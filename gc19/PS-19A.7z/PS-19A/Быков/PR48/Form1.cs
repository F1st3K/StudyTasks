﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace PR48
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void qAddBooks_Click(object sender, EventArgs e)
        {
            if (F.Text == "" || I.Text == "" || O.Text == "" || Cabinet.Text == "" || Korpus.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!", "Сообщение пользователю", MessageBoxButtons.OK);
            }
            else
            {
                int id = 0;
                Random rnd = new Random();
                id = rnd.Next(10000000, 99999999);

                string Fio = F.Text.ToString();
                string Imea = I.Text.ToString();
                string Otchecsvo = O.Text.ToString();
                string Cab = Cabinet.Text.ToString();
                string Korp = Korpus.Text.ToString();


                string con = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

                OleDbConnection oleDbConn = new OleDbConnection(con);

                oleDbConn.Open();

                OleDbCommand sql = new OleDbCommand("INSERT INTO Uchitel (id, Surname, Name, Patronymic_name, Cabinet, Korpus) VALUES (" + id + ",'" + Fio + "','" + Imea + "', '" + Otchecsvo + "', " + Cab + "," + Korp + ");");

                sql.Connection = oleDbConn;

                sql.ExecuteNonQuery();

                oleDbConn.Close();

                MessageBox.Show("Книга в базу добавлена", "Сообщение пользователю", MessageBoxButtons.OK);

                UpdatedataGridViewBooks();

                F.Clear();
                I.Clear();
                O.Clear();
                Cabinet.Clear();
                Korpus.Clear();

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connect1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(connect1);

            DataTable datatable1 = new DataTable();


            try
            {
                oleDbConn1.Open();
            }
            catch (OleDbException)
            {
                MessageBox.Show(
               "Такой базы данных не существует",
               "Ошибка",
               MessageBoxButtons.OK,
               MessageBoxIcon.Error,
               MessageBoxDefaultButton.Button1);
                exit();

                goto t1;
            }

            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel;");

            sql1.Connection = oleDbConn1;

            try
            {
                sql1.ExecuteNonQuery();
            }
            catch (OleDbException)
            {
                MessageBox.Show(
                "В БД нету такой таблицы",
                "Ошибка",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
                exit();
                goto t1;
            }


            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(datatable1);

            datatable1.Columns["Surname"].ColumnName = "Фамилия";
            datatable1.Columns["Name"].ColumnName = "Имя";
            datatable1.Columns["Patronymic_name"].ColumnName = "Отчество";
            datatable1.Columns["Cabinet"].ColumnName = "Кабинет";
            datatable1.Columns["Korpus"].ColumnName = "Корпус";

            dataGridViewBooks.DataSource = datatable1;

            dataGridViewBooks.Columns[0].Visible = false;
        t1:
            oleDbConn1.Close();
        }


        public void exit()
        {
            Application.Exit();
        }


        public void UpdatedataGridViewBooks()
        {
            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            DataTable dt1 = new DataTable();

            oleDbConn1.Open();

            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel;");

            sql1.Connection = oleDbConn1;

            sql1.ExecuteNonQuery();

            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(dt1);




            dt1.Columns["Surname"].ColumnName = "Фамилия";
            dt1.Columns["Name"].ColumnName = "Имя";
            dt1.Columns["Patronymic_name"].ColumnName = "Отчество";
            dt1.Columns["Cabinet"].ColumnName = "Кабинет";
            dt1.Columns["Korpus"].ColumnName = "Корпус";

            dataGridViewBooks.DataSource = dt1;

            oleDbConn1.Close();
        }

        private void Cabinet_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if(!Char.IsDigit(number) && number != 8 && number != 32)
            {
                e.Handled = true;
            }
        }

        private void F_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void I_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void O_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void Korpus_TextChanged(object sender, EventArgs e)
        {
            if ((F.Text.Length == 0) || I.Text.Length == 0 || O.Text.Length == 0 || Cabinet.Text.Length == 0 || Korpus.Text.Length == 0 || Korpus.Text.Length != 11)
            {
                qAddBooks.Enabled = false;
            }
            else
            {
                qAddBooks.Enabled = true;
            }
        }

        private void Cabinet_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
        
    }
}
