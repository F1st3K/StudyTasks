package var05;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Arrays;

//ВАРИАНТ № 5
//1. Дано количество часов, минут и секунд (1 час = 60 минут, 1 минута = 60 секунд). Вычислить и вывести общее
// количество секунд.
//2. Проверить истинность высказывания: "Цифры данного целого положительного четырехзначного числа образуют убывающую
// последовательность".
//3. Написать функцию int MulRange(A, B) целого типа, находящую произведение всех целых чисел от A до B включительно
// (A и B — целые положительные). Если A > B, то функция должна возвращать число 0.

class task01 {
    int task01(int Hour, int Min, int Sec) {
        Sec = Hour * 3600 + Min * 60 + Sec;
        return Sec;
    }
}

class task02 {
    int RTT(int Ch){
        int n1 = Ch / 1000;
        int n2 = Ch / 100 - n1 * 10;
        int n3 = Ch / 10 - n1 * 100 - n2 * 10;
        int n4 = Ch - n1 * 1000 - n2 * 100 - n3 * 10;
        if (n1 > n2 && n2 > n3 && n3 > n4) return 1;
        else return 0;
    }
}

class task03 {
    int MulRange(int A, int B){
        int Proizv = 1;
        int cont = 0;
        for (A = A; A <= B; A++)
        {
            Proizv *= A;
        }
        return Proizv;
    }
}

public class Main
{
    public static void main(String[] args)
    {
        //region task01
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 1");
            System.out.println("Введите кол-во часов");
            int Hour = sc.nextInt();
            System.out.println("Введите кол-во минут");
            int Min = sc.nextInt();
            System.out.println("Введите кол-во секунд");
            int Sec = sc.nextInt();

            task01 T1 = new task01();
            Sec = T1.task01(Hour, Min, Sec);
            System.out.println("Всего секунд: " + Sec);
        }
        catch (Exception ex)
        {
            System.out.println("Ошибка формата или переполнение\n");
        }
        //endregion

        //region task02
        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("\nЗадание 2");
            System.out.println("Введите четырехзначное число");
            int Ch = sc.nextInt();
            if (Ch < 10000 && Ch > 999)
            {
                task02 T2 = new task02();
                int Res02 = T2.RTT(Ch);
                if (Res02 == 1)
                {
                    System.out.println("Цифры числа образуют убывающую последовательность");
                }
                else
                {
                    System.out.println("Цифры числа не образуют убывающую последовательность");
                }
            }
            else
            {
                System.out.println("Число не является четырехзначным");
            }
        }
        catch (Exception ex)
        {
            System.out.println("Ошибка формата или переполнение\n");
        }
        //endregion

        try {
            Scanner sc = new Scanner(System.in);
            System.out.println("\nЗадание 3");
            System.out.println("Введите число A");
            int A = sc.nextInt();
            System.out.println("Введите число B (B > A)");
            int B = sc.nextInt();
            if (B > A)
            {
                task03 T3 = new task03();
                int Res03 = T3.MulRange(A, B);
                System.out.println("Произведение целых чисел между A и B включительно = " + Res03);
            }
            else
            {
                System.out.println("B должно быть меньше A (0)");
            }
        }
        catch (Exception ex)
        {
            System.out.println("Ошибка формата или переполнение\n");
        }
    }
}
