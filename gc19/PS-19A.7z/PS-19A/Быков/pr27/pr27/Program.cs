﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace pr27
{
    class Var05
    {
        static void Main(string[] args)
        {
            task01 T01 = new task01();
            int N = 0;
            try
            {
                Console.WriteLine("Задание 1");
    m1:
                Console.WriteLine("Введите 4-хзначное число");
                N = Convert.ToInt32(Console.ReadLine());
                if (N < 1000 || N > 9999) goto m1;
                string Result01 = T01.Task1(N);
                Console.WriteLine(Result01);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            task03 T03 = new task03();
            int X = 0;
            int Y = 0;
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 2");
    m2:
                Console.WriteLine("Введите X");
                X = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите Y");
                Y = Convert.ToInt32(Console.ReadLine());
                if (X == 0 || Y == 0)
                {
                    Console.WriteLine("X и Y не должны быть равны 0");
                    goto m2;
                }
                string Result03 = T03.Quarter(X, Y);
                Console.WriteLine(Result03);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            task05 T05 = new task05();
            string Str = "";
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 3");
                Console.Write("Введите строку: ");
                Str = Convert.ToString(Console.ReadLine());
                string Result05 = T05.Task5(Str);
                Console.WriteLine(Result05);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
