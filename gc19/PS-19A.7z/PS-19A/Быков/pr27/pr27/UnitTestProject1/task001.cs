﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class task001
    {
        [TestMethod]
        public void T1_1()
        {
            ClassLibrary1.task01 t1 = new ClassLibrary1.task01();
            int n = 1234;
            Assert.AreEqual("Сумма двух первых чисел не равна сумме двух последних", t1.Task1(n));
        }
        [TestMethod]
        public void T1_2()
        {
            ClassLibrary1.task01 t2 = new ClassLibrary1.task01();
            int n = 1230;
            Assert.AreEqual("Сумма двух первых чисел равна сумме двух последних", t2.Task1(n));
        }
        [TestMethod]
        public void T1_3()
        {
            ClassLibrary1.task01 t3 = new ClassLibrary1.task01();
            int n = 1444;
            Assert.AreEqual("Сумма двух первых чисел не равна сумме двух последних", t3.Task1(n));
        }
        [TestMethod]
        public void T1_4()
        {
            ClassLibrary1.task01 t4 = new ClassLibrary1.task01();
            int n = 1678;
            Assert.AreEqual("Сумма двух первых чисел не равна сумме двух последних", t4.Task1(n));
        }
        [TestMethod]
        public void T1_5()
        {
            ClassLibrary1.task01 t5 = new ClassLibrary1.task01();
            int n = 3782;
            Assert.AreEqual("Сумма двух первых чисел равна сумме двух последних", t5.Task1(n));
        }
    }
}
