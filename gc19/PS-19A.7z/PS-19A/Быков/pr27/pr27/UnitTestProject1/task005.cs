﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class task005
    {
        [TestMethod]
        public void T5_1()
        {
            ClassLibrary1.task05 t1 = new ClassLibrary1.task05();
            string Str = "vlmerlkm027fjlkehrkjhjfh";
            Assert.AreEqual("Сумма чисел: 9 \t Произведение: 0", t1.Task5(Str));
        }
        [TestMethod]
        public void T5_2()
        {
            ClassLibrary1.task05 t2 = new ClassLibrary1.task05();
            string Str = "xmklqgf;dxs/fjke;jwkhi;ofeow;hbn;olh;woihjdslkhs;";
            Assert.AreEqual("Сумма чисел: 0 \t Произведение: 0", t2.Task5(Str));
        }
        [TestMethod]
        public void T5_3()
        {
            ClassLibrary1.task05 t3 = new ClassLibrary1.task05();
            string Str = "sa;lkdcl;whojoi-12cldks";
            Assert.AreEqual("Сумма чисел: 3 \t Произведение: 2", t3.Task5(Str));
        }
        [TestMethod]
        public void T5_4()
        {
            ClassLibrary1.task05 t4 = new ClassLibrary1.task05();
            string Str = "lkjwfdkekiukcjhkjwk345";
            Assert.AreEqual("Сумма чисел: 12 \t Произведение: 60", t4.Task5(Str));
        }
        [TestMethod]
        public void T5_5()
        {
            ClassLibrary1.task05 t5 = new ClassLibrary1.task05();
            string Str = "sgergberhgtry01";
            Assert.AreEqual("Сумма чисел: 1 \t Произведение: 0", t5.Task5(Str));
        }
    }
}
