﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject1
{
    [TestClass]
    public class task003
    {
        [TestMethod]
        public void T3_1()
        {
            ClassLibrary1.task03 t1 = new ClassLibrary1.task03();
            int X = 6;
            int Y = -1;
            Assert.AreEqual("Координаты в 4-ой четверти", t1.Quarter(X, Y));
        }
        [TestMethod]
        public void T3_2()
        {
            ClassLibrary1.task03 t2 = new ClassLibrary1.task03();
            int X = -6;
            int Y = -1;
            Assert.AreEqual("Координаты в 3-ей четверти", t2.Quarter(X, Y));
        }
        [TestMethod]
        public void T3_3()
        {
            ClassLibrary1.task03 t3 = new ClassLibrary1.task03();
            int X = 6;
            int Y = 1;
            Assert.AreEqual("Координаты в 1-ой четверти", t3.Quarter(X, Y));
        }
        [TestMethod]
        public void T3_4()
        {
            ClassLibrary1.task03 t4 = new ClassLibrary1.task03();
            int X = -6;
            int Y = 1;
            Assert.AreEqual("Координаты во 2-ой четверти", t4.Quarter(X, Y));
        }
        [TestMethod]
        public void T3_5()
        {
            ClassLibrary1.task03 t5 = new ClassLibrary1.task03();
            int X = 0;
            int Y = -1;
            Assert.AreEqual("Ошибка: X или Y равно 0", t5.Quarter(X, Y));
        }
    }
}
