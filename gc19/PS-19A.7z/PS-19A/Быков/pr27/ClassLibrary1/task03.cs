﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class task03
    {
        /// <summary>
        /// 3. Написать функцию int Quarter(X, Y) целого типа, определяющую номер координатной четверти, в которой находится точка с ненулевыми целыми координатами (X, Y).
        /// </summary>
     
        public string Quarter(int X, int Y)
        {
            if (X > 0 && Y > 0) return "Координаты в 1-ой четверти";
            else if (X < 0 && Y > 0) return "Координаты во 2-ой четверти";
            else if (X < 0 && Y < 0) return "Координаты в 3-ей четверти";
            else if (X > 0 && Y < 0) return "Координаты в 4-ой четверти";
            else return "Ошибка: X или Y равно 0";
        }

    }
}
