﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class task05
    {
        /// <summary>
        /// 5. Вводится строка, содержащая буквы и цифры. Длина строки может быть разной. Вывести сумму и произведение цифр этой введенной строки. 
        /// Чтобы избежать целочисленного переполнения при произведении, вычислять это выражение с помощью вещественной переменной и выводить его как вещественное число. 
        /// </summary>
     
        public string Task5(string Str)
        {
            double Sum = 0;
            double Proizv = 1;
            int count = 0;
            for (int i = 0; i < Str.Length; i++)
            {
                if (Str[i] == '0')
                {
                    Sum += 0;
                    Proizv *= 0;
                    count = 1;
                }
                else if (Str[i] == '1')
                {
                    Sum += 1;
                    Proizv *= 1;
                    count = 1;
                }
                else if (Str[i] == '2')
                {
                    Sum += 2;
                    Proizv *= 2;
                    count = 1;
                }
                else if (Str[i] == '3')
                {
                    Sum += 3;
                    Proizv *= 3;
                    count = 1;
                }
                else if (Str[i] == '4')
                {
                    Sum += 4;
                    Proizv *= 4;
                    count = 1;
                }
                else if (Str[i] == '5')
                {
                    Sum += 5;
                    Proizv *= 5;
                    count = 1;
                }
                else if (Str[i] == '6')
                {
                    Sum += 6;
                    Proizv *= 6;
                    count = 1;
                }
                else if (Str[i] == '7')
                {
                    Sum += 7;
                    Proizv *= 7;
                    count = 1;
                }
                else if (Str[i] == '8')
                {
                    Sum += 8;
                    Proizv *= 8;
                    count = 1;
                }
                else if (Str[i] == '9')
                {
                    Sum += 9;
                    Proizv *= 9;
                    count = 1;
                }
            }
            if (count == 0) Proizv = 0;
            return "Сумма чисел: " + Sum + " \t Произведение: " + Proizv;
        }
    }
}
