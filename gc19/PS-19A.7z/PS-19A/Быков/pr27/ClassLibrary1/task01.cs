﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class task01
    {
        /// <returns>
        /// ВАРИАНТ № А5/Б41
        /// </returns>
        /// <summary>
        /// 1. Проверить истинность высказывания: "Сумма двух первых цифр данного целого положительного четырехзначного числа равна сумме двух его последних цифр".
        /// </summary>
       
        public string Task1(int N)
        {
            int A = N / 1000;
            int B = N / 100 - A * 10;
            int C = N / 10 - A * 100 - B * 10;
            int D = N - A * 1000 - B * 100 - C * 10;
            if (A + B == C + D) return "Сумма двух первых чисел равна сумме двух последних";
            else return "Сумма двух первых чисел не равна сумме двух последних";
        }
    }
}
