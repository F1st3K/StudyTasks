package main

import (
	"fmt"
)

// ВАРИАНТ № А5/Б41
// 1. В вещественном массиве известны данные о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году).
// Верно ли, что по четным числам выпало больше осадков, чем по нечетным?
// 2. Дан целочисленный массив, состоящий из N элементов (N > 0). Поменять местами минимальный и максимальный элемент этого
// массива. Вывести новый полученный массив.
// 3. Написать функцию bool IsSquare(K) логического типа, возвращающую True, если целый параметр K (K > 0) является квадратом
// некоторого целого числа, и False в противном случае.
// 4. Написать функцию double RingS(R1, R2) вещественного типа, находящую площадь кольца, заключенного между двумя окружностями
// с общим центром и радиусами R1 и R2 (R1 и R2 — вещественные, R1 > R2). Воспользоваться формулой площади круга радиуса R: S = π·R2.
// В качестве значения π использовать 3.14.

func main() {
	//task01
	{
		fmt.Println("Задение 1")

		var month int
		var day int
	m1:
		fmt.Println("Введите номер месяца")
		_, err := fmt.Scan(&month)

		if err != nil {
			fmt.Println(err)
		}

		if (month > 12) || (month < 1) {
			fmt.Println("Число должно соответствовать номеру существующего месяца(1-12)")
			goto m1
		}
		if month == 1 {
			day = 31
		} else if month == 2 {
			day = 28
		} else if month == 3 {
			day = 31
		} else if month == 4 {
			day = 30
		} else if month == 5 {
			day = 31
		} else if month == 6 {
			day = 30
		} else if month == 7 {
			day = 31
		} else if month == 8 {
			day = 31
		} else if month == 9 {
			day = 30
		} else if month == 10 {
			day = 31
		} else if month == 11 {
			day = 30
		} else {
			day = 31
		}

		var nech, ch = task01(day)

		if nech > ch {
			fmt.Println("В нечётные дни выпало больше осадков")
		} else if nech == ch {
			fmt.Println("В нечётные и чётные дни выпало одинаковое кол-во осадков")
		} else {
			fmt.Println("В чётные дни выпало больше осадков")
		}
	}

	//task02
	{
		fmt.Println("\nЗадение 2")
		var mas []int
	m2_1:
		fmt.Println("Введите кол-во элементов массива")
		var el int
		_, err := fmt.Scan(&el)

		if err != nil {
			fmt.Println(err)
			goto m2_1
		}

		mas = task02(mas, el)

		fmt.Println("Получившийся массив: ", mas)
	}
}

func task01(day int) (int, int) {

	nech := 0
	ch := 0
	var p int
	var os []int

	for i := 0; i < day; i++ {
	m1_1:
		fmt.Println("Введите сколько осадков выпало в ", i+1, " день")
		_, err := fmt.Scan(&p)

		if err != nil {
			fmt.Println(err)
			goto m1_1
		}
		os = append(os, p)
	}

	for i := 0; i < day; i++ {
		if i == 0 {
			nech += os[i]
		} else if i == 1 {
			ch += os[i]
		} else if i%2 == 0 {
			nech += os[i]
		} else if i%2 == 1 {
			ch += os[i]
		}
	}

	return nech, ch
}

func task02(mas []int, el int) ([]int) {

	var f int
	for i := 0; i < el; i++ {
	m1_2:
		fmt.Println("Введите ", i+1, " элемент массива")
		_, err := fmt.Scan(&f)

		if err != nil {
			fmt.Println(err)
			goto m1_2
		}
		mas = append(mas, f)
	}

	var max int
	var min int
	max = mas[1]
	min = mas[1]

	for i := 0; i < el; i++ {
		if max < mas[i] {
			max = mas[i]
		}
		if min > mas[i] {
			min = mas[i]
		}
	}

	for i := 0; i < el; i++ {
		if mas[i] == max {
			mas[i] = min
		} else if mas[i] == min {
			mas[i] = max
		}
	}
	return mas
}