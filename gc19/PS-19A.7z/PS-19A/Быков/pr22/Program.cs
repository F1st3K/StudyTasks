﻿// ВАРИАНТ № А5/Б41
// 1. Дано количество часов, минут и секунд (1 час = 60 минут, 1 минута = 60 секунд). Вычислить и вывести общее количество секунд.
// 2. Проверить истинность высказывания: "Сумма всех цифр данного целого положительного трехзначного числа является нечетным числом".
// 3. Из пяти введенных целых положительных чисел найти два наибольших и вывести произведение этих двух наибольших чисел.
// 4. Написать функцию int Min4(A, B, C, D) целого типа, возвращающую одно минимальное значение из 4-х своих аргументов (параметры A, B, C 
// и D - целые числа).
// 5. Вводится строка, состоящая из букв и цифр (от 0 до 9). Длина строки может быть разной. Вывести сумму всех четных цифр встречающихся 
// в этой строке. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace pr22
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Task01
            int hour = 0;
            int min = 0;
            int sec = 0;
            int allsec = 0;
            string result01 = "";

            // Переход к реестру
            RegistryKey Task1 = Registry.CurrentUser;
            
            // Создание реестра PR_22
            RegistryKey newTask1 = Task1.CreateSubKey("PR_22");
            RegistryKey wKey = Task1.OpenSubKey("PR_22", true);


            try
            {
                Console.WriteLine("Задание 1");
                Console.Write("Введите кол-во часов ");
                hour = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите кол-во минут ");
                min = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите кол-во секунд ");
                sec = Convert.ToInt32(Console.ReadLine());
                allsec = hour * 3600 + min * 60 + sec;

                // Запись в реестр
                RegistryKey newKey = wKey.CreateSubKey("Task01");
                Console.WriteLine("Запись \'{0}\' успешно внесена в реестр!", newKey.Name);
                newKey.SetValue("Hour", "Часов вписано " + hour);
                newKey.SetValue("Min", "Минут вписано " + min);
                newKey.SetValue("Sec", "Секунд вписано " + sec);
                newKey.SetValue("Result1", "Всего секунд " + allsec);

                result01 = Convert.ToString(newKey.GetValue("Result1"));
                Console.WriteLine(result01);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                // закрываем запись
                Task1.Close();
            }
            finally
            {
                // закрываем запись
                Task1.Close();
            }
            #endregion

            #region Task02
            int Slot = 0;
            int Num1 = 0;
            int Num2 = 0;
            int Num3 = 0;
            int count = 0;
            string result02 = "";

            RegistryKey Task2 = Registry.CurrentUser;

            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 2");
    mT2:
                Console.Write("Введите 3-хзначное число ");
                Slot = Convert.ToInt32(Console.ReadLine());
                if (Slot > 999 || Slot < 99) goto mT2;
                Console.Write("Введите кол-во минут ");
                Num1 = Slot / 100;
                Num2 = Slot / 10 - Num1 * 10;
                Num3 = Slot - Num1 * 100 - Num2 * 10;
                if ((Num1 + Num2 + Num3) % 2 == 0) count = 1;

                // Запись в реестр
                RegistryKey newKey = wKey.CreateSubKey("Task02");
                Console.WriteLine("Запись \'{0}\' успешно внесена в реестр!", newKey.Name);
                newKey.SetValue("Slot", "Вписанное трёхзначное число " + Slot);
                if (count == 1) newKey.SetValue("Result2", "Сумма чисел трёхзначного числа является чётной");
                else newKey.SetValue("Result2", "Сумма чисел трёхзначного числа является нечётной");

                result02 = Convert.ToString(newKey.GetValue("Result2"));
                Console.WriteLine(result02);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                // закрываем запись
                Task2.Close();
            }
            finally
            {
                // закрываем запись
                Task2.Close();
            }
            #endregion 

            #region Task03
            string result03 = "";
            int[] Mas = new int[5];
            int[] Sort = new int[5];

            RegistryKey Task3 = Registry.CurrentUser;

            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 3");
                for (int i = 0; i < Mas.Length; i++)
                {
                    Console.WriteLine("Введите " + (i + 1) + " элемент массива");
    mT3:
                    Mas[i] = Convert.ToInt32(Console.ReadLine());
                    if (Mas[i] < 0)
                    {
                        Console.WriteLine("Число должно быть положительным");
                        goto mT3;
                    }
                }
                Sort = Mas;
                Array.Sort(Sort);

                // Запись в реестр
                RegistryKey newKey = wKey.CreateSubKey("Task03");
                Console.WriteLine("Запись \'{0}\' успешно внесена в реестр!", newKey.Name);
                newKey.SetValue("Mass", "Вписаный массив " + Mas[0] + ", " + Mas[1] + ", " + Mas[2] + ", " + Mas[3] + ", " + Mas[4]);
                newKey.SetValue("Result3", "Максимальные числа массива " + Sort[Sort.Length - 1] + " и " + Sort[Sort.Length - 2]);

                result03 = Convert.ToString(newKey.GetValue("Result3"));
                Console.WriteLine(result03);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                // закрываем запись
                Task3.Close();
            }
            finally
            {
                // закрываем запись
                Task3.Close();
            }
            #endregion

            #region Task04
            int A = 0;
            int B = 0;
            int C = 0;
            int D = 0;
            int Min = 0;
            string result04 = "";

            RegistryKey Task4 = Registry.CurrentUser;

            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 4");
                Console.Write("Введите 1-ое число ");
                A = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите 2-ое число ");
                B = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите 3-ое число ");
                C = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите 4-ое число ");
                D = Convert.ToInt32(Console.ReadLine());
                Min = Min4(A, B, C, D);

                // Запись в реестр
                RegistryKey newKey = wKey.CreateSubKey("Task04");
                Console.WriteLine("Запись \'{0}\' успешно внесена в реестр!", newKey.Name);
                newKey.SetValue("Nums", "Вписанные числа " + A + ", " + B + ", " + C + ", " + D);
                newKey.SetValue("Result4", "Минимальное число " + Min);

                result04 = Convert.ToString(newKey.GetValue("Result4"));
                Console.WriteLine(result04);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                // закрываем запись
                Task4.Close();
            }
            finally
            {
                // закрываем запись
                Task4.Close();
            }
            #endregion

            #region Task05
            string result05 = "";
            string Str = "";
            int SumCh = 0;

            RegistryKey Task5 = Registry.CurrentUser;

            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 5");
                
                Console.WriteLine("Введите строку");
                Str = Convert.ToString(Console.ReadLine());
                for (int i = 0; i < Str.Length; i++)
                {
                    if (Str[i] == '2') SumCh += 2;
                    else if (Str[i] == '4') SumCh += 4;
                    else if (Str[i] == '6') SumCh += 6;
                    else if (Str[i] == '8') SumCh += 8;
                }
                
                // Запись в реестр
                RegistryKey newKey = wKey.CreateSubKey("Task05");
                Console.WriteLine("Запись \'{0}\' успешно внесена в реестр!", newKey.Name);
                newKey.SetValue("Str", "Вписанная строка " + Str);
                newKey.SetValue("Result5", "Сумма чётных чисел в строке " + SumCh);

                result05 = Convert.ToString(newKey.GetValue("Result5"));
                Console.WriteLine(result05);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                // закрываем запись
                Task5.Close();
            }
            finally
            {
                // закрываем запись
                Task5.Close();
            }
            #endregion

            // удаление реестра "PR_22"
            try
            {
                for (int i = 0; i < 5; i++) { Console.WriteLine(); }
                Console.WriteLine("Для удаления реестра нажмите клавишу клавиатуры отвечающую за ввод");
                Console.ReadKey();
                for (int i = 0; i < 5; i++) { Console.WriteLine(); }
                Console.WriteLine("Всего записей в {0}: {1}.", Task1.Name, Task1.SubKeyCount);
                Task1.DeleteSubKeyTree("PR_22", true);

                Console.WriteLine("Запись \'PR_22\' успешно удалена из реестра!");
                Console.WriteLine("Теперь записей стало: {0}.", Task1.SubKeyCount);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                wKey.Close();
            }

            // Задержка на экране.
            Console.ReadKey();
        }


        static int Min4(int A, int B, int C, int D)
        {
            int[] MS = new int[4];
            MS[0] = A;
            MS[1] = B;
            MS[2] = C;
            MS[3] = D;
            return MS.Min();
        }
    }
}
