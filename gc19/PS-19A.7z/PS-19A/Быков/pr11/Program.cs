﻿// Вариант 05 - задание 05, 28, 24.
// Задание 05. Вычисление объема цилиндра
// Задание 28. Пересчет веса из килограммов в фунты (1 фунт — это 405,9 грамма)
// Задание 24. Пересчет расстояния из километров в мили (1 км - это 0,621 мили)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr11
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            Console.WriteLine("Задание 1\n");
            double r = 0;
            double h = 0;
            double R1;

            Console.WriteLine("Введите радиус");            
            r = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите высоту");
            h = Convert.ToDouble(Console.ReadLine());
            R1 = r * r * h * 3.14;
            Console.WriteLine(R1);

            #endregion

            #region Задание 2
            Console.WriteLine("\nЗадание 2\n");
            double kg = 0;
            double R2;

            Console.WriteLine("Введите вес в килограммах");
            kg = Convert.ToDouble(Console.ReadLine());
            R2 = kg * 2.20462;
            Console.WriteLine("Этот вет в фунтах = " + R2);

            #endregion

            #region Задание 3
            Console.WriteLine("\nЗадание 2\n");
            double km = 0;
            double R3;

            Console.WriteLine("Введите расстояние в километрах");
            km = Convert.ToDouble(Console.ReadLine());
            R3 = km * 0.621;
            Console.WriteLine("Это расстояние в милях = " + R3);

            #endregion

            Console.ReadKey();
            
        }
    }
}
