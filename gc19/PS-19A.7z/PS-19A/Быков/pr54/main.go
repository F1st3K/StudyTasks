package main

import (
	"fmt"
	"sort"
	"strconv"
)

// ВАРИАНТ № А5/Б41
// 1. Дано целое положительное пятизначное число N (N > 0). Используя операции деления и определения остатка от деления найти
// и вывести сумму всех его цифр.
// 2. Проверить истинность высказывания: "Квадратное уравнение A·x2 + B·x + C = 0 с данными коэффициентами A (A ≠ 0), B, C
// имеет ровно два вещественных корня".
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0). Проверить, чередуются ли в нем четные и нечетные числа.
// Если чередуются, то вывести 0, если нет, то вывести порядковый номер первого элемента, нарушающего закономерность.
// 4. Вводится строка, содержащая латинские буквы и скобки трех видов: «()», «[]», «{}». Если скобки расставлены правильно
// (т.е. каждой открывающей соответствует закрывающая скобка того же вида), то вывести число 0. В противном случае вывести
// или номер позиции, в которой расположена первая ошибочная скобка, или, если закрывающих скобок не хватает, значение −1.

func main() {
	//task01
	{
		fmt.Println("Задение 1")
		var (
			N  int
			n1 int
			n2 int
			n3 int
			n4 int
			n5 int
			c  []byte
		)

		_, err := fmt.Scan(&c)

		if err != nil {
			fmt.Println("Произошла ошибка формата")
			goto mn2
		}

		N, err = strconv.Atoi(string(c))

		if err != nil {
			fmt.Println("Ошибка, в файл введено не верный формат данных")
			goto mn2
		}

		if (N < 10000) || (N > 99999) {
			fmt.Println("Число не пятизначное")
			goto mn2
		}

		n1 = N / 10000
		n2 = N/1000 - n1*10
		n3 = N/100 - n1*100 - n2*10
		n4 = N/10 - n1*1000 - n2*100 - n3*10
		n5 = N - n1*10000 - n2*1000 - n3*100 - n4*10

		ress := n1 + n2 + n3 + n4 + n5

		fmt.Println("Сумма всех чисел: " + strconv.Itoa(ress))
	}
mn2:

	//task03
	{
		fmt.Println("\nЗадение 3")
		var (
			mas  []int
			rm   int
			asdf int
		)
		fmt.Println("Введите кол-во эл-ов массива")
		_, err := fmt.Scan(&rm)

		if err != nil {
			fmt.Println("Произошла ошибка формата")
			goto mn4
		}

		for i := 0; i < rm; i++ {
			fmt.Println("Введите", i+1, " элемент массива")
			_, err = fmt.Scan(&asdf)

			if err != nil {
				fmt.Println("Ошибка формата")
				goto mn4
			}

			mas = append(mas, asdf)
		}

		var gg int
		var ff int
		var nn int
		for i := 0; i < len(mas); i++ {

			if (mas[i]%2 == 1) && (i == 0) {
				ff++
				gg = 0
				nn = 1
			} else if (mas[i]%2 == 0) && (i == 0) {
				ff++
				gg = 1
				nn = 0
			}
			if gg == 1 && nn == 0 && i != 0 && mas[i]%2 == 1 {
				ff++
				gg = 0
				nn = 1
			} else if gg == 0 && nn == 1 && i != 0 && mas[i]%2 == 0 {
				ff++
				gg = 1
				nn = 0
			}

		}

		if ff == len(mas) {
			fmt.Println("Все элементы чередуются")
		} else {
			fmt.Println("Не все элементы чередуются")
		}

	}

	//task04
mn4:
	{
		fmt.Println("\nЗадение 4")
		mas := ""

		fmt.Println("Введите строку")
		_, err := fmt.Scan(&mas)

		if err != nil {
			fmt.Println(err)
			goto mn5
		}
		fg := 0
		fh := 0
		fj := 0
		for i := 0; i < len(mas); i++ {

			if mas[i] == '{' {
				fg++
			} else if mas[i] == '}' {
				fg--
			} else if mas[i] == '[' {
				fh++
			} else if mas[i] == ']' {
				fh--
			} else if mas[i] == '(' {
				fj++
			} else if mas[i] == ')' {
				fj--
			}

		}
		if fg == 0 && fh == 0 && fj == 0 {
			fmt.Println("Все скобки закрыты")
		} else {
			fmt.Println("Не все скобки закрыты")
		}

	}
mn5:
}

func Min4(A int, B int, C int, D int) int {
	var sl []int
	sl = append(sl, A, B, C, D)
	sort.Ints(sl)
	return sl[0]
}
