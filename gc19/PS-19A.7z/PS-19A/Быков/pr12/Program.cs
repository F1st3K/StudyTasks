﻿// ВАРИАНТ № А5/Б41
// 1. Дано количество часов, минут и секунд (1 час = 60 минут, 1 минута = 60 секунд). Вычислить и вывести общее количество секунд.
// 2. Задано целое положительное четырехзначное число N (N > 0). Найти разницу между суммой всех его цифр и произведением четных цифр.
// 3. Проверить истинность высказывания: "Сумма двух первых цифр данного четырехзначного целого положительного числа равна сумме двух его последних цифр".
// 4. Дан набор, состоящий из пяти целых ненулевых чисел. Найти количество положительных чисел в этом наборе.
// 5. В восточном календаре принят 60-летний цикл, состоящий из 12-летних подциклов, обозначаемых названиями цвета: зеленый, красный, желтый, белый и черный. 
// В каждом подцикле годы носят названия животных: крысы, коровы, тигра, зайца, дракона, змеи, лошади, овцы, обезьяны, курицы, собаки и свиньи. 
// По номеру года определить его название, если 1984 год - начало цикла: «год зеленой крысы». 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr12
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            Console.WriteLine("Задание 1");
            int hour = 0;
            int min = 0;
            int sec = 0;
            Console.WriteLine("Введите часы");

            //обработчик исключения
            try
            {
                hour = Convert.ToInt32(Console.ReadLine());
            }
            catch (System.FormatException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            catch (System.OverflowException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            Console.WriteLine("Введите минуты");

            //обработчик исключения
            try
            {
                min = Convert.ToInt32(Console.ReadLine());
            }
            catch (System.FormatException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            catch (System.OverflowException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            Console.WriteLine("Введите секунды");

            //обработчик исключения
            try
            {
                sec = Convert.ToInt32(Console.ReadLine());
            }
            catch (System.FormatException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            catch (System.OverflowException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            sec = (hour * 60 * 60) + (min * 60) + sec;
            Console.WriteLine("Общее кол-во секунд - " + sec);

            #endregion

            #region Задание 2

            Console.WriteLine("\nЗадание 2");
            int N = 0;
            int t1 = 0;
            int t2 = 0;
            int t3 = 0;
            int t4 = 0;
            int vR1 = 0;
            int vR2 = 1;

        m20:
            Console.WriteLine("Введите целое положительное четырехзначное число N (N > 0)");

            try
            {
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (System.FormatException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            catch (System.OverflowException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            if (N < 0)
            {
                Console.WriteLine("Введите N > 0");
                goto m20; 
            }
            if (N > 999 && N < 10000)
            {
                t1 = N / 1000;
                t2 = N / 100 - t1 * 10;
                t3 = N / 10 - t2 * 10 - t1 * 100;
                t4 = N - t1 * 1000 - t2 * 100 - t3 * 10;
                vR1 = t1 + t2 + t3 + t4;
                if (t1 % 2 == 1) vR2 = vR2;
                else vR2 = vR2 * t1;
                if (t2 % 2 == 1) vR2 = vR2;
                else vR2 = vR2 * t2;
                if (t3 % 2 == 1) vR2 = vR2;
                else vR2 = vR2 * t3;
                if (t4 % 2 == 1) vR2 = vR2;
                else vR2 = vR2 * t4;
            }
            else goto m20;
            if (vR2 == 1) vR2 = 0;
            Console.WriteLine("Разница между суммой всех цифр и произведением четных цифр = " + vR1 + " - " + vR2 + " = " + (vR1 - vR2));

            #endregion

            #region Задание 3
            Console.WriteLine("\nЗадание 3");
        m10:
            int n1 = 0;
            int n2 = 0;
            int n3 = 0;
            int n4 = 0;
            int Gl = 0;
            Console.WriteLine("Введите целое положительное четырёхзначное число");

            //обработчик исключения
            try
            {
                Gl = Convert.ToInt32(Console.ReadLine());
            }
            catch (System.FormatException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            catch (System.OverflowException exception)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("METHOD - " + exception.TargetSite.ToString()); //метод
                Console.WriteLine("MESSAGE - " + exception.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("SOURCE - " + exception.Source.ToString()); //источник ошибки
                Console.WriteLine("DATA - " + exception.Data.ToString());   //дополнит информация
                Console.WriteLine("STACK - " + exception.StackTrace.ToString());
                Console.WriteLine("----------------------------------------------------------------\n");
            }
            if (Gl > 999 && Gl < 10000)
            {
                n1 = Gl / 1000;
                n2 = Gl / 100 - n1 * 10;
                n3 = Gl / 10 - n2 * 10 - n1 * 100;
                n4 = Gl - n1 * 1000 - n2 * 100 - n3 * 10;
                if (n1 + n2 == n3 + n4) Console.WriteLine("Сумма двух первых цифр данного числа равна сумме двух его последних цифр\n");
                else Console.WriteLine("Сумма двух первых цифр данного числа не равна сумме двух его последних цифр\n");
            }
            else goto m10;
            #endregion

            Console.ReadKey();
        }
    }
}
