﻿// ВАРИАНТ № 5/15/25
// Класс для лейтенанта (взводы/танки/бойцы) (во взводе 3 танка, в танке 4 бойца)ы

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using var05;

namespace var05
{
    class Program
    {
        static void Main(string[] args)
        {
            int vzvods = 0;
            int exp = 0;
            int tanks = 0;
            int warriors = 0;

            try
            {
                Console.WriteLine("Введите кол-во взводов");
                vzvods = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                exp = 1;
                Console.WriteLine(ex.Message);
            }

            if (exp == 0)
            {
                task Num = new task(vzvods, exp);
                tanks = Num.TK();
                warriors = Num.WR();
            }

            if (exp == 0)
            {
                Console.WriteLine("Взводов " + vzvods + ", танков " + tanks + ", бойцов " + warriors);
            }
        }
    }
}
