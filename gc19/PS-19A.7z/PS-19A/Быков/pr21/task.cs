﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var05
{
    class task
    {
        public int vzvods = 0;
        public int tanks = 0;
        public int warriors = 0;
        public int exp1 = 0;

        public task(int vzvod, int exp)
        {
            vzvods = vzvod;
            exp1 = exp;
        }

        public int TK()
        {
            if (exp1 == 0)
            {
                tanks = vzvods * 3;
                return vzvods * 3;
            }

            else
            {
                return 0;
            }
        }

        public int WR()
        {
            if (exp1 == 0)
            {
                return tanks * 4;
            }

            else
            {
                return 0;
            }
        }
    }
}
