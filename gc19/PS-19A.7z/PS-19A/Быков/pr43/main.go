package main

// Вариант 05
// Авиакомпания (char), тип самолета (char), вместимость пассажиров (int), бортовой номер (int), часов
// до выработки ресурса (float).
// Поиск по оставшемуся ресурсу "не менее".

import (
	"fmt"
	"os"
)

type DB struct {
	AirCom string
	Type   string
	People int
	NumR   int
	Res    float64
	Num    int
}

type sDB struct {
}

func check(e error) {
	if e != nil {
		panic(e)
	}
}

func main() {
t1:
	a := 0
	fmt.Printf("Выберите действие  \n" +
		"1 - Поиск по номеру строки\n" +
		"2 - Поиск по оставшемуся ресурсу 'не менее'\n" +
		"Любое другое число - Выход из программы\n")

	_, err := fmt.Scan(&a)
	check(err)

	if a == 1 {
		seek()
		goto t1
	}
	if a == 2 {
		seekYsl()
		goto t1
	}

}

func seek() {
t2:
	f, err := os.Open("input.txt")
	check(err)

	sDB := DB{}

	a := 0
	fmt.Println("Введите номер записи")
	_, err = fmt.Scan(&a)
	check(err)

	for i := 1; i < 32; i++ {
		fmt.Fscanf(f, "%s%s%d%d%f", &sDB.AirCom, &sDB.Type,
			&sDB.People, &sDB.NumR, &sDB.Res)
		sDB.Num = i

		if a*2 == i {
			fmt.Printf("----------------------- \nАвиакомпания: %s \n Тип самолёта: %s \n Вместимость пассажиров: %d \n Номер рейса: %d \n Часов до выработки ресурса: %f \n----------------------- \n", sDB.AirCom, sDB.Type,
				sDB.People, sDB.NumR, sDB.Res)
		}
	}

	fmt.Println("Выбрать другую запись по номеру? \n " +
		"1 - ДА\n " +
		"Любое иное число - НЕТ")

	_, err = fmt.Scan(&a)
	check(err)

	if a == 1 {
		goto t2
	}

}

func seekYsl() {
t3:
	f, err := os.Open("input.txt")
	check(err)

	sDB := DB{}

	var a float64

	fmt.Println("Введите часы до выработки ресурса")
	_, err = fmt.Scan(&a)
	check(err)

	Ia := 0

	fmt.Fscanf(f, "%s%s%d%d%f", &sDB.AirCom, &sDB.Type,
		&sDB.People, &sDB.NumR, &sDB.Res)

	for i := 1; i < 22; i++ {
		fmt.Fscanf(f, "%s%s%d%d%f", &sDB.AirCom, &sDB.Type,
			&sDB.People, &sDB.NumR, &sDB.Res)
		sDB.Num = i

		// 00.00.00
		a1 := sDB.Res

		s1 := a

		if (s1 <= a1) && Ia != i {
			fmt.Printf("Авиакомпания: %s \n Тип самолёта: %s \n Вместимость пассажиров: %d \n Номер рейса: %d \n Часов до выработки ресурса: %f \n ----------------------- \n", sDB.AirCom, sDB.Type,
				sDB.People, sDB.NumR, sDB.Res)
			Ia = i + 1
		}

	}
	fmt.Println("Подобрать другое время? \n " +
		"1 - ДА\n " +
		"Любое иное число - НЕТ")

	_, err = fmt.Scan(&a)
	check(err)

	if a == 1 {
		goto t3
	}
}
