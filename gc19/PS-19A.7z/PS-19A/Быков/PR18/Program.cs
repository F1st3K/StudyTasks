﻿// Вариант № 5/20
// 1. Тамбовская область (село)
// 2. Тверская область (поселок)
// 3. Тульская область (город)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.IO;

namespace ex_ArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();
            StreamWriter swtch1 = File.CreateText("out1.txt");
            StreamWriter swtch2 = File.CreateText("out2.txt");
            StreamWriter swtch3 = File.CreateText("out3.txt");
            string TTT;

            try
            {
            using (StreamReader sr = File.OpenText("oktmo.csv"))
            {
                string input = null;
                while ((input = sr.ReadLine()) != null)
                {
                    list.Add(input);
                }
            }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }

            for(int i=1; i<list.Count; i++)
            {
                string tr = list[i].ToString();
                string[] gg = tr.Split(';');
                TTT = gg[12];
                if (TTT != "")
                {
                    if ((gg[16] == "Тамбовская область" && gg[18] == "село") || (gg[16] == "Тамбовская область" && TTT.Substring(0, 1) == "с"))
                    {
                        swtch1.WriteLine(tr);
                    }
                    if ((gg[16] == "Тверская область" && gg[18] == "поселок") || (gg[16] == "Тверская область" && TTT.Substring(0, 1) == "п"))
                    {
                        swtch2.WriteLine(tr);
                    }
                    if ((gg[16] == "Тульская область" && gg[18] == "город") || (gg[16] == "Тульская область" && TTT.Substring(0, 1) == "г"))
                    {
                        swtch3.WriteLine(tr);
                    }
                }
            }

            swtch1.Close();
            swtch2.Close();
            swtch3.Close();

        }
    }
}
