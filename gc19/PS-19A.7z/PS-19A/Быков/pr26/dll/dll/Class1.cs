﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bykov
{
    public class pr26
    {
        public bool Task01(int X, int Y)
        {
            if (X < 0 && Y > 0)
            {
                return true;
            }
            else return false;
        }

        public double Task02(int Tf)
        {
            double Tc = (Tf - 32) * 5 / 9;
            return Tc;
        }

        public double Task03(double Tr)
        {
            double P = Tr * 3;
            return P;
        }

        public bool Task04(string Str)
        {
            int c1 = 0;
            int c2 = 0;
            int c3 = 0;
            for (int i = 0; i<Str.Length; i++)
            {
                if (Str[i] == '(') c1++;
                else if (Str[i] == ')') c1--;
                else if (Str[i] == '{') c2++;
                else if (Str[i] == '}') c2--;
                else if (Str[i] == '[') c3++;
                else if (Str[i] == ']') c3--;
            }
            if (c1 == 0 && c2 == 0 && c3 == 0) return true;
            else return false;
        }
    }
}
