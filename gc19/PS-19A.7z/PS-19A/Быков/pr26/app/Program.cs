﻿// ВАРИАНТ № А5/Б31
// 1. Проверить истинность высказывания: "Данные целые числа X и Y являются координатами точки, лежащей во второй координатной четверти".
// 2. Дано значение некоторой температуры T (целое ненулевое число) в градусах Фаренгейта (Tf). Определить значение этой же температуры в градусах Цельсия (Tc). 
// Температура по Цельсию (Tc) и температура по Фаренгейту (Tf) связаны следующим соотношением: Tc = (Tf − 32)* 5/9.
// 3. Написать функцию double TriangleP(a) вещественного типа, вычисляющую по стороне a равностороннего треугольника его периметр P = 3·a (параметр a является вещественным). 
// С помощью этой процедуры найти периметры трех равносторонних треугольников с данными сторонами.
// 4. Вводится строка, содержащая латинские буквы и скобки трех видов: «()», «[]», «{}». Если скобки расставлены правильно 
// (т. е. каждой открывающей соответствует закрывающая скобка того же вида), то вывести число 0. В противном случае вывести или номер позиции, 
// в которой расположена первая ошибочная скобка, или, если закрывающих скобок не хватает, значение −1. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Bykov;

namespace app
{
    class Program
    {
        static void Main(string[] args)
        {
            pr26 lib = new pr26();

            #region Task01
            int X = 0;
            int Y = 0;

            try
            {
                Console.WriteLine("Задание 1");
                Console.WriteLine("Введите X");
                X = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите Y");
                Y = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto mEnd1;
            }
            bool Result01 = lib.Task01(X, Y);
            if (Result01 == true)
            {
                Console.WriteLine("Точка лежит во второй координатной четверти");
            }
            else
            {
                Console.WriteLine("Точка не лежит во второй координатной четверти");
            }
    mEnd1:
            #endregion

            #region Task02
            int Tf = 0;
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 2");
                Console.WriteLine("Введите температуру в градусах Фаренгейта");
                Tf = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto mEnd2;
            }

            double Tc = lib.Task02(Tf);
            Console.WriteLine(Tc );
    mEnd2:
            #endregion

            #region Task03
            double Tr1 = 0;
            double Tr2 = 0;
            double Tr3 = 0;
            double P1 = 0;
            double P2 = 0;
            double P3 = 0;

            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 3");
                Console.WriteLine("Введите сторону первого треугольника");
                Tr1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите сторону второго треугольника");
                Tr2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите сторону третьего треугольника");
                Tr3 = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto mEnd3;
            }
            P1 = lib.Task03(Tr1);
            P2 = lib.Task03(Tr2);
            P3 = lib.Task03(Tr3);

            Console.WriteLine("Периметр первого треугольника: " + P1);
            Console.WriteLine("Периметр второго треугольника: " + P2);
            Console.WriteLine("Периметр третьего треугольника: " + P3);
    mEnd3:
            #endregion

            #region Task04
            string Str = "";

            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 4");
                Console.WriteLine("Введите строку");
                Str = Convert.ToString(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto mEnd4;
            }
            bool Result04 = lib.Task04(Str);

            if (Result04 == true) Console.WriteLine("Нет лишних открытых или закрытых скобок");
            else if (Result04 == false) Console.WriteLine("Не все скобки закрыты");
    mEnd4: ;
            #endregion
        }
    }
}
