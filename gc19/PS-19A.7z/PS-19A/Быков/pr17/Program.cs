﻿// ВАРИАНТ № А5/Б41
// 1. В вещественном массиве известны данные о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году). 
// Верно ли, что по четным числам выпало больше осадков, чем по нечетным?
// 2. Дан целочисленный массив, состоящий из N элементов (N > 0). Поменять местами минимальный и максимальный элемент этого массива. 
// Вывести новый полученный массив.
// 3. Написать функцию bool IsSquare(K) логического типа, возвращающую True, если целый параметр K (K > 0) является квадратом некоторого 
// целого числа, и False в противном случае.
// 4. Написать функцию double RingS(R1, R2) вещественного типа, находящую площадь кольца, заключенного между двумя окружностями с 
// общим центром и радиусами R1 и R2 (R1 и R2 — вещественные, R1 > R2). Воспользоваться формулой площади круга радиуса R: S = π·R2. 
// В качестве значения π использовать 3.14. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr17
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            
            int N = 0;
            Console.WriteLine("Задание 1");
        m10:
            Console.WriteLine("Введите номер месяца");
            try
            {
            N = Convert.ToInt32(Console.ReadLine());
            if (N < 1 || N > 12)
            {
                goto m10;
            }
            }
            catch(FormatException)
            {
                Console.WriteLine("Неверный формат");
            }
            catch (OverflowException)
            {
                Console.WriteLine("переполнение массива");
            }
            string Otv1 = T1(N);
            Console.WriteLine(Otv1);
            #endregion

            #region Задание 2

            int E = 0;
            Console.WriteLine("\nЗадание 2");
        m18:
            Console.WriteLine("Введите кол-во элементов в массиве");
            try
            {
                E = Convert.ToInt32(Console.ReadLine());
                if (E < 1)
                {
                    Console.WriteLine("В массиве должен быть минимум 1 элемент");
                    goto m18;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Неверный формат");
                goto mT4;
            }
            catch (OverflowException)
            {
                Console.WriteLine("переполнение массива");
                goto mT4;
            }
            int[] Otv2 = T2(E);
            Console.Write("Массив с заменой максимальных и минимальных чисел ");
            for (int i = 0; i < E; i++)
            {
                Console.Write(" {0} ",Otv2[i]);
            }
            Console.WriteLine();

            #endregion

        mT4:
            #region Задание 4
            double R1 = 0;
            double R2 = 0;
            Console.WriteLine("\nЗадание 4");
        m111:
            try
            {
                Console.WriteLine("Введите радиус первого круга");
                R1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Введите радиус второго круга");
                R2 = Convert.ToDouble(Console.ReadLine());
                if (R1 < R2)
                {
                    Console.WriteLine("Радиус первого круга должен быть больше радиуса второго");
                    goto m111;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Неверный формат");
            }
            catch (OverflowException)
            {
                Console.WriteLine("переполнение массива");
            }
            double T4 = RingS(R1, R2);
            Console.WriteLine("Площадь кольца = {0}", T4);
            #endregion

            Console.WriteLine();
        }
        static string T1(int N)
        {
            int i = 0;
            double Chet = 0;
            double Nechet = 0;
            if (N == 1 || N == 3 || N == 5 || N == 7 || N == 8 || N == 10 || N == 12)
            {
                i = 31;
            }
            else if (N == 2)
            {
                i = 28;
            }
            else
            {
                i = 30;
            }
            double[] Mas = new double[i];
            for (int j = 0; j < i; j++)
            {
            m12:
                Console.WriteLine("Введите кол-во осадков выпавших в {0} день", j + 1);
                try
                {
                    Mas[j] = Convert.ToDouble(Console.ReadLine());
                }
                catch
                {
                    goto m12;
                }
                if (j % 2 == 0 || j == 0)
                {
                    Nechet += Mas[j]; 
                }
                else
                {
                    Chet += Mas[j];
                }
            }
            string T1 = "";
            if (Nechet > Chet) T1 = "По нечётным дням выпало больше осадков";
            else if (Nechet < Chet) T1 = "По чётным дням выпало больше осадков";
            else T1 = "По чётным и нечётным дням выпало одинаковое кол-во осадков";
            return T1;
        }

        static double RingS(double R1, double R2)
        {
            double R3 = R1 - R2;
            double S = 3.14 * R3;
            return S;
        }

        static int[] T2(int E)
        {
            int min2;
            int max2;
            int[] MasT2 = new int[E];
            for (int i = 0; i < E; i++)
            {
                Console.WriteLine("Введите {0} элемент массива", i+1);
                try
                {
                    MasT2[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Неверный формат");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("переполнение массива");
                }
               
            }
            Console.Write("Текущий массив ");
            for (int i = 0; i < E; i++)
            {
                Console.Write(" {0} ", MasT2[i]);
            }
            Console.WriteLine();
            max2 = MasT2.Max();
            min2 = MasT2.Min();
            for (int i = 0; i < E; i++)
            {
                if (MasT2[i] == max2) MasT2[i] = min2;
                else if (MasT2[i] == min2) MasT2[i] = max2;
            }
            return MasT2;
        }
    }
}
