﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace task05.Test
{
    [TestClass]
    public class task05Tests
    {
        [TestMethod]
        public void HowManyBracketsInStr1()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(0, task05.BracketsInStr("asd()asdf_{}asdf[][]()(())"));
        }
        [TestMethod]
        public void HowManyBracketsInStr2()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(-1, task05.BracketsInStr("asd()asdf_{}asdf[])(())"));
        }
        [TestMethod]
        public void HowManyBracketsInStr3()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(0, task05.BracketsInStr("asd()asdf_{}asdf()(())"));
        }
        [TestMethod]
        public void HowManyBracketsInStr4()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(-1, task05.BracketsInStr("asdasdf_{asdf[][]()(())"));
        }
        [TestMethod]
        public void HowManyBracketsInStr5()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(0, task05.BracketsInStr("asdasdf_{}asdf[][]())"));
        }
    }
}
