﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace task04.Test
{
    [TestClass]
    public class task04Tests
    {
        [TestMethod]
        public void CheckT4_1()
        {
            pr23.task04 task04 = new pr23.task04();
            Assert.AreEqual(1, task04.Calc(3, 2, 1));
        }

        [TestMethod]
        public void CheckT4_2()
        {
            pr23.task04 task04 = new pr23.task04();
            Assert.AreEqual(17, task04.Calc(15, 2, 4));
        }

        [TestMethod]
        public void CheckT4_3()
        {
            pr23.task04 task04 = new pr23.task04();
            Assert.AreEqual(9, task04.Calc(18, 2, 3));
        }

        [TestMethod]
        public void CheckT4_4()
        {
            pr23.task04 task04 = new pr23.task04();
            Assert.AreEqual(8, task04.Calc(4.0, 2.0, 2));
        }

        [TestMethod]
        public void CheckT4_5()
        {
            pr23.task04 task04 = new pr23.task04();
            Assert.AreEqual(6, task04.Calc(9, 3, 1));
        }
    }
}
