﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace task01.Test
{
    [TestClass]
    public class task01Tests
    {
        [TestMethod]
        public void Check_proizv5_42_42()
        {
            pr23.task01 task01 = new pr23.task01();
            int[] n = { 11, 42, 42, 6, 4 };
            Assert.AreEqual(42 * 42, task01.CheckT1(n));
        }
        [TestMethod]
        public void Check_proizv5_55_22()
        {
            pr23.task01 task01 = new pr23.task01();
            int[] n2 = { 22, 55, 11, 10, 1 };
            Assert.AreEqual(22 * 55, task01.CheckT1(n2));
        }
        [TestMethod]
        public void Check_proizv5_55_11()
        {
            pr23.task01 task01 = new pr23.task01();
            int[] n3 = { 3, 7, 11, 55, 6 };
            Assert.AreEqual(55 * 11, task01.CheckT1(n3));
        }
        [TestMethod]
        public void Check_proizv5_34_11()
        {
            pr23.task01 task01 = new pr23.task01();
            int[] n4 = { 11, 1, 34, 6, 4 };
            Assert.AreEqual(34 * 11, task01.CheckT1(n4));
        }
        [TestMethod]
        public void Check_proizv5_61_21()
        {
            pr23.task01 task01 = new pr23.task01();
            int[] n5 = new int[] { 21, 3, 3, 61, 4 };
            Assert.AreEqual(61 * 21, task01.CheckT1(n5));
        }
    }
}
