﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace task03.Test
{
    [TestClass]
    public class task03Tests
    {
        [TestMethod]
        public void CheckedT3_1()
        {
            pr23.task03 task03 = new pr23.task03();
            int[] numbers = new int[] { 1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 };
            Assert.AreEqual(0, task03.CheckT3(numbers));
        }
        [TestMethod]
        public void CheckedT3_2()
        {
            pr23.task03 task03 = new pr23.task03();
            int[] numbers = new int[] { 11, 23, 32, 45, 54, 6, 71, 8, 9 };
            Assert.AreEqual(2, task03.CheckT3(numbers));
        }
        [TestMethod]
        public void CheckedT3_3()
        {
            pr23.task03 task03 = new pr23.task03();
            int[] numbers = new int[] { 17, 26, 33, 42, 56, 67, 73, 81, 9 };
            Assert.AreEqual(1, task03.CheckT3(numbers));
        }
        [TestMethod]
        public void CheckedT3_4()
        {
            pr23.task03 task03 = new pr23.task03();
            int[] numbers = new int[] { 12, 27, 32, 45, 52, 67, 71, 82, 92 };
            Assert.AreEqual(0, task03.CheckT3(numbers));
        }
        [TestMethod]
        public void CheckedT3_5()
        {
            pr23.task03 task03 = new pr23.task03();
            int[] numbers = new int[] { 11, 42, 52, 51, 33, 2, 42, 6, 4 };
            Assert.AreEqual(6, task03.CheckT3(numbers));
        }
    }
}
