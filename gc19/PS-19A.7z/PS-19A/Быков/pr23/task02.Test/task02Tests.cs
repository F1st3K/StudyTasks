﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace task02.Test
{
    [TestClass]
    public class task02Tests
    {
        [TestMethod]
        public void Check1_proizv1()
        {
            pr23.task02 task02 = new pr23.task02();
            int[] n = { 11, 42, 42, 6, 4 };
            Assert.AreEqual(4 * 6, task02.CheckT2(n));
        }
        [TestMethod]
        public void Check1_proizv2()
        {
            pr23.task02 task02 = new pr23.task02();
            int[] n2 = { 22, 55, 11, 10, 1 };
            Assert.AreEqual(10 * 1, task02.CheckT2(n2));
        }
        [TestMethod]
        public void Check1_proizv3()
        {
            pr23.task02 task02 = new pr23.task02();
            int[] n3 = { 3, 7, 11, 55, 6 };
            Assert.AreEqual(3 * 6, task02.CheckT2(n3));
        }
        [TestMethod]
        public void Check1_proizv4()
        {
            pr23.task02 task02 = new pr23.task02();
            int[] n4 = { 11, 1, 34, 6, 4 };
            Assert.AreEqual(4 * 1, task02.CheckT2(n4));
        }
        [TestMethod]
        public void Check1_proizv5()
        {
            pr23.task02 task02 = new pr23.task02();
            int[] n5 = new int[] { 21, 3, 3, 61, 4 };
            Assert.AreEqual(3 * 3, task02.CheckT2(n5));
        }
    }
}

