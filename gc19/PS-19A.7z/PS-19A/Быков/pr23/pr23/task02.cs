﻿// С некоторого момента прошло N недель (N > 0). Сколько полных дней прошло за этот период?
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr23
{
    /// <summary>
    /// 2. Ввести пять различных ненулевых целых чисел. Найти произведение двух наименьших чисел.
    /// </summary>
    public class task02
    {
        /// <returns>
        /// Произведение 2-х наименьших.
        /// </returns>
        public int CheckT2(int[] v)
        {
            Array.Sort(v);
            return v[1] * v[0];
        }
    }
}
