﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr23
{
    /// <summary>
    /// 3. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти и вывести количество элементов, 
    /// расположенных после самого последнего максимального элемента.
    /// </summary>
    public class task03
    {
        /// <returns>
        /// Чисел после последнего.
        /// </returns>
        public int CheckT3(int[] n)
        {
            int result = n.Max();
            int count = 0;
            int p = 0;
            for (int i = 0; i < n.Length; i++)
            {
                if (p == 1)
                {
                    count += 1;
                }
                if(n[i] == result)
                {
                    count = 0;
                    p = 1;
                }
            }
            return count;
        }
    }
}
