﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr23
{
    public class task05
    {
        /// <returns>
        /// Чисел после последнего.
        /// </returns>
        public int CheckT5(string Str)
        {
            int count = 0;
            for (int i = 0; i < Str.Length; i++)
            {
                if (Str[i] == 'q') count++;
                else if (Str[i] == 'w') count++;
                else if (Str[i] == 'e') count++;
                else if (Str[i] == 'r') count++;
                else if (Str[i] == 't') count++;
                else if (Str[i] == 'y') count++;
                else if (Str[i] == 'u') count++;
                else if (Str[i] == 'i') count++;
                else if (Str[i] == 'o') count++;
                else if (Str[i] == 'p') count++;
                else if (Str[i] == 'l') count++;
                else if (Str[i] == 'k') count++;
                else if (Str[i] == 'j') count++;
                else if (Str[i] == 'h') count++;
                else if (Str[i] == 'g') count++;
                else if (Str[i] == 'f') count++;
                else if (Str[i] == 'd') count++;
                else if (Str[i] == 's') count++;
                else if (Str[i] == 'a') count++;
                else if (Str[i] == 'z') count++;
                else if (Str[i] == 'x') count++;
                else if (Str[i] == 'c') count++;
                else if (Str[i] == 'v') count++;
                else if (Str[i] == 'b') count++;
                else if (Str[i] == 'n') count++;
                else if (Str[i] == 'm') count++;
            }
            return count;
        }
    }
}
