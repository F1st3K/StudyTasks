﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr23
{
    /// <summary>
    /// 1. Из пяти введенных целых положительных чисел найти два наибольших и вывести произведение этих двух 
    /// наибольших чисел.
    /// Код выполняфющий задание
    /// </summary>
    public class task01
    {
        /// <returns>
        /// Произведение двух наибольших
        /// </returns>
        public int CheckT1(int[] n)
        {
            Array.Sort(n);
            return n[4] * n[3];
        }
    }
}
