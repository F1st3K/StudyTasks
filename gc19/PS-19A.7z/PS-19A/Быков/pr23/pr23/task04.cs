﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace pr23
{
    /// <summary>
    /// Написать функцию double Calc(A, B, Op) вещественного типа, выполняющую над ненулевыми вещественными числами 
    /// A и B одну из арифметических операций и возвращающую ее результат. Вид операции определяется целым 
    /// параметром Op: 1 — вычитание, 2 — умножение, 3 — деление, 4 — сложение.
    /// </summary>
    public class task04
    {
        /// <returns>
        /// Операции над числами.
        /// </returns>
        public double Calc(double A, double B, int Op)
        {
            if (Op == 1)
            {
                return A - B;
            }
            else if (Op == 2)
            {
                return A * B;
            }
            else if (Op == 3)
            {
                return A / B;
            }
            else if (Op == 4)
            {
                return A + B;
            }
            return 0;
        }
    }
}
