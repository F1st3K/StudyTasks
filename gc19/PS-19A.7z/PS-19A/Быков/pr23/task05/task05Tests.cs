﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace task05
{
    [TestClass]
    public class task05Tests
    {
        [TestMethod]
        public void CheckT5_1()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(14, task05.CheckT5("kjwdhfhwekhjfh"));
        }

        [TestMethod]
        public void CheckT5_2()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(0, task05.CheckT5("234"));
        }

        [TestMethod]
        public void CheckT5_3()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(0, task05.CheckT5(""));
        }

        [TestMethod]
        public void CheckT5_4()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(13, task05.CheckT5("'/.;],;sjfkpwoijfhiu4987"));
        }

        [TestMethod]
        public void CheckT5_5()
        {
            pr23.task05 task05 = new pr23.task05();
            Assert.AreEqual(1, task05.CheckT5("a2@$@^%"));
        }
    }
}
