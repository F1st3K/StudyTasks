package main

// ВАРИАНТ № А5/Б41
// 1. Дано количество часов, минут и секунд (1 час = 60 минут, 1 минута = 60 секунд). Вычислить и вывести общее количество секунд.
// 2. Задано целое положительное четырехзначное число N (N > 0). Найти разницу между суммой всех его цифр и произведением четных цифр.
// 3. Проверить истинность высказывания: "Сумма двух первых цифр данного четырехзначного целого положительного числа равна сумме двух
// его последних цифр".
// 4. Дан набор, состоящий из пяти целых ненулевых чисел. Найти количество положительных чисел в этом наборе.
// 5. В восточном календаре принят 60-летний цикл, состоящий из 12-летних подциклов, обозначаемых названиями цвета: зеленый, красный,
// желтый, белый и черный. В каждом подцикле годы носят названия животных: крысы, коровы, тигра, зайца, дракона, змеи, лошади, овцы,
// обезьяны, курицы, собаки и свиньи. По номеру года определить его название, если 1984 год - начало цикла: «год зеленой крысы».

import (
	"fmt"
)

func main() {
	//Task01
	{
		fmt.Println("Задание 1")
		var (
			hour int
			min  int
			sec  int
		)
		fmt.Println("Введите кол-во часов")
		fmt.Scan(&hour)
		fmt.Println("Введите кол-во минут")
		fmt.Scan(&min)
		fmt.Println("Введите кол-во секунд")
		fmt.Scan(&sec)
		sec = hour*3600 + min*60 + sec
		fmt.Println("Всего секунд ", sec)
	}

	//Task02
	{
		fmt.Println("\nЗадание 2")
		var (
			Num    int
			Sum    int
			Proizv int
			con    int
		)

		con = 0
		Proizv = 1
	m1:
		fmt.Println("Введите 4-хзначное число")
		fmt.Scan(&Num)
		if Num < 10000 && Num > 999 {
			var (
				N1 int
				N2 int
				N3 int
				N4 int
			)

			N1 = Num / 1000
			N2 = Num/100 - N1*10
			N3 = Num/10 - N1*100 - N2*10
			N4 = Num - N1*1000 - N2*100 - N3*10
			Sum = N1 + N2 + N3 + N4
			if N1%2 == 0 {
				Proizv *= N1
				con = 1
			}
			if N2%2 == 0 {
				Proizv *= N1
				con = 1
			}
			if N3%2 == 0 {
				Proizv *= N1
				con = 1
			}
			if N4%2 == 0 {
				Proizv *= N1
				con = 1
			}
			if con == 0 {
				Proizv = 0
			}
			fmt.Printf("\nСумма всех элементов числа: %d \n Произведение чётных элементов числа: %d\n", Sum, Proizv)
		} else {
			fmt.Println("Число не 4-хзначное")
			goto m1
		}
	}

	//Task03
	{
		fmt.Println("\nЗадание 3")
		var Num int
	m2:
		fmt.Println("Введите 4-хзначное число")
		fmt.Scan(&Num)
		if Num < 10000 && Num > 999 {
			var (
				N1 int
				N2 int
				N3 int
				N4 int
			)

			N1 = Num / 1000
			N2 = Num/100 - N1*10
			N3 = Num/10 - N1*100 - N2*10
			N4 = Num - N1*1000 - N2*100 - N3*10
			if N1+N2 == N3+N4 {
				fmt.Println("Сумма 2-х перых элементов числа равна сумме 2-х последних")
			} else {
				fmt.Println("Сумма 2-х перых элементов числа не равна сумме 2-х последних")
			}

		} else {
			fmt.Println("Число не 4-хзначное")
			goto m2
		}
	}

	//Task04
	{
		fmt.Println("\nЗадание 4")
		var N1 int
		var N2 int
		var N3 int
		var N4 int
		var N5 int
		var con int
		con = 0
	m3:
		fmt.Println("Введите 1 число")
		fmt.Scan(&N1)
		fmt.Println("Введите 2 число")
		fmt.Scan(&N2)
		fmt.Println("Введите 3 число")
		fmt.Scan(&N3)
		fmt.Println("Введите 4 число")
		fmt.Scan(&N4)
		fmt.Println("Введите 5 число")
		fmt.Scan(&N5)
		if N1 != 0 && N2 != 0 && N3 != 0 && N4 != 0 && N5 != 0 {
			if N1 > 0 {
				con++
			}
			if N2 > 0 {
				con++
			}
			if N3 > 0 {
				con++
			}
			if N4 > 0 {
				con++
			}
			if N5 > 0 {
				con++
			}
			fmt.Println("Положительных чисел введено: ", con)
		} else {
			fmt.Println("Числа не должны равняться нулю")
			goto m3
		}
	}

	//Task05
	{
		fmt.Println("\nЗадание 5")
		fmt.Println("Введите год")
		var (
			year   int
			pcikl  int
			cikl   int
			otkl   int
			itotkl int
			color  string
			animal string
		)

		fmt.Scan(&year)
		otkl = 0
		if year >= 60 {
			otkl = year / 12
			year = year - (year/60)*60
		}

		if year < 12 {
			pcikl = 0
		} else {
			pcikl = year / 12
		}
		itotkl = pcikl - otkl
		if itotkl < 0 {
			itotkl *= -1
		}
		if itotkl > 17 {
			for i := 0; itotkl > 17; i++ {
				itotkl -= 18
			}
		}

		if itotkl > 9 {
			itotkl /= 2
			if itotkl == 1 {
				itotkl = 8
			} else if itotkl == 0 {
				itotkl = 9
			} else if itotkl == 2 {
				itotkl = 7
			} else if itotkl == 3 {
				itotkl = 6
			} else if itotkl == 4 {
				itotkl = 5
			} else if itotkl == 5 {
				itotkl = 4
			} else if itotkl == 6 {
				itotkl = 3
			} else if itotkl == 7 {
				itotkl = 2
			} else if itotkl == 8 {
				itotkl = 1
			} else if itotkl == 9 {
				itotkl = 0
			}
		}
		itotkl++

		switch itotkl {
		case 0:
			color = " бел"
		case 1:
			color = " бел"
		case 2:
			color = " черн"
		case 3:
			color = " черн"
		case 4:
			color = " зелён"
		case 5:
			color = " зелён"
		case 6:
			color = " красн"
		case 7:
			color = " красн"
		case 8:
			color = " желт"
		case 9:
			color = " желт"
		}

		cikl = year - (year/12)*12

		switch cikl {
		case 0:
			animal = " обезьяны"
		case 1:
			animal = " курицы"
		case 2:
			animal = " собаки"
		case 3:
			animal = " свиньи"
		case 4:
			animal = " крысы"
		case 5:
			animal = " коровы"
		case 6:
			animal = " тигра"
		case 7:
			animal = " зайца"
		case 8:
			animal = " дракона"
		case 9:
			animal = " змеи"
		case 10:
			animal = " лошади"
		case 11:
			animal = " овцы"
		}

		if (animal == " дракона") && (animal == " тигра") {
			color += "ого"
		} else {
			color += "ой"
		}

		fmt.Printf("\n%d: год%s%s", year, color, animal)
	}
}
