package var5;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Arrays;

// ВАРИАНТ № 5
// 1. Проверить истинность высказывания: "Среди трех данных целых положительны чисел введенных с клавиатуры, есть хотя бы
// одна пара совпадающих".
// 2. Ввести два ненулевых положительных целых числа. Найти и вывести на экран их сумму, разность, произведение и частное.
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти сумму и произведение всех четных чисел из данного массива.
// 4. Вводится строка. Длина строки может быть разной. Подсчитать количество содержащихся в этой строке чисел (от 0 до 9).
// Вычислить и вывести сумму этих чисел.
// 5. Вводится строка, содержащая цифры (от 0 до 9) и строчные латинские буквы. Длина строки может быть разной. Если цифры в
// строке упорядочены по возрастанию, то вывести число 0; в противном случае вывести номер первого символа строки, нарушающего порядок

public class Main {

    public static void main(String[] args) {

        //region task01
        try {
            Scanner sc = new Scanner(System.in);
            int I1 = 0;
            int I2 = 0;
            int I3 = 0;
            System.out.println("Задание 1");
            System.out.println("Введите первое число");
            I1 = sc.nextInt();
            System.out.println("Введите второе число");
            I2 = sc.nextInt();
            System.out.println("Введите третье число");
            I3 = sc.nextInt();
            if (I1 == I2 || I1 == I3 || I2 == I3) {
                System.out.println("Некоторые числа совпадают");
            }
            else {
                System.out.println("Нет совпадающих чисел");
            }
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("Число выходит за грaницы массива");
        }
        catch (InputMismatchException ex) {
            System.out.println("Неверный формат или слишком длинное число");
        }
        //endregion

        //region task02
        try
        {
            System.out.println("\nЗадание 2");
            System.out.println("Введите первое число");
            Scanner sc = new Scanner(System.in);
            float e1 = sc.nextFloat();
            float e2 = sc.nextFloat();
            System.out.println("Функции над числами: произведение = " + (e1 * e2) + ", деление(1 На 2) = " + (e1/e2) + ", разность(1 на 2) = " + (e1-e2) + ", сумма = " + (e1+e2));
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("Число выходит за грaницы массива");
        }
        catch (InputMismatchException ex) {
            System.out.println("Неверный формат или слишком длинное число");
        }
        //endregion

        //region task03
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("\nЗадание 3\n");
            System.out.print("Кол-во жлементов массива\n");
            int B = sc.nextInt();
            int Sum = 0;
            int Pr = 1;
            int ct = 0;
            int[] Mas = new int[B];
            for (int i = 0; i < B; i++) {
                System.out.print("Введите " + (i+1) + " элемент массива\n");
                Mas[i] = sc.nextInt();
                if (Mas[i] % 2 == 0)
                {
                    Sum += Mas[i];
                    Pr *= Mas[i];
                    ct = 1;
                }
            }
            if (ct == 0) Pr = 0;
            System.out.print("Произведение = " + Pr + " и сумма = " + Sum + " четных чисел массива\n");


        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion

        //region task04
        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("\nЗадание 4\n");
            System.out.print("Введите строку\n");
            String Str = sc.next();
            char FF = Str.charAt(1);
            int Sum = 0;
            for (int i = 0; i < Str.length(); i++)
            {
                if (Str.charAt(i) == '1') Sum += 1;
                else if (Str.charAt(i) == '2') Sum += 2;
                else if (Str.charAt(i) == '3') Sum += 3;
                else if (Str.charAt(i) == '4') Sum += 4;
                else if (Str.charAt(i) == '5') Sum += 5;
                else if (Str.charAt(i) == '6') Sum += 6;
                else if (Str.charAt(i) == '7') Sum += 7;
                else if (Str.charAt(i) == '8') Sum += 8;
                else if (Str.charAt(i) == '9') Sum += 9;
            }
            System.out.print("Сумма чётных = " + Sum + "\n");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        catch (Exception ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion
    }
}
