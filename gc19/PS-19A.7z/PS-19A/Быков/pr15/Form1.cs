﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace pr15
{
    
    public partial class pr15 : Form
    {
        double[] Tk1 = { 0, 0, 0, 0, 0 };
        public pr15()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Tk1[0] = Convert.ToDouble(textBox1.Text);
                Tk1[1] = Convert.ToDouble(textBox2.Text);
                Tk1[2] = Convert.ToDouble(textBox3.Text);
                Tk1[3] = Convert.ToDouble(textBox4.Text);
                Tk1[4] = Convert.ToDouble(textBox5.Text); 
            }
            catch (FormatException ex11)
            {
                textBox6.Text = "Неверный формат";
            }
            catch (OverflowException ex12)
            {
                textBox6.Text = "Выход за пределы массива";
            }

            Double maxValue = Tk1.Max();
            Array.Sort(Tk1);

            textBox6.Text = Convert.ToString(Tk1[4] + " и " + Tk1[3] + " - наибольшие числа");
        }

        int A;
        int B;
        
        private void button2_Click(object sender, EventArgs e)
        {
            int C = 1;
            try
            {
            m1:
                A = Convert.ToInt32(textBox7.Text);
                B = Convert.ToInt32(textBox8.Text);
                if (A >= B)
                {
                    textBox9.Text = "A должно быть меньше B";
                    goto m1;
                }
            }
            catch (FormatException T22)
            {
                textBox9.Text = "Неверный формат";
            }
            catch (OverflowException T23)
            {
                textBox9.Text = "Выход за пределы массива";
            }
            for (int i = 1; A + i < B; i++ )
            {
                C *= A + i;
            }
            textBox9.Text = Convert.ToString(C);
        }
    }
}
