﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr20
{
    class Task04
    {
        public int Ex = 0;
        public string Str = "";
        public int ErrNum = 0;
        public int CL = 1;
        public int check = 0;

        public void Read()
        {
            try
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Задание 4");
                Console.WriteLine("Введите строку");
                Str = Convert.ToString(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Ex = 1;
                Console.WriteLine(ex.Message);
            }
        }

        public void Write()
        {
            for (int i = 0; i < Str.Length; i++)
            {
                Str = Str.ToLower();
                if (Str[i] == '0' || Str[i] == '1' || Str[i] == '2' || Str[i] == '3' || Str[i] == '4' || Str[i] == '5' || Str[i] == '6' || Str[i] == '7' || Str[i] == '8' || Str[i] == '9') continue;
                else
                {
                    if (CL == 1)
                    {
                        if (Str[i] != 'a')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 2;
                        if (check == 1) break;
                    }
                    else if (CL == 2)
                    {
                        if (Str[i] != 'b')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 3;
                        if (check == 1) break;
                    }
                    else if (CL == 3)
                    {
                        if (Str[i] != 'c')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 4;
                        if (check == 1) break;
                    }
                    else if (CL == 4)
                    {
                        if (Str[i] != 'd')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 5;
                        if (check == 1) break;
                    }
                    else if (CL == 5)
                    {
                        if (Str[i] != 'e')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 6;
                        if (check == 1) break;
                    }
                    else if (CL == 6)
                    {
                        if (Str[i] != 'f')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 7;
                        if (check == 1) break;
                    }
                    else if (CL == 7)
                    {
                        if (Str[i] != 'g')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 8;
                        if (check == 1) break;
                    }
                    else if (CL == 8)
                    {
                        if (Str[i] != 'h')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 9;
                        if (check == 1) break;
                    }
                    else if (CL == 9)
                    {
                        if (Str[i] != 'i')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 10;
                        if (check == 1) break;
                    }
                    else if (CL == 10)
                    {
                        if (Str[i] != 'j')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 11;
                        if (check == 1) break;
                    }
                    else if (CL == 11)
                    {
                        if (Str[i] != 'k')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 12;
                        if (check == 1) break;
                    }
                    else if (CL == 12)
                    {
                        if (Str[i] != 'l')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 13;
                        if (check == 1) break;
                    }
                    else if (CL == 13)
                    {
                        if (Str[i] != 'm')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 14;
                        if (check == 1) break;
                    }
                    else if (CL == 14)
                    {
                        if (Str[i] != 'n')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 15;
                        if (check == 1) break;
                    }
                    else if (CL == 15)
                    {
                        if (Str[i] != 'o')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 16;
                        if (check == 1) break;
                    }
                    else if (CL == 16)
                    {
                        if (Str[i] != 'p')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 17;
                        if (check == 1) break;
                    }
                    else if (CL == 17)
                    {
                        if (Str[i] != 'q')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 18;
                        if (check == 1) break;
                    }
                    else if (CL == 18)
                    {
                        if (Str[i] != 'r')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 19;
                        if (check == 1) break;
                    }
                    else if (CL == 19)
                    {
                        if (Str[i] != 's')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 20;
                        if (check == 1) break;
                    }
                    else if (CL == 20)
                    {
                        if (Str[i] != 't')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 21;
                        if (check == 1) break;
                    }
                    else if (CL == 21)
                    {
                        if (Str[i] != 'u')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 22;
                        if (check == 1) break;
                    }
                    else if (CL == 22)
                    {
                        if (Str[i] != 'v')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 23;
                        if (check == 1) break;
                    }
                    else if (CL == 23)
                    {
                        if (Str[i] != 'w')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 24;
                        if (check == 1) break;
                    }
                    else if (CL == 24)
                    {
                        if (Str[i] != 'x')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 25;
                        if (check == 1) break;
                    }
                    else if (CL == 25)
                    {
                        if (Str[i] != 'y')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 26;
                        if (check == 1) break;
                    }
                    else if (CL == 26)
                    {
                        if (Str[i] != 'z')
                        {
                            check = 1;
                            ErrNum = i;
                        }
                        else CL = 27;
                        if (check == 1) break;
                    }
                    else if (CL == 27)
                    {
                        break;
                    }
                }
            }
        }

        public void Output()
        {
            if (check == 1)
            {
                Console.WriteLine("Номер " + (ErrNum+1) + " прерывает алфавитную последовательность");
            }
            else if (CL != 27)
            {
                Console.WriteLine("Последовательность прервалась на " + CL + " числе последовательности");
            }
            else
            {
                Console.WriteLine("Введённая последовательность прошла алфавитный порядок(0)");
            }
        }
    }
}
