﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr20
{
    class Task03
    {
        public int Ex = 0;
        public int N = 0;
        public int[] Mas;
        public int Max = 0;
        public int Min = 0;
        public int Start = 0;
        public int End = 0;
        public int coin = 0;
        public int ret = 0;

        public void Read()
        {
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 3");
                Console.WriteLine("Введите количество элементов в массиве");
                N = Convert.ToInt32(Console.ReadLine());
                Mas = new int[N];
                for (int i = 0; i < N; i++)
                {
                    Console.Write("Введите " + (i + 1) + " элемент массива - ");
                    Mas[i] = Convert.ToInt32(Console.ReadLine());
                }
            }
            catch (Exception ex)
            {
                Ex = 1;
                Console.WriteLine(ex.Message);
            }
        }

        public void Write()
        {
            if (Ex == 0)
            {
                Max = Mas.Max();
                Min = Mas.Min();
                Console.Write("Старый массив: {");
                for (int i = 0; i < Mas.Length; i++)
                {
                    if (i + 1 == Mas.Length)
                    {
                        Console.Write(Mas[i]);
                        break;
                    }
                    Console.Write(Mas[i] + " ");
                }
                Console.WriteLine("}");
                for (int i = 0; i < Mas.Length; i++)
                {
                    if (Min == Mas[i] & coin == 0)
                    {
                        coin = 1;
                        Start = i;
                    }
                    if (Max == Mas[i])
                    {
                        End = i;
                    }
                }
                if (End < Start)
                {
                    coin = 0;
                    for (int i = 0; i < Mas.Length; i++)
                    {
                        if (Max == Mas[i] & coin == 0)
                        {
                            coin = 1;
                            Start = i;
                        }
                        if (Min == Mas[i])
                        {
                            End = i;
                        }
                    }
                }
                int Middle = (End - Start) / 2;
                Start++;
                int Save = 0;
                for (int i = Start; i < End; i++)
                {
                    if (i != Start + Middle)
                    {
                        Save = Mas[End - 1];
                        Mas[End - 1] = Mas[i];
                        Mas[i] = Save;
                    }
                    End--;
                }
            }
        }

        public void Output()
        {
            if (Ex == 0)
            {
                Console.Write("Новый массив:  {");
                for (int i = 0; i < Mas.Length; i++)
                {
                    if (i + 1 == Mas.Length)
                    {
                        Console.Write(Mas[i]);
                        break;
                    }
                    Console.Write(Mas[i] + " ");
                }
                Console.Write("}");
            }
        }
    }
}
