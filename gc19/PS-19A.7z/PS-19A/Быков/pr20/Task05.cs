﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr20
{
    class Task05
    {
        public string Str = "";
        public int Ex = 0;
        public int Sum = 0;

        public void Read()
        {
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 5");
                Console.WriteLine("Введите строку");
                Str = Convert.ToString(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Ex = 1;
                Console.WriteLine(ex.Message);
            }
        }

        public void Write()
        {
            for (int i = 0; i < Str.Length; i++)
            {
                if (Str[i] == '2') Sum += 2;
                if (Str[i] == '4') Sum += 4;
                if (Str[i] == '6') Sum += 6;
                if (Str[i] == '8') Sum += 8;
            }
        }

        public void Output()
        {
            Console.WriteLine("Сумма всех чётных чисел = " + Sum);
        }
    }
}
