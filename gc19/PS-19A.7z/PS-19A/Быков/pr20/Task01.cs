﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr20
{
    class Task01
    {
        public int Perv;
        public int Vtor;
        public int Tret;
        public int Sot = 0;

        public void Read()
        {
    BackToTheBeginning:
            try 
            {
                Console.WriteLine("Задание 1");
                Console.WriteLine("Введите 3-хзначное число");
                Sot = Convert.ToInt32(Console.ReadLine());
                if (Sot < 100 || Sot > 999)
                {
                    goto BackToTheBeginning;
                }
            }
            catch (Exception ex)
            {
                Sot = 0;
                Console.WriteLine(ex.Message);
            }
        }

        public void Write()
        {
            if (Sot == 0)
            {
                goto EndWrite;
            }
            Perv = Sot / 100;
            Vtor = Sot / 10 - Perv * 10;
            Tret = Sot - Vtor * 10 - Perv * 100;
    EndWrite:
            ;
        }

        public void Output()
        {
            if (Sot == 0)
            {
                goto EndOutput;
            }
            if ((Perv + Vtor + Tret) % 2 == 0)
            {
                Console.WriteLine("Сумма цифр трёхзначного числа является Чётной");
            }
            else
            {
                Console.WriteLine("Сумма цифр трёхзначного числа является Нечётной");
            }
    EndOutput:
            ;
        }
    }
}
