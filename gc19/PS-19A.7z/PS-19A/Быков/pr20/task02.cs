﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr20
{
    class Task02
    {
        public int Hour = 0;
        public int Min = 0;
        public int Sec = 0;
        public int Ex = 0;
        public int AllInSec;

        public void Read()
        {
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 2");
                Console.Write("Введите часы ");
                Hour = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите минуты ");
                Min = Convert.ToInt32(Console.ReadLine());
                Console.Write("Введите секунды ");
                Sec = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Ex = 1;
                Console.WriteLine(ex.Message);
            }
        }

        public void Write()
        {
            if (Ex == 0)
            {
                AllInSec = Sec + Hour * 3600 + Min * 60;
            }
        }

        public void Output()
        {
            if (Ex == 0)
            {
                Console.WriteLine("Это время переведённое в секунды = " + AllInSec);
            }
        }
    }
}
