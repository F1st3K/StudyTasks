﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace poop
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Task01
            try
            {
                Console.WriteLine("Задание 1");
                Console.WriteLine("Введите положительное четырехзначное число");
    m1st:    
                int N = Convert.ToInt32(Console.ReadLine());
                if (N < 0 || N < 1000 || N > 9999)
                {
                    Console.WriteLine("Число должно быть положительным четырехзначным");
                    goto m1st;
                }

                int n1 = N / 1000;
                int n2 = N / 100 - n1 * 10;
                int n3 = N / 10 - n1 * 100 - n2 * 10;
                int n4 = N - n1 * 1000 - n2 * 100 - n3 * 10;

                int Sum = n1 + n2 + n3 + n4;
                int Pr = n1 * n4;
                int Res = Sum - Pr;

                if (Res < 0) Res *= -1;
                Console.WriteLine("Разница между суммой всех и произведением первой и последней цифры: " + Res);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            #region Task02
            try
            {
                Console.WriteLine("\nЗадание 2");
    m2st:
                Console.WriteLine("Введите кол-во элементов в масиве");
                int E = Convert.ToInt32(Console.ReadLine());
                if (E < 0)
                {
                    Console.WriteLine("Кол-во элементов массива не может быть меньше 0");
                    goto m2st;
                }

                int[] mas = new int[E];
                int F;
                int Sec = 0;

                for (int i = 0; i < mas.Length; i++)
                {
                    Console.WriteLine("Введите " + (i+1) + " элемент массива");
                    if (i == 0) {
                        Sec = Convert.ToInt32(Console.ReadLine());
                        mas[i] = Sec;
                    }
                    else if (i != mas.Length - 1 && i != 0)
                    {
                        F = Convert.ToInt32(Console.ReadLine());
                        if (F % 2 == 0)
                        {
                            F += Sec;
                        }
                        mas[i] = F;
                    }
                    else
                    {
                        mas[i] = Convert.ToInt32(Console.ReadLine());
                    }
                    
                }

                for (int i = 0; i < mas.Length; i++)
                {
                    if (i == 0)
                    {
                        Console.Write(mas[i]);
                    }
                    else
                    {
                        Console.Write(", " + mas[i]);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            #region Task03
            try
            {
                Console.WriteLine("\n\nЗадание 3");
                Console.WriteLine("Введите сторону треугольника");
                double a = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Периметр треугольника " + Triangle(a));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            #region Task04
            try
            {
                Console.WriteLine("\nЗадание 4");
                Console.WriteLine("Введите строку");
                string Str = Console.ReadLine() + " ";
                string word = "";
                int s;
                int e = 0;
                int con = 0;
                Console.Write("Слова с 1 'h': ");
                bool Wh = false;

                for (int i = 0; i < Str.Length; i++)
                {
                    if (Str[i] == '_' || i == 0 || i == Str.Length - 1)
                    {
                        s = i;
                        for (int j = i+1; j < Str.Length; j++)
                        {
                            if (Str[j] == '_' || j == 0 || j == Str.Length - 1)
                            {
                                e = j;
                                break;
                            }
                            else e = 0;
                        }
                        if (e != 0)
                        {
                            for (s = s; s < e + 1; s++)
                            {
                                if (Str[s] == 'h') {
                                    con++;
                                }
                                word += Str[s];
                            }
                            if (con == 1)
                            {
                                word = word.Trim('_');
                                Console.Write(word + " ");
                                Wh = true;
                            }
                            con = 0;
                            word = "";
                        }
                    }
                    else continue;
                }
                if (Wh == false) {
                    Console.Write("отсутствуют");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            #region Task05
            try
            {
                Console.WriteLine("\n\nЗадание 5");
                Console.WriteLine("Введите целое положительное число");
                int Tr = Convert.ToInt32(Console.ReadLine());
                if (Tr % 2 == 0 && Tr > 100 && Tr < 999)
                {
                    Console.WriteLine("Число является четным трехзначным");
                }
                else
                {
                    Console.WriteLine("Число не является четным трехзначным");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            string fg = Console.ReadLine();
        }

        static double Triangle(double a)
        {
            double P = 3 * a;
            return P;
        }
    }
}
