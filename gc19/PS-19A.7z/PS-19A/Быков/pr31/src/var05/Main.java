package var05;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Arrays;

//ВАРИАНТ № А5/Б31
//1. Проверить истинность высказывания: "Данное целое положительное число является нечетным трехзначным
//числом".
//2. С некоторого момента прошло N недель (N > 0). Сколько полных дней прошло за этот период?
//3. В вещественном массиве хранятся сведения о количестве осадков, выпавших за каждый день месяца N (в
//месяце должно быть 30 дней). Определить, сколько осадков выпадало в среднем за один день в первую,
// вторую и третью декады этого месяца (декада состоит из 10 дней).
//4. Вводится строка, содержащая цифры (от 0 до 9) и строчные латинские буквы. Если буквы в строке
//упорядочены по алфавиту (abcdefghijklmnopqrstuvwxyz), то вывести число 0; в противном случае вывести номер первого
// символа строки, нарушающего алфавитный порядок.
//5. Вводится строка, содержащая латинские буквы и скобки трех видов: «()», «[]», «{}». Если скобки
//расставлены правильно (т. е. каждой открывающей соответствует закрывающая скобка того же вида), то
//вывести число 0. В противном случае вывести или номер позиции, в которой расположена первая ошибочная
//скобка, или, если закрывающих скобок не хватает, значение −1.

public class Main {

    public static void main(String[] args) {

        //region task01
        try {
            Scanner sc = new Scanner(System.in);
            int N = 0;
            System.out.print("Задание 1\n");
            System.out.print("Введите число\n");
            N = sc.nextInt();
            int er = 0;
            if (N > 99 || N < 1000) {
                if (N  % 2 == 1) ;
                else er = 1;
            }
            else er = 1;
            if (er == 0) System.out.print("Число является нечётным 3-хзначным\n");
            else System.out.print("Число не является нечётным 3-хзначным\n");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion

        //region task02
        try
        {
            Scanner sc = new Scanner(System.in);
            int[] Mas = new int[5];
            System.out.print("\nЗадание 2\n");
            System.out.print("Введите кол-во недель\n");
            int week = sc.nextInt();
            int day = week * 7;
            System.out.print("Дней: " + day + "\n");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion

        //region task03
        try {
            Scanner sc = new Scanner(System.in);
            int day1;
            System.out.print("\nЗадание 3\n");
            System.out.print("введите месяц\n");
            int month = sc.nextInt();
            double d1 = 0;
            double d2 = 0;
            double d3 = 0;
            if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) day1 = 31;
            else if (month == 4 || month == 6 || month == 9 || month == 11) day1 = 30;
            else if (month == 2) day1 = 28;
            else day1 = 50;
            if (day1 == 50)  System.out.print("Номер месяца введён не корректно\n");
            else
            {
                double[] Mas = new double[day1];
                for (int i = 0; i < day1; i++) {
                    System.out.print("Введите кол-во осадков в + " + (i+1) + " день месяца\n");
                    Mas[i] = sc.nextDouble();
                }
                for (int i = 0; i < day1; i++)
                {
                    if (i < 14)
                    {
                        d1 += Mas[i];
                    }
                    else if (i > 13 && i < 28)
                    {
                        d2 += Mas[i];
                    }
                    else d3 += Mas[i];
                }
                d1 = d1 / 14;
                d2 = d2 / 14;
                if (d3 != 0) d3 = d3 / (day1 - 28);
                System.out.print("Среднее кол-во: в 1 декаду = " + d1 + ", 2 декаду = " + d2 + ", 3 декаду = " + d3 + "\n");
            }
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion

        //region task04
        try{
            int scr = 0;
            int err = 0;
            Scanner sc = new Scanner(System.in);
            System.out.print("\nЗадание 4\n");
            System.out.print("Введите строку\n");
            String Str = sc.nextLine();
            for (int i = 0; i < Str.length(); i++)
            {
                if (Str.charAt(i) == 'a')
                {
                    if (scr == 0) scr = 1;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'b')
                {
                    if (scr == 1) scr = 2;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'c')
                {
                    if (scr == 2) scr = 3;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'd')
                {
                    if (scr == 3) scr = 4;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'e')
                {
                    if (scr == 4) scr = 5;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'f')
                {
                    if (scr == 5) scr = 6;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'g')
                {
                    if (scr == 6) scr = 7;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'h')
                {
                    if (scr == 7) scr = 8;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'i')
                {
                    if (scr == 8) scr = 9;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'j')
                {
                    if (scr == 9) scr = 10;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'k')
                {
                    if (scr == 10) scr = 11;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'l')
                {
                    if (scr == 11) scr = 12;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'm')
                {
                    if (scr == 12) scr = 13;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'n')
                {
                    if (scr == 13) scr = 14;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'o')
                {
                    if (scr == 14) scr = 15;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'p')
                {
                    if (scr == 15) scr = 16;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'q')
                {
                    if (scr == 16) scr = 17;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'r')
                {
                    if (scr == 17) scr = 18;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 's')
                {
                    if (scr == 18) scr = 19;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 't')
                {
                    if (scr == 19) scr = 20;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'u')
                {
                    if (scr == 20) scr = 21;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'v')
                {
                    if (scr == 21) scr = 22;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'w')
                {
                    if (scr == 22) scr = 23;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'x')
                {
                    if (scr == 23) scr = 24;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'y')
                {
                    if (scr == 24) scr = 25;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
                else if (Str.charAt(i) == 'z')
                {
                    if (scr == 25) scr = 26;
                    else
                    {
                        scr = 0;
                        err = i;
                    }
                }
            }
            if (scr == 26) System.out.print("Алфавит пройден\n");
            else System.out.print("Символ " + (err+1) + " обрывает последовательность");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное значение\n");
        }
        //endregion

        //region task05
        try
        {
            int ca = 0;
            int cb = 0;
            int cc = 0;
            Scanner sc = new Scanner(System.in);
            System.out.print("\nЗадание 5\n");
            System.out.print("Введите строку\n");
            String Str = sc.nextLine();
            for (int i = 0; i < Str.length(); i++)
            {
                if (Str.charAt(i) == '{') ca += 1;
                else if (Str.charAt(i) == '}') ca -= 1;
                else if (Str.charAt(i) == '[') cb += 1;
                else if (Str.charAt(i) == ']') cb -= 1;
                else if (Str.charAt(i) == '(') cc += 1;
                else if (Str.charAt(i) == ')') cc -= 1;
            }
            if (ca == 0 && cb == 0 && cc == 0) System.out.print("Все скобки закрыты");
            else System.out.print("Не все скобки закрыты");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное значение\n");
        }
        //endregion
    }
}
