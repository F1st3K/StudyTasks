﻿// ВАРИАНТ № А5/Б41
// 1. Задано целое положительное четырехзначное число N (N > 0). Найти разницу между суммой всех его цифр и произведением нечетных цифр.
// 2. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти и вывести количество элементов, расположенных после самого 
// последнего максимального элемента.
// 3. Дан массив ненулевых целых чисел, признак его завершения - число 0. Вывести на экран все положительные нечетные числа из данного 
// набора, а строкой ниже вывести их сумму. Если требуемые числа в наборе отсутствуют, то вывести значение -1.
// 4. Написать функцию double Fact2(N) вещественного типа, вычисляющую двойной факториал: N!! = 1·3·5·…·N, если N — нечетное; N!! = 2·4·6·…·N, 
// если N — четное (N > 0 — параметр целого типа; вещественное возвращаемое значение используется для того, чтобы избежать целочисленного переполнения 
// при больших значениях N). С помощью этой функции найти двойные факториалы пяти различных целых чисел.
// 5. Вводится строка, изображающая целочисленное арифметическое выражение вида «цифра_цифра_цифра_цифра», где на месте знака операции «_» находится 
// символ «+» или «-», а на месте "цифра" находится одна из цифр (от 1 до 9). Например, «4+7-2+5». Вывести значение данного выражения (как целое число).
// 6. Вводится строка, состоящая из букв и цифр. Длина строки может быть разной. Вывести на экран произведение цифр '3', '5' и '7', встречающихся в этой 
// строке.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr19
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            int N1 = 0;
            int N2 = 0;
            int N3 = 0;
            int N4 = 0;
            int N = 0;
            int Sum = 0;
            int PN = 1;
            int g = 0;
            int Rez1 = 0;

            Console.WriteLine("Задание 1");
        m10:
            Console.WriteLine("Введите 4-значное число ");
            try
            {
                N = Convert.ToInt32(Console.ReadLine());
                if (N < 999 || N > 9999)
                {
                    goto m10;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto m20;
            }
            N1 = N / 1000;
            N2 = N / 100 - N1 * 10;
            N3 = N / 10 - N1 * 100 - N2 * 10;
            N4 = N - N1 * 1000 - N2 * 100 - N3 * 10;
            Sum = N1 + N2 + N3 + N4;
            if (N1 % 2 == 0)
            {
                ;
            }
            else
            {
                PN = PN * N1;
                g = 1;
            }
            if (N2 % 2 == 0)
            {
                ;
            }
            else
            {
                PN = PN * N2;
                g = 1;
            }
            if (N3 % 2 == 0)
            {
                ;
            }
            else
            {
                PN = PN * N3;
                g = 1;
            }
            if (N4 % 2 == 0)
            {
                ;
            }
            else
            {
                PN = PN * N4;
                g = 1;
            }
            if (PN == 1 && g == 0)
            {
                PN = 0;
            }
            Rez1 = Sum - PN;
            if (Rez1 < 0)
            {
                Rez1 = Rez1 * -1;
            }
            Console.WriteLine("Разница между суммой всех и произведением нечётных = {0}", Rez1);
            #endregion
        m20:


            #region Задание 2
            int Max = 0;
            int R = 0;
            Console.WriteLine("");
            Console.WriteLine("Задание 2");
        m21:
            try
            {
                Console.WriteLine("Введите кол-во элементов в массиве");
                R = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                goto m21;
            }
            
            int[] Mas = new int[R];
            try
            {
                for (int i = 0; i < R; i++)
                {
                    Console.WriteLine("Введите {0} элемент массива", i + 1);
                    Mas[i] = Convert.ToInt32(Console.ReadLine());
                }
            }
            catch (Exception x)
            {
                Console.WriteLine(x.Message);
                goto m30;
            }
            Max = Mas.Max();
            int K = 0;
            int Num = 0;
            int D = 0;
            int F = 0;
            int T = 0;
            int[] Mas2 = {};
            for (int i = 0; i < R; i++)
            {
                if (K == 1)
                {
                    F = i;
                    D = i;
                    for (int j = 0; j <= R-F; j++)
                    {
                        D = i;
                        Num = j;
                    }
                    K = 0;
                    T = 1;
                }

                if (Mas[i] == Max)
                {
                    K = 1;
                }
                if (Num > 0)
                {
                    if (T == 1)
                    {
                        Mas2 = new int[Num];
                        for (int j = 0; j <= R - F; j++)
                        {
                            Mas2[j] = Mas[D];
                            D++;
                            Num = j;
                            T = 0;
                            if (D == R)
                            {
                                break;
                            }
                        }
                    }
                }
            }

            Console.WriteLine("Чисел после максимального элемента {0}", Num + 1);
            Console.Write("Массив чисел после максимального элемента   ");
            for (int i = 0; i <= Num; i++)
            {
                Console.Write("{0} ", Mas2[i]);
            }
                

            #endregion

        m30:
            #region Задание 5
            Console.WriteLine("");
            Console.WriteLine("Задание 5");
            Console.WriteLine("Введите строку формата «цифра_цифра_цифра_цифра», где на месте знака операции «_» находится символ «+» или «-», а на месте 'цифра' находится одна из цифр (от 1 до 9).");
            string Z5 = "";
            int Rez5 = 0;
            try
            {
                Z5 = Console.ReadLine();
            }
            catch (Exception r)
            {
                Console.WriteLine(r.Message);
                goto m6;
            }
            for (int i = 0; i < Z5.Length; i++)
            {
                if (i == 0)
                {
                    if (Z5[0] == '0') Rez5 = 0;
                    else if (Z5[0] == '1') Rez5 = 1;
                    else if (Z5[0] == '2') Rez5 = 2;
                    else if (Z5[0] == '3') Rez5 = 3;
                    else if (Z5[0] == '4') Rez5 = 4;
                    else if (Z5[0] == '5') Rez5 = 5;
                    else if (Z5[0] == '6') Rez5 = 6;
                    else if (Z5[0] == '7') Rez5 = 7;
                    else if (Z5[0] == '8') Rez5 = 8;
                    else if (Z5[0] == '9') Rez5 = 9;
                }
                if (Z5[i] == '+')
                {
                    Rez5 = Rez5 + Z5[i+1];
                }
                else if (Z5[i] == '-')
                {
                    Rez5 = Rez5 - Z5[i + 1];
                }
            }
            Console.WriteLine("Ответ: {0}", Rez5);
            #endregion

        m6:
            #region Задание 6
            int Proizv2 = 1;
            string Str = "";
            Console.WriteLine("");
            Console.WriteLine("Задание 6");
            Console.WriteLine("Введите строку");
            try
            {
                Str = Console.ReadLine();
            }
            catch (Exception t)
            {
                Console.WriteLine(t.Message);
                goto mE;
            }
            for (int i = 0; i < Str.Length; i++)
            {
                if (Str[i] == '3')
                {
                    Proizv2 = Proizv2 * 3;
                }
                else if (Str[i] == '5')
                {
                    Proizv2 = Proizv2 * 5;
                }
                else if (Str[i] == '7')
                {
                    Proizv2 = Proizv2 * 7;
                }
            }
            if (Proizv2 == 1)
            {
                Proizv2 = 0;
            }
            Console.WriteLine("Произведение '3', '5' и '7' из этой строки       {0}", Proizv2);
            #endregion

        mE:
            ;
        }
    }
}
