package com.company;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Arrays;

// ВАРИАНТ № А5/Б31
// 1. Проверить истинность высказывания: "Все цифры данного целого положительного трехзначного числа введенного
// с клавиатуры различны".
// 2. Даны пять целых ненулевых положительных чисел. Найти сумму двух наименьших чисел.
// 3. Дан размер некоторого файла в байтах (целочисленное положительное ненулевое число). Используя
// операцию деления нацело, найти количество полных килобайтов и мегабайтов, которые занимает данный файл
// (1 килобайт = 1024 байта, 1 мегабайт - 1024 килобайт).
// 4. Дано целое положительное число K в диапазоне от 1 до 7. Вывести строку - название дня недели, соответствующее
// данному числу (1 - «понедельник», 2 - «вторник», ..., 7 - «воскресенье»). Если K не лежит в диапазоне 1–7, то
// вывести строку с сообщением "Ошибка"/"Error".

public class Main {

    public static void main(String[] args) {

        //region task01
        try {
            Scanner sc = new Scanner(System.in);
            int N = 0;
            System.out.print("Задание 1\n");
            System.out.print("Введите трехзначное число\n");
            N = sc.nextInt();
            if (N > 99 || N < 1000) {
                int n1 = N / 100;
                int n2 = N / 10 - n1 * 10;
                int n3 = N - n1 * 100 - n2 * 10;
                if (n1 != n2 && n2 != n3 || n1 != n3) System.out.print("Все числа данного трёхзначного различны\n");
                else System.out.print("Число не 3-хзначное\n");
            } else {
                System.out.print("Число не является трёхзначным\n");
            }
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion

        //region task02
        try
        {
            Scanner sc = new Scanner(System.in);
            int[] Mas = new int[5];
            System.out.print("\nЗадание 2\n");
            System.out.print("Введите первое ненулевое целое число\n");
            int r1 = sc.nextInt();
            System.out.print("Введите второе ненулевое целое число\n");
            int r2 = sc.nextInt();
            System.out.print("Введите третье ненулевое целое число\n");
            int r3 = sc.nextInt();
            System.out.print("Введите четвертое ненулевое целое число\n");
            int r4 = sc.nextInt();
            System.out.print("Введите пятое ненулевое целое число\n");
            int r5 = sc.nextInt();
            if (r1 > 0 && r2 > 0 && r3 > 0 && r4 > 0 && r5 > 0) {
                Mas[0] = r1;
                Mas[1] = r2;
                Mas[2] = r3;
                Mas[3] = r4;
                Mas[4] = r5;
                Arrays.sort(Mas);
                int R1 = Mas[0];
                int R2 = Mas[1];
                int SumMin = R1 + R2;
                System.out.print("Сумма 2-х минимальных равна \n" + SumMin);
            } else System.out.print("Все числа должны быть больше 0\n");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion

        //region task03
        try {
            Scanner sc = new Scanner(System.in);
            System.out.print("\nЗадание 3\n");
            System.out.print("введите кол-во байт файла\n");
            long byt = sc.nextInt();
            long kbyt = byt / 1024;
            long mbyt = kbyt / 1024;
            System.out.print("Кол-во Килобайт файла " + kbyt + "\n");
            System.out.print("Кол-во Мегабайт файла " + mbyt + "\n");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion

        //region task04
        try{
            Scanner sc = new Scanner(System.in);
            System.out.print("\nЗадание 4\n");
            System.out.print("введите день недели\n");
            int day = sc.nextInt();
            if (day > 0 && day < 8)
                switch(day){
                    case 1: System.out.print("Понедельнк\n");
                        return;
                    case 2: System.out.print("Вторник\n");
                        return;
                    case 3: System.out.print("Среда\n");
                        return;
                    case 4: System.out.print("Четверг\n");
                        return;
                    case 5: System.out.print("Пятница\n");
                        return;
                    case 6: System.out.print("Суббота\n");
                        return;
                    case 7: System.out.print("Воскресенье\n");
                }
            else System.out.print("Ошибка/Error\n");
        }
        catch (ArrayIndexOutOfBoundsException ex) {
            System.out.print("Число выходит за грaницы массива\n");
        }
        catch (InputMismatchException ex) {
            System.out.print("Неверный формат или слишком длинное число\n");
        }
        //endregion
    }
}
