package main

import (
	"fmt"
	"strings"
)

// ВАРИАНТ № А5/Б31
//1. Дан размер некоторого файла в байтах (целочисленное положительное ненулевое пятизначное число).
//Используя операцию деления нацело, найти количество полных килобайтов и мегабайтов, которые занимает
//данный файл (1 килобайт = 1024 байта, 1 мегабайт - 1024 килобайт).
//2. Дан целочисленный массив, состоящий из N элементов (N > 0). Сложить со всеми нечетными числами
//максимальное четное число из этого массива. Вывести новый полученный массив.
//3. Вводится строка. Длина строки может быть разной. Подсчитать количество содержащихся в ней строчных
//букв латинского алфавита.
//4. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). Требуется
//удалить из этой строки повторяющиеся символы. Например, если было введено "abc_cde_defg", то должно быть
//выведено "abcdefg".

func main() {
	//task01
	{
		fmt.Println("Задение 1")
		var byte int
		var kbyte int
		var mbyte int
	m1:
		fmt.Println("Введите кол-во байт")
		_, err := fmt.Scan(&byte)

		if err != nil {
			fmt.Println(err)
			goto m1
		}
		kbyte = byte / 1024
		mbyte = kbyte / 1024
		fmt.Println("Всего мегабайт: ", mbyte, "\nВсего килобайт: ", kbyte)
	}

	//task02
	{
		fmt.Println("\nЗадение 2")
		var mas []int
	m2_1:
		fmt.Println("Введите кол-во элементов массива")
		var el int
		var f int
		_, err := fmt.Scan(&el)

		if err != nil {
			fmt.Println(err)
			goto m2_1
		}

		for i := 0; i < el; i++ {
		m1_2:
			fmt.Println("Введите ", i+1, " элемент массива")
			_, err := fmt.Scan(&f)

			if err != nil {
				fmt.Println(err)
				goto m1_2
			}
			mas = append(mas, f)
		}

		var max int
		max = mas[1]

		for i := 0; i < el; i++ {
			if max < mas[i] {
				max = mas[i]
			}
		}

		for i := 0; i < el; i++ {
			if mas[i]%2 == 1 {
				mas[i] += max
			}
		}

		fmt.Println("Получившийся массив: ", mas)
	}

	//task03
	{
		fmt.Println("\nЗаданий 3")
	m3_1:
		fmt.Println("Введите строку")
		var Str string
		con := 0
		_, err := fmt.Scan(&Str)

		if err != nil {
			fmt.Println(err)
			goto m3_1
		}
		for i := 0; i < len(Str); i++ {
			if Str[i] == 'a' {
				con++
			} else if Str[i] == 'b' {
				con++
			} else if Str[i] == 'c' {
				con++
			} else if Str[i] == 'd' {
				con++
			} else if Str[i] == 'e' {
				con++
			} else if Str[i] == 'f' {
				con++
			} else if Str[i] == 'j' {
				con++
			} else if Str[i] == 'i' {
				con++
			} else if Str[i] == 'h' {
				con++
			} else if Str[i] == 'k' {
				con++
			} else if Str[i] == 'l' {
				con++
			} else if Str[i] == 'm' {
				con++
			} else if Str[i] == 'n' {
				con++
			} else if Str[i] == 'o' {
				con++
			} else if Str[i] == 'p' {
				con++
			} else if Str[i] == 'q' {
				con++
			} else if Str[i] == 'r' {
				con++
			} else if Str[i] == 's' {
				con++
			} else if Str[i] == 't' {
				con++
			} else if Str[i] == 'u' {
				con++
			} else if Str[i] == 'v' {
				con++
			} else if Str[i] == 'w' {
				con++
			} else if Str[i] == 'x' {
				con++
			} else if Str[i] == 'y' {
				con++
			} else if Str[i] == 'z' {
				con++
			}
		}
		fmt.Println("Строчных букв латинского алфавита в ведённой строке: ", con)
	}

	//task04
	{
		fmt.Println("\nЗаданий 4")
	m4_1:
		fmt.Println("Введите строку")

		var Str string
		_, err := fmt.Scan(&Str)

		if err != nil {
			fmt.Println(err)
			goto m4_1
		}

		Slice := []rune(Str)
		Slice[0] = 'F'

		for i := 0; i < len(Str); i++ {
			for j := i + 1; j < len(Str)-1; j++ {
				if Str[i] == '_' {
					Slice[i] = ' '
				} else if Str[i] == Str[j] {
					Slice[i] = ' '
				}
			}
		}

		Str = string(Slice)
		Str = strings.TrimSpace(Str)
		fmt.Println("Эта строка без повторений: ", Str)
	}
}
