package main

import (
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"sort"
	"strconv"
	"strings"
)

// ВАРИАНТ № А5/Б41
// 1. Дано целое положительное пятизначное число N (N > 0). Используя операции деления и определения остатка от деления найти
// и вывести сумму всех его цифр.
// 2. Проверить истинность высказывания: "Квадратное уравнение A·x2 + B·x + C = 0 с данными коэффициентами A (A ≠ 0), B, C
// имеет ровно два вещественных корня".
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0). Проверить, чередуются ли в нем четные и нечетные числа.
// Если чередуются, то вывести 0, если нет, то вывести порядковый номер первого элемента, нарушающего закономерность.
// 4. Вводится строка, содержащая латинские буквы и скобки трех видов: «()», «[]», «{}». Если скобки расставлены правильно
// (т.е. каждой открывающей соответствует закрывающая скобка того же вида), то вывести число 0. В противном случае вывести
// или номер позиции, в которой расположена первая ошибочная скобка, или, если закрывающих скобок не хватает, значение −1.

func main() {
	//task01
	{
		fmt.Println("Задение 1")
		var (
			N  int
			n1 int
			n2 int
			n3 int
			n4 int
			n5 int
			c  []byte
		)

		fl1, err := os.Open("input1.txt")

		if err != nil {
			fmt.Println("Для 1 задания не создан файл")
			goto mn2
		}

		c, err = ioutil.ReadAll(fl1)

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn2
		}

		N, err = strconv.Atoi(string(c))

		if err != nil {
			fmt.Println("Ошибка, в файл введено не верный формат данных")
			goto mn2
		}

		fl1, err = os.OpenFile("output1.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto mn2
		}

		if (N < 1000) || (N > 9999) {
			res1 := "Число не четырёхзначное"
			io.WriteString(fl1, res1)
			goto mn2
		}

		n1 = N / 10000
		n2 = N/1000 - n1*10
		n3 = N/100 - n1*100 - n2*10
		n4 = N/10 - n1*1000 - n2*100 - n3*10
		n5 = N - n1*10000 - n2*1000 - n3*100 - n4*10

		ress := n1 + n2 + n3 + n4 + n5

		res1 := "Сумма всех чисел: " + strconv.Itoa(ress)
		io.WriteString(fl1, res1)

		fl1.Close()
	}
mn2:

	//task03
	{
		fmt.Println("\nЗадение 3")
		var (
			mas []int
			c   []byte
			dd  []string
			o   int
		)
		fl3, err := os.Open("input3.txt")

		if err != nil {
			fmt.Println("Для 3 задания не создан файл")
			goto mn4
		}

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn4
		}

		c, err = ioutil.ReadAll(fl3)

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn4
		}

		a := string(c)
		dd = strings.Split(a, " ")

		for i := 0; i < len(dd); i++ {
			o, err = strconv.Atoi(dd[i])
			if err != nil {
				fmt.Println("Ошибка формата")
				goto mn4
			}
			mas = append(mas, o)
		}

		fl3.Close()

		cc := 0

		fl3, err = os.OpenFile("output3.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto mn4
		}
		var gg int
		var ff int
		var nn int
		for i := 0; i < len(mas); i++ {

			if (mas[i]%2 == 1) && (i == 0) {
				ff++
				gg = 0
				nn = 1
			} else if (mas[i]%2 == 0) && (i == 0) {
				ff++
				gg = 1
				nn = 0
			}
			if gg == 1 && nn == 0 {
				ff++
				gg = 0
			} else if gg == 0 && nn == 1 {
				ff++
				gg = 1
			}

		}

		if cc == len(mas) {
			res2 := "Все элементы чередуются"
			io.WriteString(fl3, res2)
		} else {
			res2 := "Не все элементы чередуются"
			io.WriteString(fl3, res2)
		}

		fl3.Close()
	}

	//task04
mn4:
	{
		fmt.Println("\nЗадение 4")
		var (
			mas []string
			c   []byte
			dd  []string
		)

		fl4, err := os.Open("input4.txt")

		if err != nil {
			fmt.Println("Для 4 задания не создан файл")
			goto mn5
		}

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn5
		}

		c, err = ioutil.ReadAll(fl4)

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn5
		}

		a := string(c)
		dd = strings.Split(a, "")

		fl4.Close()

		fl4, err = os.OpenFile("output4.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto mn5
		}
		fg := 0
		fh := 0
		fj := 0
		for i := 0; i < len(mas); i++ {

			if mas[i] == "{" {
				fg++
			} else if mas[i] == "}" {
				fg--
			} else if mas[i] == "[" {
				fh++
			} else if mas[i] == "]" {
				fh--
			} else if mas[i] == "(" {
				fj++
			} else if mas[i] == ")" {
				fj--
			}

		}
		if fg == 0 && fh == 0 && fj == 0 {
			res4 := "Все скобки закрыты"
			dd = nil
			fmt.Println("", dd)
			io.WriteString(fl4, res4)
		} else {
			res4 := "Не все скобки закрыты"
			dd = nil
			fmt.Println("", dd)
			io.WriteString(fl4, res4)
		}

		fl4.Close()
	}
mn5:
}

func Min4(A int, B int, C int, D int) int {
	var sl []int
	sl = append(sl, A, B, C, D)
	sort.Ints(sl)
	return sl[0]
}
