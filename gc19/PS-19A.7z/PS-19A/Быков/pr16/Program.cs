﻿//ВАРИАНТ № А5/Б41
//1. Дано целое положительное пятизначное число N (N > 0). Используя операции деления и определения остатка от деления найти и 
//вывести сумму всех его цифр.
//2. Проверить истинность высказывания: "Квадратное уравнение A·x2 + B·x + C = 0 с данными коэффициентами A (A ≠ 0), B, C имеет 
//ровно два вещественных корня".
//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Проверить, чередуются ли в нем четные и нечетные числа. 
//Если чередуются, то вывести 0, если нет, то вывести порядковый номер первого элемента, нарушающего закономерность.
//4. Вводится строка, содержащая латинские буквы и скобки трех видов: «()», «[]», «{}». Если скобки расставлены правильно 
//(т. е. каждой открывающей соответствует закрывающая скобка того же вида), то вывести число 0. В противном случае вывести или номер позиции, 
//в которой расположена первая ошибочная скобка, или, если закрывающих скобок не хватает, значение −1.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace pr16
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            int T1 = 0;
            int T11;
            int T12;
            int T13;
            int T14;
            int T15;
            using (StreamReader sr1 = File.OpenText("Input1.txt"))
            {
                try
                {
                    string input = null;
                    input = sr1.ReadLine();
                    T1 = Convert.ToInt32(input);
                    if (T1 < 10000 || T1 > 99999)
                    {
                        using (StreamWriter writer = File.CreateText("Output1.txt"))
                        {
                            writer.WriteLine("Число не является пятизначным");
                            goto m3;
                        }
                    }
                }
                catch (Exception ex)
                {
                    using (StreamWriter writer = File.CreateText("Output1.txt"))
                    {
                        writer.WriteLine(ex.Message.ToString());
                        goto m3;
                    }
                }
            }
            T11 = T1 / 10000;
            T12 = T1 / 1000 - T11 * 10;
            T13 = T1 / 100 - T11 * 100 - T12 * 10;
            T14 = T1 / 10 - T11 * 1000 - T12 * 100 - T13 * 10;
            T15 = T1 - T11 * 10000 - T12 * 1000 - T13 * 100 - T14 * 10;
            T1 = T11 + T12 + T13 + T14 + T15;

            using (StreamWriter writer = File.CreateText("Output1.txt"))
            {
                writer.WriteLine("Задание 1");
                writer.WriteLine("Суммма всех чисел пятизначного числа = {0}", T1);
            }
            #endregion

        m3:
            #region Задание 3
            int T3;
            int p = 0;
            int n = 0;
            int z = 0;
            int r = 0;
            using (StreamReader sr3 = File.OpenText("Input3.txt"))
            {
                try
                {

                    string input = null;
                    input = sr3.ReadLine();
                    T3 = Convert.ToInt32(input);
                }
                catch (Exception ex)
                {
                    using (StreamWriter writer = File.CreateText("Output3.txt"))
                    {
                        writer.WriteLine(ex.Message.ToString());
                        goto m4;
                    }
                }
            }
            string str = T3.ToString();
            int[] T33 = new int[str.Length];
            for (int i = 0; i < str.Length; i++)
            {
                if (r == 0)
                {
                    if (Convert.ToInt32(str[i]) % 2 == 0)
                    {
                        p = 0;
                        r = 1;
                    }
                    else
                    {
                        p = 1;
                        r = 1;
                    }
                }
                if (p == 2) goto mET2;
                else if (p == 0)
                {
                    if (Convert.ToInt32(str[i]) % 2 == 0)
                    {
                        p = 1;
                    }
                    else
                    {
                        p = 2;
                        if (z == 0)
                        {
                            n = i + 1;
                            z = 0;
                        }
                    }
                }
                else if (p == 1)
                {
                    if (Convert.ToInt32(str[i]) % 2 == 0)
                    {
                        p = 2;
                        if (z == 0)
                        {
                            n = i + 1;
                            z = 0;
                        }
                    }
                    else
                    {
                        p = 0;
                    }
                }

            }
        mET2:
            if (p == 2)
            {
                using (StreamWriter writer = File.CreateText("Output3.txt"))
                {
                    writer.WriteLine("Задание 3");
                    writer.WriteLine("Чётные и нечётные не чередуются (число прерывающее чередование находится под номером {0})", n);
                }
            }
            else
            {
                using (StreamWriter writer = File.CreateText("Output3.txt"))
                {
                    writer.WriteLine("Задание 3");
                    writer.WriteLine("Чётные и нечётные чередуются");
                }
            }
            #endregion
        m4:
            #region Задание 4
            string T4 = null;
            int df1 = 0;
            int df2 = 0;
            int gf1 = 0;
            int gf2 = 0;
            int hf1 = 0;
            int hf2 = 0;
            int df11 = 0;
            int df22 = 0;
            int gf11 = 0;
            int gf22 = 0;
            int hf11 = 0;
            int hf22 = 0;
            using (StreamReader sr4 = File.OpenText("Input4.txt"))
            {
                try
                {
                    T4 = sr4.ReadLine();
                }
                catch (Exception ex)
                {
                    using (StreamWriter writer = File.CreateText("Output4.txt"))
                    {
                        writer.WriteLine(ex.Message.ToString());
                        goto m5;
                    }
                }
            }
            for (int i = 0; i < T4.Length; i++)
            {
                if (T4[i] == '{')
                {
                    df1 += 1;
                    df11 = i + 1;
                }
                else if (T4[i] == '}')
                {
                    df2 += 1;
                    df22 = i + 1;
                }
                else if (T4[i] == '(')
                {
                    gf1 += 1;
                    gf11 = i + 1;
                }
                else if (T4[i] == ')')
                {
                    gf2 += 1;
                    gf22 = i + 1;
                }
                else if (T4[i] == '[')
                {
                    hf1 += 1;
                    hf11 = i + 1;
                }
                else if (T4[i] == ']')
                {
                    hf2 += 1;
                    hf22 = i + 1;
                }
            }
                using (StreamWriter writer = File.CreateText("Output4.txt"))
                {
                    writer.WriteLine("Задание 4");
                    if (df1 == df2 && gf1 == gf2 && hf1 == hf2)
                    {
                        writer.WriteLine("0");
                    }
                    else writer.WriteLine("-1");
                    if (df1 < df2)
                    {
                        writer.WriteLine("Лишняя последняя '}' находится под номером {0}", df22);
                    }
                    else if (df2 < df1)
                    {
                        writer.WriteLine("Лишняя последняя '{' находится под номером {0}", df11);
                    }
                    if (gf1 < gf2)
                    {
                        writer.WriteLine("Лишняя последняя '(' находится под номером {0}", gf22);
                    }
                    else if (gf2 < gf1)
                    {
                        writer.WriteLine("Лишняя последняя ')' находится под номером {0}", gf11);
                    }
                    if (hf1 < hf2)
                    {
                        writer.WriteLine("Лишняя последняя '[' находится под номером {0}", hf22);
                    }
                    else if (hf2 < hf1)
                    {
                        writer.WriteLine("Лишняя последняя ']' находится под номером {0}", hf11);
                    }
                }
            #endregion
            m5:
                ;
            }
        }
    }
