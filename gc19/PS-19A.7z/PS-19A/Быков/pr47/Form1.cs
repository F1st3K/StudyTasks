﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;

namespace PR47
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connect1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(connect1);

            DataTable datatable1 = new DataTable();

           
            try
            {
                oleDbConn1.Open();
            }
            catch (OleDbException)
            {
                MessageBox.Show(
               "База данных отсутствует",
               "Ошибка",
               MessageBoxButtons.OK,
               MessageBoxIcon.Error,
               MessageBoxDefaultButton.Button1);
                exit();

                goto t1;
            }
          
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel;");

            sql1.Connection = oleDbConn1;

            try
            {
                sql1.ExecuteNonQuery();
            }
            catch(OleDbException)
            {
                MessageBox.Show(
                "В БД нету такой таблицы",
                "Ошибка",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
                exit();
                goto t1;
            }
            

            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(datatable1);

            datatable1.Columns["Surname"].ColumnName = "Фамилия";
            datatable1.Columns["Name"].ColumnName = "Имя";
            datatable1.Columns["Patronymic_name"].ColumnName = "Отчество";
            datatable1.Columns["Cabinet"].ColumnName = "Кабинет";
            datatable1.Columns["Korpus"].ColumnName = "Корпус";

            dataGridView1.DataSource = datatable1;

            dataGridView1.Columns[0].Visible = false;
t1:
            oleDbConn1.Close();
            

        }

      public void exit()
        {
            Application.Exit();
        }
        

    }
}
