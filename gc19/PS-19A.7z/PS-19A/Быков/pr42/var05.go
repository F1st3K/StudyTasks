package main

import (
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"sort"
	"strconv"
	"strings"
)

// ВАРИАНТ № А5/Б31
// 1. Дано четырехзначное целое ненулевое положительное число N (N>0). Проверить истинность высказывания: "Все цифры
// данного числа различны".
// 2. Дан целочисленный массив, состоящий из N элементов (N > 0, N может быть четным или нечетным числом). Поменять
// порядок его элементов на обратный. Вычислить и вывести сумму и произведение всех его элементов.
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0), содержащий, по крайней мере, два нуля. Вычислить
// сумму чисел из данного набора, расположенных между этими двумя нулями. Если нули идут подряд, то вывести 0. Если
// в массиве имеется только одно значение 0, то вычислить сумму всех его элементов.
// 4. Написать функцию int Min4(A, B, C, D) целого типа, возвращающую одно минимальное значение из 4-х своих аргументов
// (параметры A, B, C и D - целые числа).

func main() {
	//task01
	{
		fmt.Println("Задение 1")
		var (
			N  int
			n1 int
			n2 int
			n3 int
			n4 int
			c  []byte
		)

		fl1, err := os.Open("input1.txt")

		if err != nil {
			fmt.Println("Для 1 задания не создан файл")
			goto mn2
		}

		c, err = ioutil.ReadAll(fl1)

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn2
		}

		N, err = strconv.Atoi(string(c))

		if err != nil {
			fmt.Println("Ошибка, в файл введено не верный формат данных")
			goto mn2
		}

		fl1, err = os.OpenFile("output1.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto mn2
		}

		if (N < 1000) || (N > 9999) {
			res1 := "Число не четырёхзначное"
			io.WriteString(fl1, res1)
			goto mn2
		}

		n1 = N / 1000
		n2 = N/100 - n1*10
		n3 = N/10 - n1*100 - n2*10
		n4 = N - n1*1000 - n2*100 - n3*10

		if (n1 != n2) && (n1 != n3) && (n1 != n4) && (n2 != n3) && (n2 != n4) && (n3 != n4) {
			res1 := "Все цифры данного числа различны"
			io.WriteString(fl1, res1)
		} else {
			res1 := "Не все цифры данного числа различны"
			io.WriteString(fl1, res1)
		}

		fl1.Close()
	}

	//task02
mn2:
	{
		fmt.Println("\nЗадение 2")
		var (
			mas []int
			c   []byte
			dd  []string
			o   int
		)
		Sum := 0
		fl2, err := os.Open("input2.txt")

		if err != nil {
			fmt.Println("Для 2 задания не создан файл")
			goto mn3
		}

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn3
		}

		c, err = ioutil.ReadAll(fl2)

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn3
		}

		a := string(c)
		dd = strings.Split(a, " ")

		for i := 0; i < len(dd); i++ {
			o, err = strconv.Atoi(dd[i])
			if err != nil {
				fmt.Println("Ошибка формата")
				goto mn3
			}
			mas = append(mas, o)
		}

		fl2.Close()

		for i := 0; i < len(mas); i++ {
			Sum += mas[i]
		}

		for i, j := 0, len(mas)-1; i < j; i, j = i+1, j-1 {
			mas[i], mas[j] = mas[j], mas[i]
		}

		fl2, err = os.OpenFile("output2.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto mn3
		}

		res2 := "Получившийся массив: "

		for i := 0; i < len(mas); i++ {
			res2 += strconv.Itoa(mas[i]) + " "
		}
		res2 += "\nСумма его элементов: " + strconv.Itoa(Sum)

		io.WriteString(fl2, res2)

		fl2.Close()
	}

	//task03
mn3:
	{
		fmt.Println("\nЗадение 3")
		var (
			mas []int
			c   []byte
			dd  []string
			o   int
		)
		Sum := 0
		fl3, err := os.Open("input3.txt")

		if err != nil {
			fmt.Println("Для 3 задания не создан файл")
			goto mn4
		}

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn4
		}

		c, err = ioutil.ReadAll(fl3)

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn4
		}

		a := string(c)
		dd = strings.Split(a, " ")

		for i := 0; i < len(dd); i++ {
			o, err = strconv.Atoi(dd[i])
			if err != nil {
				fmt.Println("Ошибка формата")
				goto mn4
			}
			mas = append(mas, o)
		}

		fl3.Close()

		cc := 0
		r := 0

		fl3, err = os.OpenFile("output3.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto mn4
		}

		for i := 0; i < len(mas); i++ {

			if cc == 1 {
				Sum += mas[i]
			}

			if r < 2 {
				if mas[i] == 0 {
					if cc == 1 {
						cc = 0
						r++
					} else {
						cc = 1
						r++
					}
				}
			}

		}

		if r == 1 {
			Sum = 0
			for i := 0; i < len(mas); i++ {
				Sum += mas[i]
			}
			res2 := "Сумма всех элементов массива: " + strconv.Itoa(Sum)
			io.WriteString(fl3, res2)
		} else {
			res2 := "Искомая сумма элементов массива: " + strconv.Itoa(Sum)
			io.WriteString(fl3, res2)
		}
		fl3.Close()
	}

	//task04
mn4:
	{
		fmt.Println("\nЗадение 4")
		var (
			mas []int
			c   []byte
			dd  []string
			o   int
		)

		fl4, err := os.Open("input4.txt")

		if err != nil {
			fmt.Println("Для 4 задания не создан файл")
			goto mn5
		}

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn5
		}

		c, err = ioutil.ReadAll(fl4)

		if err != nil {
			fmt.Println("Произошла ошибка содержания файла")
			goto mn5
		}

		a := string(c)
		dd = strings.Split(a, " ")

		for i := 0; i < len(dd); i++ {
			o, err = strconv.Atoi(dd[i])
			if err != nil {
				fmt.Println("Ошибка формата")
				goto mn5
			}
			mas = append(mas, o)
		}

		fl4.Close()

		fl4, err = os.OpenFile("output4.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto mn5
		}

		if (len(mas) > 4) && (len(mas) < 1) {
			res4 := "Ошибка: должно быть 4 целых числа!"
			io.WriteString(fl4, res4)
			goto mn5
		}

		min := Min4(mas[0], mas[1], mas[2], mas[3])

		res4 := "Минимальное число: " + strconv.Itoa(min)
		io.WriteString(fl4, res4)

		fl4.Close()
	}
mn5:
}

func Min4(A int, B int, C int, D int) int {
	var sl []int
	sl = append(sl, A, B, C, D)
	sort.Ints(sl)
	return sl[0]
}
