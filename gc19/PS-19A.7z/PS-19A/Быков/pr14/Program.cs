﻿// ВАРИАНТ № А5/Б41
// 1. Проверить истинность высказывания: "Все цифры данного целого положительного пятизначного числа введенного с клавиатуры различны".
// 2. Из пяти целых различных ненулевых положительных и отрицательных чисел найти самое наименьшее число.
// 3. Вводится строка. Длина строки может быть разной. Подсчитать количество содержащихся в этой строке чисел (от 0 до 9). Вычислить и вывести сумму этих чисел.
// 4. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). Требуется удалить из этой строки повторяющиеся символы. 
// Например, если было введено "abc_cde_defg", то должно быть выведено "abcdefg".
// 5. Вводится строка, состоящая из слов разделенных точками. Длина строки может быть разной. 
// Сформировать и вывести подстроку, расположенную между третьей и четвертой точками исходной строки. Если в строке менее двух точек, то вывести всю исходную строку.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr13
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            int Ch = 0;
            int N1 = 0;
            int N2 = 0;
            int N3 = 0;
            int N4 = 0;
            int N5 = 0;
            Console.WriteLine("Задание 1");

        m101:
            Console.WriteLine("Введите целое положительное пятизначное число ");

            try
            {
                Ch = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("MESSAGE - " + ex.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("\n----------------------------------------------------------------");
            }
            if (Ch > 9999 && Ch < 100000)
            {
                N1 = Ch / 10000;
                N2 = Ch / 1000 - N1 * 10;
                N3 = Ch / 100 - N1 * 100 - N2 * 10;
                N4 = Ch / 10 - N1 * 1000 - N2 * 100 - N3 * 10;
                N5 = Ch - N1 * 10000 - N2 * 1000 - N3 * 100 - N4 * 10;
                if (N1 != N2 && N1 != N3 && N1 != N4 && N1 != N5 && N2 != N3 && N2 != N4 && N2 != N5 && N3 != N4 && N3 != N5 && N4 != N5)
                {
                    Console.WriteLine("Ни одно из чисел не повторяется");
                }
                else Console.WriteLine("Некоторые числа повторяются");
            }
            else
            {
                goto m101;
            }
            #endregion

            #region Задание 2
            Console.WriteLine("\n\nЗадание 2");
            Console.WriteLine("Введите 5 чисел через пробел");
            int[] Chet = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            int B = Chet.Min();
            Console.WriteLine("Минимальное число = " + B);

            #endregion

            #region Задание 3
            Console.WriteLine("\n\nЗадание 3");
            Console.WriteLine("Введите строку");
            string Str1 = Console.ReadLine();
            int A = Str1.Length;
            int Kolvo = 0;
            int Sum = 0;
            int i;
            for (i = 0; i < A; i++)
            {
                if (Str1[i] == '0')
                {
                    Sum += 0;
                    Kolvo++;
                }
                if (Str1[i] == '1')
                {
                    Sum += 1;
                    Kolvo++;
                }
                if (Str1[i] == '2')
                {
                    Sum += 2;
                    Kolvo++;
                }
                if (Str1[i] == '3')
                {
                    Sum += 3;
                    Kolvo++;
                }
                if (Str1[i] == '4')
                {
                    Sum += 4;
                    Kolvo++;
                }
                if (Str1[i] == '5')
                {
                    Sum += 5;
                    Kolvo++;
                }
                if (Str1[i] == '6')
                {
                    Sum += 6;
                    Kolvo++;
                }
                if (Str1[i] == '7')
                {
                    Sum += 7;
                    Kolvo++;
                }
                if (Str1[i] == '8')
                {
                    Sum += 8;
                    Kolvo++;
                }
                if (Str1[i] == '9')
                {
                    Sum += 9;
                    Kolvo++;
                }

            }
            Console.WriteLine("Кол-во чисел в строке " + Kolvo);
            Console.WriteLine("Сумма чисел в строке " + Sum);
            #endregion

            #region Задание 4
            Console.WriteLine("\n\nЗадание 4");
            Console.WriteLine("Введите строку разделённую '_'");
            string St1 = Console.ReadLine();
            string St2 = "";
            string St3;
            string St4;
            while (0 < St1.Length)
            {
                St1 = St1.Replace("_", "");
                St4 = St1.Substring(0, 1);
                St2 = St2 + St4;
                St3 = St1.Substring(0, 1);
                St1 = St1.Replace(St3, "");
            }
            Console.WriteLine("Эта строка без повторяющихся символов - {0}", St2);
            #endregion

            #region Задание 5
            Console.WriteLine("\n\nЗадание 5");
            Console.WriteLine("Введите строку разделённую '.'");
            string Hh1 = Console.ReadLine();
            string Hh2 = "";
            string Hh3 = "";
            int R = 0;
            int V = 0;
            int S = 0;
            int j = 0;
            int G = 0;
            for (i = 0; i < Hh1.Length; i++)
            {
                j = i - 1;
                Hh2 = Hh1.Substring(i, 1);
                if (Hh2 == ".")
                {
                    if (S == 3)
                    {
                        V = i - R - 1;
                        S = S + 1;
                    }
                    else
                    {
                        R = i;
                        S = S + 1;
                        G = G + 1;
                    }
                }
                if (S == 4)
                {
                    Hh3 = Hh1.Substring(R + 1, V);
                    break;
                }
            }
            if (G < 2) Console.WriteLine("{0}", Hh1);
            else if (V != 0) Console.WriteLine("{0}", Hh3);
            else Console.WriteLine("Условие в задаче не рассматривалось");
            Console.ReadLine();
            #endregion
        }
    }
}
