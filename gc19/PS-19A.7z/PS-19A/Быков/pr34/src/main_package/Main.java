package main_package;

import package_with_numbs.*;
import java.util.Scanner;


// ВАРИАНТ № А5/Б36
// 1. Из пяти введенных целых положительных чисел найти два наибольших и вывести сумму этих двух наибольших чисел.
// 2. С некоторого момента прошло N недель (N > 0). Сколько полных дней прошло за этот период?
// 6. Вводится строка. В строке могут быть любые символы. Длина строки может быть разной. Подсчитать и вывести
// количество содержащихся в этой строке цифр, а так же сумму всех этих цифр.


public class Main {

    public static void main(String[] args) {

        while (true) {
            System.out.println("\nВведите номер задания");
            System.out.println("1 - Задание 1.\n2 - Задание 2.\n6 - Задание 6.\n3 - Завершение работы.\n");
            int N;
            Scanner sc = new Scanner(System.in);
            N = sc.nextInt();

            switch (N) {
                case 1:
                {
                    int n1 = 0;
                    int n2 = 0;
                    int n3 = 0;
                    int n4 = 0;
                    int n5 = 0;
                    Scanner sc1 = new Scanner(System.in);

                    int Res01 = 0;

                    try {
                        System.out.println("\nЗадание 1");
                        System.out.print("Введите 1 число: ");
                        n1 = sc1.nextInt();
                        System.out.print("Введите 2 число: ");
                        n2 = sc1.nextInt();
                        System.out.print("Введите 3 число: ");
                        n3 = sc1.nextInt();
                        System.out.print("Введите 4 число: ");
                        n4 = sc1.nextInt();
                        System.out.print("Введите 5 число: ");
                        n5 = sc1.nextInt();

                    }
                    catch (java.util.InputMismatchException ex) {
                        System.out.println("\nОшибка формата числа.\nВозврщаемся в меню ...");
                        break;
                    }

                    Task01 z1 = new Task01();
                    System.out.println("\n Сумма двух наибольших: " + (z1.Task01(n1, n2, n3, n4, n5)));
                    break;


                }
                case 2:
                {
                    System.out.println("\nЗадание 2");
                    int Ned;
                    Scanner sc2 = new Scanner(System.in);

                    try {
                        System.out.print("Введите кол-во недель: ");
                        Ned = sc2.nextInt();
                    }
                    catch (java.util.InputMismatchException ex) {
                        System.out.println("Ошибка формата числа.\nВозврщаемся в меню ...");
                        break;
                    }

                    Task02 z2 = new Task02();
                    System.out.println("\nВсего дней прошло: " + z2.Task02(Ned));

                    try {
                        Thread.sleep(2000);
                    }
                    catch (InterruptedException ex) {
                        System.out.println(ex.getMessage());
                    }

                    break;
                }
                case 6:
                {
                    System.out.println("\nЗадание 6");
                    String Str;
                    Scanner sc3 = new Scanner(System.in);

                    try {
                        System.out.print("Введите строку: ");
                        Str = sc3.next();
                    }
                    catch (java.util.InputMismatchException ex) {
                        System.out.println("Ошибка формата числа.\nВозврщаемся в меню ...");
                        break;
                    }

                    Task06 z3 = new Task06();
                    System.out.println("Всего чисел в строке: " + z3.Con(Str) + ", их сумма: " + z3.Sum(Str));

                    try {
                        Thread.sleep(2000);
                    }
                    catch (InterruptedException ex) {
                        System.out.println(ex.getMessage());
                    }

                    break;
                }
                case 3:
                {
                    return;
                }
                default:
                {
                    break;
                }
            }

        }

    }
}
