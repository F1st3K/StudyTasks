package package_with_numbs;

public class Task06 {

    public Task06() { }

    public int Con(String Str) {
        int c = 0;
        for (int i = 0; i < Str.length(); i++) {
            if (Str.charAt(i) == '0') c++;
            else if (Str.charAt(i) == '1') c++;
            else if (Str.charAt(i) == '2') c++;
            else if (Str.charAt(i) == '3') c++;
            else if (Str.charAt(i) == '4') c++;
            else if (Str.charAt(i) == '5') c++;
            else if (Str.charAt(i) == '6') c++;
            else if (Str.charAt(i) == '7') c++;
            else if (Str.charAt(i) == '8') c++;
            else if (Str.charAt(i) == '9') c++;
        }
        return c;
    }

    public int Sum(String Str) {
        int Sum = 0;
        for (int i = 0; i < Str.length(); i++) {
            if (Str.charAt(i) == '1') Sum += 1;
            else if (Str.charAt(i) == '2') Sum += 2;
            else if (Str.charAt(i) == '3') Sum += 3;
            else if (Str.charAt(i) == '4') Sum += 4;
            else if (Str.charAt(i) == '5') Sum += 5;
            else if (Str.charAt(i) == '6') Sum += 6;
            else if (Str.charAt(i) == '7') Sum += 7;
            else if (Str.charAt(i) == '8') Sum += 8;
            else if (Str.charAt(i) == '9') Sum += 9;
        }
        return Sum;
    }
}
