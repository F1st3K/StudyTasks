package package_with_numbs;

public class Task02 {

    public int Task02(int Ned) {
        Ned *= 7;
        return Ned;
    }
}
