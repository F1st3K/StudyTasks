package package_with_numbs;

import java.lang.reflect.Array;

public class Task01 {

    public int Task01 (int n1, int n2, int n3, int n4, int n5) {
        int[] m = {n1, n2, n3, n4, n5};
        for(int i = m.length-1 ; i > 0 ; i--) {
            for (int j = 0; j < i; j++) {
                if (m[j] > m[j + 1]) {
                    int tmp = m[j];
                    m[j] = m[j + 1];
                    m[j + 1] = tmp;
                }
            }
        }
        return (m[4] + m[3]);
    }
}
