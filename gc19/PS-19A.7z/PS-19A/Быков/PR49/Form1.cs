﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR49
{
    public partial class main : Form
    {
        public main()
        {
            InitializeComponent();        
        }
        

        private void exit_func_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void add_func_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddFunc addForm = new AddFunc();
            addForm.Show();
          
        }

        private void redact_func_Click(object sender, EventArgs e)
        {
            this.Hide();
            Redact_func redactF = new Redact_func();
            redactF.Show();
        }
    }
}
