﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
namespace PR49
{
    public partial class AddFunc : Form
    {
        public AddFunc()
        {
            InitializeComponent();
        }

        private void AddFunc_Load(object sender, EventArgs e)
        {
            addrest.Enabled = false;
            // строка подключения
            string connect1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

            // создаем подключение
            OleDbConnection oleDbConn1 = new OleDbConnection(connect1);

            // создаем виртуальную таблицу
            DataTable datatable1 = new DataTable();


            try
            {
                // открываем подключение к базе
                oleDbConn1.Open();
            }
            catch (OleDbException)
            {
                MessageBox.Show(
               "Такой базы данных не существует",
               "Ошибка",
               MessageBoxButtons.OK,
               MessageBoxIcon.Error,
               MessageBoxDefaultButton.Button1);
                exit();

                goto t1;
            }

            // создаем запрос к бд
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel;");

            // привязываем запрос к коннекту
            sql1.Connection = oleDbConn1;

            try
            {
                // выполняем запрос
                sql1.ExecuteNonQuery();
            }
            catch (OleDbException)
            {
                MessageBox.Show(
                "В БД нету такой таблицы",
                "Ошибка",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
                exit();
                goto t1;
            }


            // создаем новый адаптер для манипулирования данными
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            // заполняем адаптер полученными данными из базы (файла) MS Access
            da1.Fill(datatable1);

            datatable1.Columns["Surname"].ColumnName = "Фамилия";
            datatable1.Columns["Name"].ColumnName = "Имя";
            datatable1.Columns["Patronymic_name"].ColumnName = "Отчество";
            datatable1.Columns["Cabinet"].ColumnName = "Кабинет";
            datatable1.Columns["Korpus"].ColumnName = "Корпус";

            dataGridViewBooks.DataSource = datatable1;

            dataGridViewBooks.Columns[0].Visible = false;
        t1:
            oleDbConn1.Close();
        }

        public void exit()
        {
            Application.Exit();
        }

        private void addbook_Click(object sender, EventArgs e)
        {
            //проверяем заполнение всех полей
            if (F.Text == "" || I.Text == "" || O.Text == "" || Adress.Text == "" || Num.Text == "")
            {
                MessageBox.Show("Ошибка! Заполните все поля!", "Сообщение пользователю", MessageBoxButtons.OK);
            }
            else
            {
                int id = 0;
                Random rnd = new Random();
                id = rnd.Next(8, 50000000);

                //забираем введенные значения с формы
                string Fio = F.Text.ToString();
                string Imea = I.Text.ToString();
                string Otchecsvo = O.Text.ToString();
                string Adress1 = Adress.Text.ToString();
                string NumberPass = Num.Text.ToString();


                // строка подключения к нашей БД MS Access
                string con = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

                // создаем виртуальное подключение
                OleDbConnection oleDbConn = new OleDbConnection(con);

                // открываем подключение к базе
                oleDbConn.Open();

                // создаем запрос - в нашем случае это ввод данных
                OleDbCommand sql = new OleDbCommand("INSERT INTO Uchitel (id, Surname, Name, Patronymic_name, Cabinet, Korpus) VALUES (" + id + ",'" + Fio + "','" + Imea + "', '" + Otchecsvo + "', '" + Adress1 + "'," + NumberPass + ");");

                // привязываем запрос к "конекту"
                sql.Connection = oleDbConn;

                //выполняем запрос
                sql.ExecuteNonQuery();

                // обязательно закрываем подключение к БД
                oleDbConn.Close();

                //выводим сообщение пользователю что книга в БД добавлена
                MessageBox.Show("Книга в базу добавлена", "Сообщение пользователю", MessageBoxButtons.OK);

                //обновляем нашу таблицу которая на форме с уже 
                //новой записью (отдельной функцией)
                UpdatedataGridViewBooks();

                //очищаем все поля ввода на форме после успешного 
                //добавления информации в БД
                F.Clear();
                I.Clear();
                O.Clear();
                Adress.Clear();
                Num.Clear();

                //делаем кнопку "Добавить" неактивной, т.к. операция уже 
                //совершена ровно для одной записи
                addrest.Enabled = false;
            }
        }


        public void UpdatedataGridViewBooks()
        {
            // строка подключения к нашей БД MS Access
            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

            // создаем виртуальное подключение - "коннект"
            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            // создаем "виртуальную" таблицу 
            DataTable dt1 = new DataTable();

            // открываем подключение к базе
            oleDbConn1.Open();

            // создаем запрос
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel;");

            // привязываем запрос к "конекту"
            sql1.Connection = oleDbConn1;

            //выполняем запрос
            sql1.ExecuteNonQuery();

            //создаем новый адаптер для манипулирования данными
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            //заполняем его полученными данными из базы (файла) MS Access
            da1.Fill(dt1);

            //меняем названия полей в контроле dataGridViewBooks на русские



            dt1.Columns["Surname"].ColumnName = "Фамилия";
            dt1.Columns["Name"].ColumnName = "Имя";
            dt1.Columns["Patronymic_name"].ColumnName = "Отчество";
            dt1.Columns["Cabinet"].ColumnName = "Кабинет";
            dt1.Columns["Korpus"].ColumnName = "Корпус";

            //привязываем нашу виртуальную таблицу с контрлолом 
            //на форме dataGridViewBooks
            dataGridViewBooks.DataSource = dt1;


            // обязательно закрываем подключение к БД
            oleDbConn1.Close();
        }


        private void F_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void I_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void O_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void Num_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }


        private void ex_Click(object sender, EventArgs e)
        {
            this.Hide();
            main returning = new main();
            returning.Show();
        }

        private void F_TextChanged(object sender, EventArgs e)
        {
            if ((F.Text.Length == 0) || I.Text.Length == 0 || O.Text.Length == 0 || Adress.Text.Length == 0 || Num.Text.Length == 0 || Num.Text.Length > 3)
            {
                addrest.Enabled = false;
            }
            else
            {
                addrest.Enabled = true;
            }
        }

        private void Adress_TextChanged(object sender, EventArgs e)
        {
            if ((F.Text.Length == 0) || I.Text.Length == 0 || O.Text.Length == 0 || Adress.Text.Length == 0 || Num.Text.Length == 0 || Num.Text.Length > 3)
            {
                addrest.Enabled = false;
            }
            else
            {
                addrest.Enabled = true;
            }
        }

        private void I_TextChanged(object sender, EventArgs e)
        {
            if ((F.Text.Length == 0) || I.Text.Length == 0 || O.Text.Length == 0 || Adress.Text.Length == 0 || Num.Text.Length == 0 || Num.Text.Length > 3)
            {
                addrest.Enabled = false;
            }
            else
            {
                addrest.Enabled = true;
            }
        }

        private void Num_TextChanged(object sender, EventArgs e)
        {
            if ((F.Text.Length == 0) || I.Text.Length == 0 || O.Text.Length == 0 || Adress.Text.Length == 0 || Num.Text.Length == 0 || Num.Text.Length > 3)
            {
                addrest.Enabled = false;
            }
            else
            {
                addrest.Enabled = true;
            }
        }

        private void O_TextChanged(object sender, EventArgs e)
        {
            if ((F.Text.Length == 0) || I.Text.Length == 0 || O.Text.Length == 0 || Adress.Text.Length == 0 || Num.Text.Length == 0 || Num.Text.Length > 3)
            {
                addrest.Enabled = false;
            }
            else
            {
                addrest.Enabled = true;
            }
        }

        
    }
}
