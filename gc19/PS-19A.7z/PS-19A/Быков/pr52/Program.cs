﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// ВАРИАНТ № А5/Б31
// 1. Ввести два ненулевых положительных целых числа. Найти и вывести на экран их сумму, разность, произведение и частное.
// 2. В вещественном массиве хранится информация о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году). Определить, в какие числа месяца осадков не было.
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0, N - четное число), в котором количество отрицательных элементов равно количеству положительным. Поменяйте местами первый отрицательный и первый положительный элемент массива, второй отрицательный и второй положительный и так далее.
// 4. Написать функцию int TimeToSec(H, M, S) целого типа, которая возвращает общее количество прошедших секунд исходя из 3-х своих аргументов (H - часы, M - минуты, S - секунды).
// 5. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). Длина строки может быть разной. Определить и вывести количество слов, которые содержат ровно одну букву 'h'.
// 6. Вводится строка, состоящая из букв и цифр (от 0 до 9). Длина строки может быть разной. Вывести сумму всех четных цифр встречающихся в этой строке.

namespace pr52
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            try { 
            Console.WriteLine("Задание 1");

            Console.WriteLine("Введите 1 положительное ненулевое положительное челое число");
            int z1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Введите 1 положительное ненулевое положительное челое число");
            int z2 = Convert.ToInt32(Console.ReadLine());

            int Sum = z1 + z2;
            int Razn = z1 - z2;
            if (Razn < 0) Razn *= -1;
            int Proizv = z1 * z2;
            double Del = z1 / z2;

            Console.WriteLine("Сумма чисел " + Sum + "\nРазность: " + Razn + "\nПроизведение: " + Proizv + "\nДеление 1-ого на 2-ое(без остатка): " + Del);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            #region Задание 2
            try { 
            Console.WriteLine("\nЗадание 2");
            Console.WriteLine("Введите номер месяца");
            int n3 = Convert.ToInt32(Console.ReadLine());

            if (n3 < 0 || n3 > 12)
            {
                Console.WriteLine("Введен несуществующий месяц");
                goto me3;
            }

            if (n3 == 1 || n3 == 3 || n3 == 5 || n3 == 7 || n3 == 8 || n3 == 10 || n3 == 12) n3 = 31;
            else if (n3 == 4 || n3 == 6 || n3 == 9 || n3 == 11) n3 = 30;
            else n3 = 28;

            int[] mas3 = new int[n3];
            int j = 0;

            for (int i = 0; i < mas3.Length; i++)
            {
            m3n:
                try
                {
                    Console.WriteLine("Введите " + (i + 1) + " день месяца");
                    mas3[i] = Convert.ToInt32(Console.ReadLine());
                    if (mas3[i] == 0) j += 1;
                }
                catch
                {
                    goto m3n;
                }
            }

            int[] ms = new int[j];
            int p = 0;

            for (int i = 0; i < mas3.Length; i++)
            {
                if (mas3[i] == 0)
                {
                    ms[p] = (i + 1);
                    p++;
                }
            }

            Console.Write("Дни месяца с нулевым кол-вом выпадения осадков: ");

            for (int i = 0; i < ms.Length; i++)
            {
                if (i == 0) Console.Write(ms[i]);
                else Console.Write(", " + ms[i]);
            }

        me3:
            ;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            #region Задание 4
            try {
            Console.WriteLine("\nЗадание 4");
            Console.WriteLine("Введите часы");

            int H = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите минуты");

            int M = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите секунды");

            int S = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Общее кол-во секунд " + TimeToSec(H, M, S));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion

            #region Задание 6
            try {
            Console.WriteLine("\nЗадание 6");
            Console.WriteLine("Введите строку");
            string Str = Console.ReadLine();

            int Dd = 0;

            for (int i = 0; i < Str.Length; i++)
            {
                if (Str[i] == '2' || Str[i] == '4' || Str[i] == '6' || Str[i] == '8') Dd += Convert.ToInt32(Str[i]);
            }

            Console.WriteLine("Сумма четных чисел строки = " + Dd);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            #endregion
        }

        public static int TimeToSec(int H, int M, int S)
        {
            S = M * 60 + H * 3600;
            return S;
        }
    }
}
