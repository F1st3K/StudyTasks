package com.company;
import java.io.*;
import java.util.Scanner;

// ВАРИАНТ № А5/Б36
// 1. Проверить истинность высказывания: "Сумма всех цифр данного целого положительного трехзначного числа является нечетным
// числом".
// 2. Ввести пять различных ненулевых целых чисел. Найти произведение двух наибольших чисел.
// 3. В вещественном массиве хранится информация о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году).
// Определить, в какие числа месяца осадков не было.
// 4. Вводится строка. Длина строки может быть разной. Подсчитать количество содержащихся в этой строке чисел (от 0 до 9).
// Вычислить и вывести сумму этих чисел.
// 5. Вводится строка, содержащая латинские буквы и скобки трех видов: «()», «[]», «{}». Если скобки расставлены правильно
// (т. е. каждой открывающей соответствует закрывающая скобка того же вида), то вывести число 0. В противном случае вывести
// или номер позиции, в которой расположена первая ошибочная скобка, или, если закрывающих скобок не хватает, значение −1.


public class Main
{
    public static void main(String[] args)
    {
        //region task01
        int e1 = 0;
        int e2 = 0;
        int Chi = 0;
        try
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("Задание 1");
            System.out.println("Введите 3-хзначное число");
            Chi = sc.nextInt();
            if (Chi > 99 && Chi < 1000)
            {
                int i1 = Chi / 100;
                int i2 = Chi / 10 - i1 * 10;
                int i3 = Chi - i1 * 100 - i2 * 10;
                if ((i1 + i2 + i3) % 2 == 1)
                {
                    System.out.println("Сумма всех цифр данного целого положительного трехзначного числа является нечетным числом");
                }
                else
                {
                    System.out.println("Сумма всех цифр данного целого положительного трехзначного числа не является нечетным числом");
                    e2 = 1;
                }
            }
            else
            {
                System.out.println("Число не является 3-хзначным");
                e1 = 1;
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        try(FileWriter writer = new FileWriter("task01_out.txt", false))
        {
            // запись всей строки
            writer.write("Задание 1\n");
            writer.write("Введённое число: " + Chi);
            if (e1 == 0 && e2 == 0) writer.write("\nСумма всех цифр данного целого положительного трехзначного числа является нечетным числом\n");
            else if (e2 == 1) writer.write("\nСумма всех цифр данного целого положительного трехзначного числа не является нечетным числом\n");
            else writer.write("\nЧисло не является 3-хзначным\n");
            System.out.println("Запись в файл выполнена");
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        //endregion

        //region task04
        String Str = "";
        int Sum = 0;
        try
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("\nЗадание 4");
            System.out.println("Введите строку");
            Str = sc.next();
            for (int i = 0; i < Str.length(); i++)
            {
                if (Str.charAt(i) == '1') Sum += 1;
                else if (Str.charAt(i) == '2') Sum += 2;
                else if (Str.charAt(i) == '3') Sum += 3;
                else if (Str.charAt(i) == '4') Sum += 4;
                else if (Str.charAt(i) == '5') Sum += 5;
                else if (Str.charAt(i) == '6') Sum += 6;
                else if (Str.charAt(i) == '7') Sum += 7;
                else if (Str.charAt(i) == '8') Sum += 8;
                else if (Str.charAt(i) == '9') Sum += 9;
            }
            System.out.println("Сумма всех чисел строки: " + Sum);
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        try(FileWriter writer = new FileWriter("task04_out.txt", false))
        {
            // запись всей строки
            writer.write("Задание 4\n");
            writer.write("Введённая строка: " + Str + "\n");
            writer.write("Сумма всех чисел в строке: " + Sum);
            System.out.println("\nЗапись в файл выполнена");
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        //endregion

        //region task05
        String Str2 = "";
        int cs = 0;
        int cf = 0;
        int cv = 0;
        try
        {
            Scanner sc = new Scanner(System.in);
            System.out.println("\nЗадание 5");
            System.out.println("Введите строку");
            Str = sc.next();
            for (int i = 0; i < Str.length(); i++)
            {
                if (Str.charAt(i) == '[') cs++;
                else if (Str.charAt(i) == ']') cs--;
                else if (Str.charAt(i) == '{') cv++;
                else if (Str.charAt(i) == '}') cv--;
                else if (Str.charAt(i) == '(') cf++;
                else if (Str.charAt(i) == ')') cf--;
            }
            if (cs == 0 && cf == 0 && cv == 0) System.out.println("Все скобки закрыты");
            else System.out.println("Не все скобки закрыты");
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        try(FileWriter writer = new FileWriter("task05_out.txt", false))
        {
            // запись всей строки
            writer.write("Задание 5\n");
            writer.write("Введённая строка: " + Str2 + "\n");
            if (cs == 0 && cf == 0 && cv == 0) writer.write("Все скобки закрыты\n");
            else writer.write("Не все скобки закрыты");
        }
        catch(IOException ex)
        {
            System.out.println(ex.getMessage());
        }
        //endregion
    }
}
