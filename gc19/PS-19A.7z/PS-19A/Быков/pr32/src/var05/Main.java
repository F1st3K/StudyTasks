package var05;
import java.util.InputMismatchException;
import java.util.*;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Collections;

// ВАРИАНТ № А5/Б41
// 1. В вещественном массиве известны данные о количестве осадков, выпавших за каждый день месяца N (N -
// любой месяц в году). Верно ли, что по четным числам выпало больше осадков, чем по нечетным?
// 2. Дан целочисленный массив, состоящий из N элементов (N > 0). Поменять местами минимальный и максимальный
// элемент этого массива. Вывести новый полученный массив.
// 3. Написать функцию bool IsSquare(K) логического типа, возвращающую True, если целый параметр K (K > 0)
// является квадратом некоторого целого числа, и False в противном случае.
// 4. Написать функцию double RingS(R1, R2) вещественного типа, находящую площадь кольца, заключенного между
// двумя окружностями с общим центром и радиусами R1 и R2 (R1 и R2 — вещественные, R1 > R2).
// Воспользоваться формулой площади круга радиуса R: S = π·R2. В качестве значения π использовать 3.14.



public class Main {

    public static void main(String[] args) {
        while (true){
            Scanner sc = new Scanner(System.in);
            System.out.print("\nВведите номер задания(1-2 задания, 3 выход)\n");
            int task = sc.nextInt();
            switch (task) {
                case 1:
                    //region task01
                    try {
                        System.out.print("\nЗадание 1\n");
                        System.out.print("Введите месяц\n");
                        int month = sc.nextInt();
                        task01(month);
                    } catch (ArrayIndexOutOfBoundsException ex) {
                        System.out.print("Число выходит за грaницы массива\n");
                    } catch (InputMismatchException ex) {
                        System.out.print("Неверный формат или слишком длинное число\n");
                    }
                    break;
                //endregion
                case 2:
                    //region task02
                    try {
                        task02();
                    } catch (Exception ex) {
                        System.out.print(ex.getMessage());
                    }
                    break;
                //endregion
                case 3: {
                    return;
                }
                default: {
                    System.out.println("Введите 1, 2 или 3");
                    break;
                }
            }
        }
    }

    static void task01(int month) {
        Scanner sc = new Scanner(System.in);
        int day1;
        int err = 0;
        if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) day1 = 31;
        else if (month == 4 || month == 6 || month == 9 || month == 11) day1 = 30;
        else if (month == 2) day1 = 28;
        else day1 = 50;
        if (day1 == 50) {
            err = 1;
            System.out.print("Номер месяца введён не корректно\n");
        } else {
            double[] Mas = new double[day1];
            double Ch = 0;
            double Nch = 0;
            for (int i = 0; i < day1; i++) {
                System.out.print("Введите кол-во осадков в " + (i + 1) + " день месяца\n");
                Mas[i] = sc.nextDouble();
                if (i == 0) Nch += Mas[i];
                else if (i == 1) Ch += Mas[i];
                else if (i % 2 == 0) Nch += Mas[i];
                else if (i % 2 == 1) Ch += Mas[i];
            }
            for (int i = 0; i < day1; i++) {
                if (i == 0) Nch += 1;
                else if (i == 1) Ch += 1;
                else if (i % 2 == 0) Nch += 1;
                else if (i % 2 == 1) Ch += 1;
            }
            if (Ch > Nch) System.out.print("В чётные дни выпало больше осадков\n");
            else if (Ch == Nch) System.out.print("В чётные и нечётные дни выпало одинаковое кол-во осадков\n");
            else System.out.print("В нечётные дни выпало больше осадков\n");
        }
    }

    static void task02()
    {
        try {
            Scanner sc = new Scanner(System.in);

            System.out.println("Задание 2");
            System.out.println("Введите кол-во элементов массива");
            int N = sc.nextInt();
            int[] masR = new int[N];
            for (int i = 0; i < masR.length; i++)
            {
                System.out.println("Введите " + (i + 1) + " элемент массива: ");
                masR[i] = sc.nextInt();
            }
            int mn = masR[0];
            int mnn = 0;
            int mxx = 0;
            for (int i = 0; i < masR.length; i++)
            {
                if (masR[i] < mn)
                {
                    mn = masR[i];
                    mnn = i;
                }
            }
            int max = masR[0];
            for (int i = 0; i < masR.length; i++)
            {
                if (masR[i] > max)
                {
                    max = masR[i];
                    mxx = i;
                }
            }
            masR[mnn] = max;
            masR[mxx] = mn;
            String s = "";
            for (int i = 0; i < N; i++) {
                s += " " + masR[i] + ",";
            }
            System.out.println("Новый массив " + s);
        }
        catch (Exception ex) {System.out.print(ex.getMessage());}
    }
}


