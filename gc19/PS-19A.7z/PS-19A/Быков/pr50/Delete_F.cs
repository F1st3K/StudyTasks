﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.OleDb;
namespace pr50
{
    public partial class Delete_F : Form
    {
        string ID_rest = "";
        public Delete_F()
        {
            InitializeComponent();
        }

        private void Redact_func_Load(object sender, EventArgs e)
        {
            redactbutt.Enabled = false;

            string connect1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(connect1);

            DataTable datatable1 = new DataTable();


            try
            {
                oleDbConn1.Open();
            }
            catch (OleDbException)
            {
                MessageBox.Show(
               "Базы данных не существует",
               "Ошибка",
               MessageBoxButtons.OK,
               MessageBoxIcon.Error,
               MessageBoxDefaultButton.Button1);
                exit();

                goto t1;
            }

            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel;");

            sql1.Connection = oleDbConn1;

            try
            {
                sql1.ExecuteNonQuery();
            }
            catch (OleDbException)
            {
                MessageBox.Show(
                "Таблица в БД не найдена",
                "Ошибка",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error,
                MessageBoxDefaultButton.Button1);
                exit();
                goto t1;
            }


            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(datatable1);


            datatable1.Columns["Surname"].ColumnName = "Фамилия";
            datatable1.Columns["Name"].ColumnName = "Имя";
            datatable1.Columns["Patronymic_name"].ColumnName = "Отчество";
            datatable1.Columns["Cabinet"].ColumnName = "Кабинет";
            datatable1.Columns["Korpus"].ColumnName = "Корпус";

            dataGridViewBooks.DataSource = datatable1;

            dataGridViewBooks.Columns[0].Visible = false;
        t1:
            oleDbConn1.Close();
        }


        public void exit()
        {
            Application.Exit();
        }

        private void dataGridViewBooks_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID_rest = dataGridViewBooks.SelectedCells[0].Value.ToString();
            redactbutt.Enabled = true;

            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;"; 
            OleDbConnection oleDbConn1 = new OleDbConnection(con1); 
            DataTable dt1 = new DataTable();

            oleDbConn1.Open(); 
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel Where id = " + Convert.ToInt32(ID_rest) + ";"); 
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);
            sql1.Connection = oleDbConn1; 
            sql1.ExecuteNonQuery(); 

            da1.Fill(dt1);

            oleDbConn1.Close();
        }

        private void redactbutt_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            "Вы точно уверены, что хотите удалить запись?",
            "Сообщение",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning,
            MessageBoxDefaultButton.Button1);

            if (result == DialogResult.OK)
            {
                string con = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";
                OleDbConnection oleDbConn = new OleDbConnection(con);
                oleDbConn.Open();
                try
                {
                    OleDbCommand sql = new OleDbCommand("DELETE FROM Uchitel Where id=" + Convert.ToInt32(ID_rest) + ";");
                    sql.Connection = oleDbConn;
                    sql.ExecuteNonQuery();
                }
                catch
                {
                    MessageBox.Show(
                    "Вы не выбрали запись",
                    "Ошибка",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error,
                    MessageBoxDefaultButton.Button1);
                }

                oleDbConn.Close();

            }

            redactbutt.Enabled = false;
            UpdatedataGridViewBooks();
        }


        public void UpdatedataGridViewBooks()
        {
            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=Uchitel.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            DataTable dt1 = new DataTable();

            oleDbConn1.Open();

            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM Uchitel;");

            sql1.Connection = oleDbConn1;

            sql1.ExecuteNonQuery();

            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(dt1);



            dt1.Columns["Surname"].ColumnName = "Фамилия";
            dt1.Columns["Name"].ColumnName = "Имя";
            dt1.Columns["Patronymic_name"].ColumnName = "Отчество";
            dt1.Columns["Cabinet"].ColumnName = "Кабинет";
            dt1.Columns["Korpus"].ColumnName = "Корпус";

            dataGridViewBooks.DataSource = dt1;


            oleDbConn1.Close();
        }


        private void ex_Click(object sender, EventArgs e)
        {
            this.Hide();
            main returning = new main();
            returning.Show();
        }

        private void F_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void I_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void O_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void Num_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void Adress_TextChanged(object sender, EventArgs e)
        {
        }

        private void Num_TextChanged(object sender, EventArgs e)
        {
        }

        private void F_TextChanged(object sender, EventArgs e)
        {
        }

        private void I_TextChanged(object sender, EventArgs e)
        {
        }

        private void O_TextChanged(object sender, EventArgs e)
        {
        }
    }
}

