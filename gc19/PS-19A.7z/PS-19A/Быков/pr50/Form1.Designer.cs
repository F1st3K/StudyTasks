﻿namespace pr50
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.redact_func = new System.Windows.Forms.Button();
            this.exit_func = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // redact_func
            // 
            this.redact_func.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.redact_func.Location = new System.Drawing.Point(41, 48);
            this.redact_func.Name = "redact_func";
            this.redact_func.Size = new System.Drawing.Size(185, 56);
            this.redact_func.TabIndex = 1;
            this.redact_func.Text = "Удаление";
            this.redact_func.UseVisualStyleBackColor = true;
            this.redact_func.Click += new System.EventHandler(this.redact_func_Click);
            // 
            // exit_func
            // 
            this.exit_func.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.exit_func.Location = new System.Drawing.Point(41, 212);
            this.exit_func.Name = "exit_func";
            this.exit_func.Size = new System.Drawing.Size(185, 56);
            this.exit_func.TabIndex = 2;
            this.exit_func.Text = "Выход";
            this.exit_func.UseVisualStyleBackColor = true;
            this.exit_func.Click += new System.EventHandler(this.exit_func_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 311);
            this.Controls.Add(this.exit_func);
            this.Controls.Add(this.redact_func);
            this.Name = "main";
            this.Text = "Меню";
            this.Load += new System.EventHandler(this.main_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button redact_func;
        private System.Windows.Forms.Button exit_func;
    }
}

