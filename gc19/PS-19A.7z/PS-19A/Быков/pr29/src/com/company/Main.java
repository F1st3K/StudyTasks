package com.company;
import java.util.Scanner;
import java.util.Arrays;

// ВАРИАНТ № А5/Б36
// 1. Даны три целых ненулевых числа. Найти среднее из этих чисел (т. е. число, расположенное между наименьшим и
// наибольшим числом).
// 2. Дано количество часов, минут и секунд (1 час = 60 минут, 1 минута = 60 секунд). Вычислить и вывести общее
// количество секунд.
// 3. Даны семь целых ненулевых положительных чисел. Найти сумму четырех наибольших чисел.
// 4. Даны два целых положительных числа: D (день, от 1 до 31) и M (месяц, от 1 до 12), определяющие правильную
// дату не високосного года. Вывести значения D и M для даты, следующей за указанной.

public class Main {

    public static void main(String[] args) {
        //region task01
        Scanner sc = new Scanner(System.in);

        System.out.print("Задание 1\n");
        System.out.print("Введите 3 числа\n");
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        int max1;
        int min1;
        if (a > b && a > c)
        {
            max1 = a;
            min1 = b > c ? c : b;
        }
        else if (b > a && b > c)
        {
            max1 = b;
            min1 = a > c ? c : a;
        }
        else
        {
            max1 = c;
            min1 = a > b ? b : a;
        }
        float result01 = min1 + ((max1 - min1) / 2);
        System.out.print("Среднее между наибольшим и наименьшим = " + result01);
        //endregion

        //region task02
        System.out.print("\n\nЗадание 2\n");
        System.out.print("Введите кол-во часов\n");
        int hour = sc.nextInt();
        System.out.print("Введите кол-во минут\n");
        int min = sc.nextInt();
            System.out.print("Введите кол-во секунд\n");
        int sec = sc.nextInt();
        sec = hour * 3600 + min * 60 + sec;
        System.out.print("Общее кол-во секунд: " + sec);
        //endregion

        //region task03
        System.out.print("\n\nЗадание 3\n");
        System.out.print("Введите 7 целых ненулевых положительных чисел\n");

        int n1 = 1;
        int n2 = 1;
        int n3 = 1;
        int n4 = 1;
        int n5 = 1;
        int n6 = 1;
        int n7 = 1;
        n1 = sc.nextInt();
        switch (n1) {
            case 0: System.out.print("Нельзя вводить число 0 и меньше. Числу под номером 1 присвоено 1\n");
                    n1 = 1;
                    break;
        }
            if (n1 < 0)
            {
                System.out.print("Нельзя вводить числа 0 и меньше. Числу под номером 1 присвоено 1\n");
                n1 = 1;
            }
        n2 = sc.nextInt();
        switch (n2) {
            case 0: System.out.print("Нельзя вводить число 0 и меньше. Числу под номером 2 присвоено 1\n");
                n2 = 1;
                break;
        }
            if (n2 < 0)
            {
                System.out.print("Нельзя вводить числа 0 и меньше. Числу под номером 2 присвоено 1\n");
                n2 = 1;
            }
        n3 = sc.nextInt();
        switch (n3) {
            case 0: System.out.print("Нельзя вводить число 0 и меньше. Числу под номером 3 присвоено 1\n");
                n3 = 1;
                break;
        }
            if (n3 < 0)
            {
                System.out.print("Нельзя вводить числа 0 и меньше. Числу под номером 3 присвоено 1\n");
                n3 = 1;
            }
        n4 = sc.nextInt();
        switch (n4) {
            case 0: System.out.print("Нельзя вводить число 0 и меньше. Числу под номером 4 присвоено 1\n");
                n4 = 1;
                break;
        }
            if (n4 < 0)
            {
                System.out.print("Нельзя вводить числа 0 и меньше. Числу под номером 4 присвоено 1\n");
                n4 = 1;
            }
        n5 = sc.nextInt();
        switch (n5) {
            case 0: System.out.print("Нельзя вводить число 0 и меньше. Числу под номером 5 присвоено 1\n");
                n5 = 1;
                break;
        }
            if (n5 < 0)
            {
                System.out.print("Нельзя вводить числа 0 и меньше. Числу под номером 5 присвоено 1\n");
                n5 = 1;
            }
        n6 = sc.nextInt();
        switch (n6) {
            case 0: System.out.print("Нельзя вводить число 0 и меньше. Числу под номером 6 присвоено 1\n");
                n6 = 1;
                break;
        }
            if (n6 < 0)
            {
                System.out.print("Нельзя вводить числа 0 и меньше. Числу под номером 6 присвоено 1\n");
                n6 = 1;
            }
        n7 = sc.nextInt();
        switch (n7) {
            case 0: System.out.print("Нельзя вводить число 0 и меньше. Числу под номером 7 присвоено 1\n");
                n7 = 1;
                break;
        }
            if (n7 < 0)
            {
                System.out.print("Нельзя вводить числа 0 и меньше. Числу под номером 7 присвоено 1\n");
                n7 = 1;
            }
        int[] mas1 = {n1, n2, n3, n4, n5, n6, n7};
        Arrays.sort(mas1);
        int m1 = mas1[3];
        int m2 = mas1[4];
        int m3 = mas1[5];
        int m4 = mas1[6];
        int result03 = m1 + m2 + m3 + m4;
        System.out.print("Сумма 4-х максимальных чисел = " + result03 + "\n");
        //endregion

        //region Description
        System.out.print("\n\nЗадание 4\n");
        System.out.print("Введите номер месяца\n");
        int month = sc.nextInt();
        System.out.print("Введите номер дня\n");
        int day = sc.nextInt();
        int cnt = 0;
        int err = 0;
        if (day > 31 || day < 1 || month < 1 || month > 12) err = 1;
        switch (month) {
            case 1:
                if (day < 31 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 2:
                if (day < 28 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 3:
                if (day < 31 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 4:
                if (day < 30 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 5:
                if (day < 31 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 6:
                if (day < 30 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 7:
                if (day < 31 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 8:
                if (day < 31 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 9:
                if (day < 30 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 10:
                if (day < 31 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 11:
                if (day < 30 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
            case 12:
                if (day < 31 && day > 0) day = day + 1;
                else {
                    day = 1;
                    if (month < 12) month = month + 1;
                    else month = 1;
                }
                break;
        }
        String f = "";
        String fm = "";
        if (day < 10 && day > 0) f = "0";
        if (month < 10 && month > 0) fm = "0";
        if (err == 1) System.out.print("Месяц или день выходят за пределы\n");
        else System.out.print("Следующая дата: " + f + day + "." + fm + month + "\n");
        //endregion
    }
}
