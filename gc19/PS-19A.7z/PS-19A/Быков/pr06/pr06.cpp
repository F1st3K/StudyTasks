﻿// Выриант 5
// 1. Проверить истинность высказывания: "Цифры данного целого положительного четырехзначного числа образуют убывающую последовательность".
// 2. Даны семь целых ненулевых положительных чисел. Найти сумму четырех наибольших чисел.
// 3. Написать функцию double DegToRad(D) вещественного типа, находящую величину угла в радианах, если дана его величина D в градусах 
// (D — вещественное число, 0 ≤ D ≤ 360). Воспользоваться следующим соотношением: 180° = pi радианов. 
// В качестве значения PI использовать предопределенную константу из библиотеки языка программирования.
#define _USE_MATH_DEFINES
#include "stdafx.h"
#include "locale.h"
#include "math.h"
#include <cmath>
int N = 0;
int T = 0;
int S = 0;
int D = 0;
int E = 0;
int res1, res2, res = 0;
int vMas1[7];
int I1 = 0;
int i, s, g, d = 0;
double v = 0;
double DegToRad(double g);

int _tmain(int argc, _TCHAR* argv[])
{
	setlocale(LC_ALL, "Ru");

	// 1 задание
	printf("Задание 1\n");
m10:
	printf("Введите целое четырёхзначное число\n");
	scanf("%d", &N);
	if (999 < N && N < 9999)
	{
		T = N / 1000;
		S = N / 100 - T * 10;
		D = (N - (T * 1000) - (S * 100))/10;
		E = N % 10;
	}
	else
	{
		goto m10;
	}
	if (T > S && S > D && D > E)
	{
		printf("Числа идут по убыванию");
	}
	else
	{
		printf("Числа не идут по убыванию");
	}


	// 2 задание
	printf("\n\nЗадание 2\n");         
	printf("Введите 7 ненулевых положительных числа\n");

	for (i = 0; i < 7; i++)
	{
		do{
			printf("Введите %d число\n", i + 1);
			scanf("%d", &vMas1[i]);
		} while (vMas1[i] <= 0);
	}

	for (d = 0; d < 4; d++){
		for (s = 0; s < 7; s++)
		{
			N = vMas1[s];
			I1 = 0;

			for (i = 0; i < 7; i++)
			{
				if (s != i)
				{
					if (N == vMas1[i])
					{
						I1++;
					}
				}
				if (N > vMas1[i])
				{
					I1++;
				}
			}

			if (I1 == 6)
			{
				res1 += N;
				vMas1[s] = 0;
				I1 = 0;
				i = 9;
				s = 9;
			}
		}
	}

	printf("Сумма 4-х наибольших чисел - %d\n", res1);


	// 3 задание
	printf("\n\nЗадание 3\n");
	printf("Введите величину угла в градусах\n");
	
	DegToRad(g);


	return 0;
}

	double DegToRad(double g)
	{
		double f;
		double v;
		scanf("%lf", &f);
		v = f * M_PI / 180;
		printf("\nРадианы = %lf\n", v);
		return v;

	}