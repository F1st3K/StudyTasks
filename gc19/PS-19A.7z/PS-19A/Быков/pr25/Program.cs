﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Word = Microsoft.Office.Interop.Word;
using System.IO;

namespace pr25
{
    class Program
    {
        static void Main(string[] args)
        {
            #region CreateFile
            //создаем новый документ Word
            Word.Application wdApp = new Word.Application();
            Word.Document wdDoc = null;
            Object wdMiss = System.Reflection.Missing.Value;

            wdDoc = wdApp.Documents.Add(ref wdMiss, ref wdMiss, ref wdMiss, ref wdMiss);

            // устанавливаем ориентацию (вид) документа
            wdDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;

            // устанавливаем размеры полей
            wdDoc.PageSetup.TopMargin = wdApp.InchesToPoints(0.60f);    //0.67 = 1.7 см
            wdDoc.PageSetup.BottomMargin = wdApp.InchesToPoints(0.60f);
            wdDoc.PageSetup.LeftMargin = wdApp.InchesToPoints(0.80f);
            wdDoc.PageSetup.RightMargin = wdApp.InchesToPoints(0.59f);  //0.59 = 1.5 см

            // выводим документ на экран
            wdApp.Visible = true;

            // устанваливаем интервал между строками
            wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
            wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.0F;

            // вставляем новый параграф
            // имя параграфа
            Word.Paragraph Predmet;
            Predmet = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            //текст в параграфе
            Predmet.Range.Text = "МДК.01.01 Системное программирование";
            //выравнивание в документе
            Predmet.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            //размер шрифта
            Predmet.Range.Font.Size = Convert.ToInt32(18);
            Predmet.Range.Font.Bold = 1;
            Predmet.Range.InsertParagraphAfter();
            // закрываем параграф

            Predmet.Range.InsertParagraphAfter();
            Predmet.CloseUp();

            Word.Paragraph P25R;
            P25R = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            //текст в параграфе
            Predmet.Range.Font.Bold = 3;
            P25R.Range.Text = "ПР25 «Программное создание документов MS Word в языке С#»";
            //выравнивание в документе
            P25R.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            //размер шрифта
            P25R.Range.Font.Size = Convert.ToInt32(16);
            P25R.Range.InsertParagraphAfter();
            // закрываем параграф
            P25R.CloseUp();

            Word.Paragraph Student;
            Student = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            //текст в параграфе
            Student.Range.Text = "Выполнил Быков М.К., студент группы ПС-19А";
            //выравнивание в документе
            Student.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            //размер шрифта
            Student.Range.Font.Size = Convert.ToInt32(16);
            Student.Range.InsertParagraphAfter();
            // закрываем параграф
            Predmet.Range.InsertParagraphAfter();
            Student.CloseUp();
            #endregion

            #region Task01
            Word.Paragraph Task01;
            Task01 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            Task01.Range.Text = "Задание 1. Задано целое положительное четырехзначное число N (N > 0). Найти разницу между суммой всех его цифр и произведением нечетных цифр.";
            Task01.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            Task01.Range.Font.Size = Convert.ToInt32(14);
            Task01.Range.Font.Bold = 0;
            Task01.Range.InsertParagraphAfter();
            int Result01 = 0;
            int Proizv = 1;
            int Sum = 0;
            int count = 0;
            int A = 0;
            int B = 0;
            int C = 0;
            int D = 0;
            int N = 0;
            try
            {
            m01:
                Console.WriteLine("Задание 1");
                Console.WriteLine("Введите четырехзначное число");
                N = Convert.ToInt32(Console.ReadLine());
                if (N < 999 || N > 9999)
                {
                    goto m01;
                }
                Task01.Range.Text = "Введённое число: " + N;
                Task01.Range.InsertParagraphAfter();
                A = N / 1000;
                B = N / 100 - A * 10;
                C = N / 10 - A * 100 - B * 10;
                D = N - A * 1000 - B * 100 - C * 10;
                Sum = A + B + C + D;
                if (A % 2 == 1)
                {
                    Proizv *= A;
                    count = 1;
                }
                if (B % 2 == 1)
                {
                    Proizv *= B;
                    count = 1;
                }
                if (C % 2 == 1)
                {
                    Proizv *= C;
                    count = 1;
                }
                if (D % 2 == 1)
                {
                    Proizv *= D;
                    count = 1;
                }
                if (count == 0) Proizv = 0;
                Result01 = Sum - Proizv;
                if (Result01 < 0) Result01 *= -1;
                Console.WriteLine("Разница между суммой всех и произведением нечётных чисел: " + Result01);
                Task01.Range.Text = "Разница между суммой всех и произведением нечётных чисел: " + Result01;
                Task01.Range.InsertParagraphAfter();
            }
            catch (Exception ex)
            {
                Task01.Range.InsertParagraphAfter();
                Console.WriteLine(ex.Message);
                Task01.Range.Text = ex.Message;
                Task01.Range.InsertParagraphAfter();
            }
            Task01.Range.InsertParagraphAfter();
            Task01.CloseUp();
            #endregion

            #region Task02
            Word.Paragraph Task02;
            Task02 = wdDoc.Content.Paragraphs.Add(ref wdMiss);

            Task02.Range.Text = "Задание 2. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти и вывести количество элементов, расположенных после самого последнего максимального элемента.";
            Task02.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            Task02.Range.Font.Size = Convert.ToInt32(14);
            Task02.Range.Font.Bold = 0;
            Task02.Range.InsertParagraphAfter();
            int[] Mas;
            int n = 0;
            int max = 0;
            int cnt = 0;
            string Str = "";
            try
            {
                Console.WriteLine("");
                Console.WriteLine("Задание 2");
                Console.WriteLine("Введите кол-во элементов в массиве");
                n = Convert.ToInt32(Console.ReadLine());
                Mas = new int[n];
                for (int i = 0; i < Mas.Length; i++)
                {
                    Console.WriteLine("Введите " + (i + 1) + " элемент массива");
                    Mas[i] = Convert.ToInt32(Console.ReadLine());
                    Str += Convert.ToString(Mas[i] + " ");
                }
                Task02.Range.Text = "Массив: " + Str;
                Task02.Range.InsertParagraphAfter();
                max = Mas.Max();
                for (int i = 0; i < Mas.Length; i++)
                {
                    if (Mas[i] == max) cnt = -1;
                    cnt++;
                }
                Console.WriteLine("Чисел после последнего максимального числа: " + cnt);
                Task02.Range.Text = "Чисел после последнего максимального числа: " + cnt;


            }
            catch (Exception ex)
            {
                Task02.Range.InsertParagraphAfter();
                Console.WriteLine(ex.Message);
                Task02.Range.Text = ex.Message;
                Task02.Range.InsertParagraphAfter();
            }
            Task02.Range.InsertParagraphAfter();
            Task02.CloseUp();
            #endregion

            #region Task03
            int r = 0;
            string Str2 = "";
            string PolN = "";
            int[] Mas2;
            int Sum2 = 0;
            int ctn = 0;
            Word.Paragraph Task03;
            Task03 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            Task03.Range.Text = "Задание 3. Дан массив ненулевых целых чисел, признак его завершения - число 0. Вывести на экран все положительные нечетные числа из данного набора, а строкой ниже вывести их сумму. Если требуемые числа в наборе отсутствуют, то вывести значение -1. ";
            Task03.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            Task03.Range.Font.Size = Convert.ToInt32(14);
            Task03.Range.Font.Bold = 0;
            Task03.Range.InsertParagraphAfter();
            try
            {
                Console.WriteLine("");
                Console.WriteLine("Задание 3");
                Console.WriteLine("Введите кол-во элементов в массиве");
                r = Convert.ToInt32(Console.ReadLine());
                Mas2 = new int[r];
                for (int i = 0; i < Mas2.Length; i++)
                {
                    Console.WriteLine("Введите " + (i + 1) + " элемент массива");
                    Mas2[i] = Convert.ToInt32(Console.ReadLine());
                    Str2 += Convert.ToString(Mas2[i] + " ");
                    if (Mas2[i] > 0 && Mas2[i] % 2 == 1)
                    {
                        ctn = 1;
                        PolN += Mas2[i] + " ";
                        Sum2 += Mas2[i];
                    }
                }
                Task03.Range.Text = "Массив: " + Str2;
                Task03.Range.InsertParagraphAfter();
                if (ctn == 1)
                {
                    Console.WriteLine("Положительные нечётные числа массива: " + PolN);
                    Console.WriteLine("Сумма положительных нечётных чисел массива: " + Sum2);
                    Task03.Range.Text = "Положительные нечётные числа массива: " + PolN;
                    Task03.Range.InsertParagraphAfter();
                    Task03.Range.Text = "Сумма положительных нечётных чисел массива: " + Sum2;
                    Task03.Range.InsertParagraphAfter();
                }
                else
                {
                    Task03.Range.Text = "В массиве нет положительных нечётных чисел(-1)";
                }
            }
            catch (Exception ex)
            {
                Task03.Range.InsertParagraphAfter();
                Console.WriteLine(ex.Message);
                Task03.Range.Text = ex.Message;
                Task03.Range.InsertParagraphAfter();
            }
            Task03.Range.InsertParagraphAfter();
            Task03.CloseUp();
            #endregion

            #region Task05
            Word.Paragraph Task05;
            Task05 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            Task05.Range.Text = "Задание 5. Вводится строка, изображающая целочисленное арифметическое выражение вида «цифра_цифра_цифра_цифра», где на месте знака операции «_» находится символ «+» или «-», а на месте 'цифра' находится одна из цифр (от 1 до 9). Например, «4+7-2+5». Вывести значение данного выражения (как целое число).";
            Task05.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            Task05.Range.Font.Size = Convert.ToInt32(14);
            Task05.Range.Font.Bold = 0;
            Task05.Range.InsertParagraphAfter();
            string Str3 = "";
            int Result05 = 0;
            int Per = 0;
            int c = 1;
            int zn = 0;
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 5");
                Console.WriteLine("Введите строку с числами(от 1 до 9) разделённых знаками(+ или -)");
                Str3 = Convert.ToString(Console.ReadLine());
                if (Str3[0] == '1') Result05 = 1;
                else if (Str3[0] == '2') Result05 = 2;
                else if (Str3[0] == '3') Result05 = 3;
                else if (Str3[0] == '4') Result05 = 4;
                else if (Str3[0] == '5') Result05 = 5;
                else if (Str3[0] == '6') Result05 = 6;
                else if (Str3[0] == '7') Result05 = 7;
                else if (Str3[0] == '8') Result05 = 8;
                else if (Str3[0] == '9') Result05 = 9;
                else
                {
                    Console.WriteLine("Строка введена неверно!!!");
                    Task05.Range.Text = "Строка введена неверно!!!";
                    goto mE5;
                }
                for (int i = 0; i + 1 < Str3.Length; i++)
                {
                    if (c == 1)
                    {
                        if (Str3[i + 1] == '+') zn = 1;
                        else if (Str3[i + 1] == '-') zn = 0;
                        else
                        {
                            Console.WriteLine("Строка введена неверно!!!");
                            Task05.Range.Text = "Строка введена неверно!!!";
                            goto mE5;
                        }
                        c = 0;

                    }
                    else if (c == 0)
                    {
                        if (Str3[i + 1] == '1') Per = 1;
                        else if (Str3[i + 1] == '2') Per = 2;
                        else if (Str3[i + 1] == '3') Per = 3;
                        else if (Str3[i + 1] == '4') Per = 4;
                        else if (Str3[i + 1] == '5') Per = 5;
                        else if (Str3[i + 1] == '6') Per = 6;
                        else if (Str3[i + 1] == '7') Per = 7;
                        else if (Str3[i + 1] == '8') Per = 8;
                        else if (Str3[i + 1] == '9') Per = 9;
                        else
                        {
                            Console.WriteLine("Строка введена неверно!!!");
                            Task05.Range.Text = "Строка введена неверно!!!";
                            goto mE5;
                        }
                        if (zn == 0) Result05 -= Per;
                        else if (zn == 1) Result05 += Per;
                        c = 1;
                    }
                }
                Task05.Range.Text = "Строка: " + Str3;
                Task05.Range.InsertParagraphAfter();
                Task05.Range.Text = "Решение: " + Result05;
                Task05.Range.InsertParagraphAfter();
                Console.WriteLine("Решение: " + Result05);
                Task05.Range.InsertParagraphAfter();
            }
            catch (Exception ex)
            {
                Task05.Range.InsertParagraphAfter();
                Console.WriteLine(ex.Message);
                Task05.Range.Text = ex.Message;
                Task05.Range.InsertParagraphAfter();
            }
        mE5:
            Task05.Range.InsertParagraphAfter();
            Task05.CloseUp();
            #endregion

            #region Task06
            Word.Paragraph Task06;
            Task06 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            Task06.Range.Text = "Задание 6. Вводится строка, состоящая из букв и цифр. Длина строки может быть разной. Вывести на экран произведение цифр '3', '5' и '7', встречающихся в этой строке.";
            Task06.Alignment = Word.WdParagraphAlignment.wdAlignParagraphLeft;
            Task06.Range.Font.Size = Convert.ToInt32(14);
            Task06.Range.Font.Bold = 0;
            Task06.Range.InsertParagraphAfter();
            string Str4 = "";
            int Proizv2 = 1;
            int coun = 0;
            try
            {
                Console.WriteLine();
                Console.WriteLine("Задание 6");
                Console.WriteLine("Введите строку");
                Str4 = Convert.ToString(Console.ReadLine());
                for (int i = 0; i < Str4.Length; i++)
                {
                    if (Str4[i] == '3')
                    {
                        coun = 1;
                        Proizv2 *= 3;
                    }
                    else if (Str4[i] == '5')
                    {
                        coun = 1;
                        Proizv2 *= 5;
                    }
                    else if (Str4[i] == '7')
                    {
                        coun = 1;
                        Proizv2 *= 7;
                    }
                }
                if (coun == 0) Proizv2 = 0;
                Task06.Range.Text = "Строка: " + Str4;
                Task06.Range.InsertParagraphAfter();
                Task06.Range.Text = "Произведение цифр '3', '5' и '7', встречающихся в этой строке: " + Proizv2;
                Console.WriteLine("Произведение цифр '3', '5' и '7', встречающихся в этой строке: " + Proizv2);
            }
            catch (Exception ex)
            {
                Task06.Range.InsertParagraphAfter();
                Console.WriteLine(ex.Message);
                Task06.Range.Text = ex.Message;
                Task06.Range.InsertParagraphAfter();
            }
            Task06.Range.InsertParagraphAfter();
            Task06.CloseUp();
            #endregion
        }
    }
}
