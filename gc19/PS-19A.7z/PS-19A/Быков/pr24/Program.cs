﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;

// ВАРИАНТ № А5/Б41
// 1. Дано целое положительное пятизначное число N (N > 0). Используя операции деления и определения остатка от деления найти и вывести сумму всех его цифр.
// 2. Проверить истинность высказывания: "Квадратное уравнение A·x2 + B·x + C = 0 с данными коэффициентами A (A ≠ 0), B, C имеет ровно два вещественных корня".
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0). Проверить, чередуются ли в нем четные и нечетные числа. Если чередуются, то вывести 0, если нет, 
// то вывести порядковый номер первого элемента, нарушающего закономерность.
// 4. Вводится строка, содержащая латинские буквы и скобки трех видов: «()», «[]», «{}». Если скобки расставлены правильно 
// (т. е. каждой открывающей соответствует закрывающая скобка того же вида), то вывести число 0. В противном случае вывести или номер позиции, в которой расположена первая ошибочная скобка, 
// или, если закрывающих скобок не хватает, значение −1. 

namespace pr24
{
    class Program
    {
        static void Main(string[] args)
        {
            #region задание1

            int A = 0;
            int B = 0;
            int C = 0;
            int D = 0;
            int E = 0;
            int Chislo = 0;
            var document = new XmlDocument();

            try
            {
                document.Load("input1.xml");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto m1;
            }

            XmlNode root = document.DocumentElement;
            var writer = new XmlTextWriter("output1.xml", null);

            foreach (XmlNode books in root.ChildNodes)
            {
                foreach (XmlNode book in books.ChildNodes)
                {
                    try
                    {
                        Chislo = Convert.ToInt32(book.InnerText);
                        A = Chislo / 10000;
                        B = Chislo / 1000 - A * 10;
                        C = Chislo / 100 - A * 100 - B * 10;
                        D = Chislo / 10 - A * 1000 - B * 100 - C * 10;
                        E = Chislo - A * 10000 - B * 1000 - C * 100 - D * 10;
                        Chislo = A + B + C + D + E;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        goto m1;
                    }
                }
            }
            writer.WriteStartDocument();
            writer.WriteStartElement("task1");
            writer.WriteStartElement("result");
            writer.WriteString(Convert.ToString(Chislo));
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Close();
        m1:
            ;
            #endregion

            #region задание3

            int i = 0;
            int er = 0;
            int con = 0;
            int[] MAS = new int[5];
            document = new XmlDocument();

            try
            {
                document.Load("input3.xml");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                goto m2;
            }

            root = document.DocumentElement;
            writer = new XmlTextWriter("output3.xml", null);

            foreach (XmlNode books in root.ChildNodes)
            {
                foreach (XmlNode book in books.ChildNodes)
                {
                    try
                    {
                        MAS[i] = Convert.ToInt32(book.InnerText);
                        i++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        goto m1;
                    }
                    if (MAS[i - 1] == 0)
                    {
                        Console.WriteLine("Ошибка, числа не должны равняться нулю");
                        goto m1;
                    }
                }
            }
            if (MAS[0] % 2 == 0) con = 0;
            else if (MAS[0] % 2 == 1) con = 1;
            for (i = 0; i < MAS.Length; i++)
            {
                if (MAS[i] == 0)
                {
                    Console.WriteLine("Ошибка, числа не должны равняться нулю");
                    goto m1;
                }
                else if (MAS[i] % 2 == 0)
                {
                    if (con == 1)
                    {
                        er = i;
                        break;
                    }
                    con = 1;
                }
                else if (MAS[i] % 2 == 1)
                {
                    if (con == 0)
                    {
                        er = i;
                        break;
                    }
                    con = 0;
                }
            }
            if (er == 0)
            {
            writer.WriteStartDocument();
            writer.WriteStartElement("task2");
            writer.WriteStartElement("result");
            writer.WriteString(Convert.ToString(0));
            writer.WriteEndElement();
            writer.WriteEndElement();
            }
            else 
            {
            writer.WriteStartDocument();
            writer.WriteStartElement("task2");
            writer.WriteStartElement("result");
            writer.WriteString(Convert.ToString("Ошибка: " + (er + 1)));
            writer.WriteEndElement();
            writer.WriteEndElement();
            }

            writer.Close();
    m2:
            ;
            #endregion
        }
    }
}
