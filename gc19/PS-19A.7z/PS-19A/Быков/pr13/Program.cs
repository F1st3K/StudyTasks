﻿// ВАРИАНТ № А5/Б41
// 1. Из пяти целых различных ненулевых положительных и отрицательных чисел найти самое наименьшее число.
// 2. Проверить истинность высказывания: "Цифры данного целого положительного трехзначного числа, введенного с клавиатуры, образуют убывающую последовательность".
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти сумму и произведение всех четных чисел из данного массива.
// 4. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти сумму и произведение всех нечетных чисел из данного массива.
// 5. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти и вывести количество элементов, расположенных перед первым минимальным элементом. 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pr13
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание 1
            int N1 = 0;
            int N2 = 0;
            int N3 = 0;
            int N4 = 0;
            int N5 = 0;
            Console.WriteLine("Задание 1");

        m101:
            Console.WriteLine("Введите целые ненулевые числа");
            Console.WriteLine("Первое число");
            try
            {
                N1 = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("MESSAGE - " + ex.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("\n----------------------------------------------------------------");
            }
            Console.WriteLine("Второе число");
            try
            {
                N2 = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("MESSAGE - " + ex.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("\n----------------------------------------------------------------");
            }
            Console.WriteLine("Третье число");
            try
            {
                N3 = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("MESSAGE - " + ex.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("\n----------------------------------------------------------------");
            }
            Console.WriteLine("Четвертое число");
            try
            {
                N4 = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("MESSAGE - " + ex.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("\n----------------------------------------------------------------");
            }
            Console.WriteLine("Пятое число");
            try
            {
                N5 = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("MESSAGE - " + ex.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("\n----------------------------------------------------------------");
            }
            if (N1 < N2 && N1 < N3 && N1 < N4 && N1 < N5 && N1 != 0)            
            {
                Console.WriteLine("\nНаименьшее из чисел");
                Console.WriteLine(N1);
            }
            if (N3 < N2 && N3 < N1 && N3 < N4 && N3 < N5 && N3 != 0)
            {
                Console.WriteLine("\nНаименьшее из чисел");
                Console.WriteLine(N3);
            }
            if (N2 < N1 && N2 < N3 && N2 < N4 && N2 < N5 && N2 != 0)
            {
                Console.WriteLine("\nНаименьшее из чисел");
                Console.WriteLine(N2);
            }
            if (N4 < N2 && N4 < N3 && N4 < N1 && N4 < N5 && N4 != 0)
            {
                Console.WriteLine("\nНаименьшее из чисел");
                Console.WriteLine(N4);
            }
            if (N5 < N2 && N5 < N3 && N5 < N4 && N5 < N1 && N5 != 0)
            {
                Console.WriteLine("\nНаименьшее из чисел");
                Console.WriteLine(N5);
            }
            if (N1 == 0 || N2 == 0 || N3 == 0 || N4 == 0 || N5 == 0)
            {
                Console.WriteLine("\nНи одно из чисел не должно равняться нулю или ошибочному значению\n");
                goto m101;
            }
            #endregion

            #region Задание 2
            Console.WriteLine("\n\nЗадание 2");
        m102:
            int T1 = 0;
            int Ta = 0;
            int Tb = 0;
            int Tc = 0;
            Console.WriteLine("Введите целое положительное трехзначное число");
            
            try
            {
            T1 = Convert.ToInt32(Console.ReadLine());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n----------------------------------------------------------------");
                Console.WriteLine("MESSAGE - " + ex.Message.ToString()); //сообщение об ошибке
                Console.WriteLine("\n----------------------------------------------------------------");
            }
            if (T1 > 99 && T1 < 1000)
            {
                Ta = T1 / 100;
                Tb = T1 / 10 - Ta * 10;
                Tc = T1 - Ta * 100 - Tb * 10;
                if (Ta > Tb && Tb > Tc) Console.WriteLine("Числа расположены в убывающей последовательности");
                else Console.WriteLine("Числа не расположены в убывающей последовательности");
            }
            else goto m102;

            #endregion

            #region Задание 3
            int Sum = 0;
            int Proizv = 1;
            int gg = 0;
            int[] Chet = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
            Console.WriteLine("\n\nЗадание 3");
            Console.WriteLine("Введите массив положительных целых чисел");
            int l = Chet.Length;
             for (int i = 0; i < l; i++)
             {
                 if (Chet[i] % 2 == 1)
                 {
                     continue;
                 }
                 else
                 {
                     Sum += Chet[i];
                     Proizv *= Chet[i];
                     gg = 1;
                 }
             }
             if (gg == 1)
             {
                 Console.WriteLine("Сумма четных чисел равна " + Sum);
                 Console.WriteLine("Произведение четных чисел равно " + Proizv);
             }
             else
             {
                 Console.WriteLine("Сумма четных чисел равна 0");
                 Console.WriteLine("Произведение четных чисел равно 0");
             }
            #endregion

            #region Задание 4
             int Sum2 = 0;
             int Proizv2 = 1;
             int gg2 = 0;
             Console.WriteLine("\n\nЗадание 4");
             Console.WriteLine("Введите массив положительных целых чисел");
             int[] NeChet = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
             int leng = NeChet.Length;
             for (int i = 0; i < leng; i++)
             {
                 if (NeChet[i] % 2 == 1)
                 {
                     Sum2 += NeChet[i];
                     Proizv2 *= NeChet[i];
                     gg2 = 1;
                 }
                 else
                 {
                     continue;
                 }
             }
             if (gg2 == 1)
             {
                 Console.WriteLine("Сумма нечетных чисел равна " + Sum2);
                 Console.WriteLine("Произведение нечетных чисел равно " + Proizv2);
             }
             else
             {
                 Console.WriteLine("Сумма нечетных чисел равна 0");
                 Console.WriteLine("Произведение нечетных чисел равно 0");
             }
             #endregion

            #region Задание 5
             int Kolvo = 0;
             Console.WriteLine("\n\nЗадание 5");
             Console.WriteLine("Введите массив положительных целых чисел");
             int[] Mass = Console.ReadLine().Split(' ').Select(int.Parse).ToArray();
             int gg3 = Mass.Length;
             int Min = Mass[0];
             for (int i = 1; i < gg3; i++)
             {
                 if (Min > Mass[i])
                 {
                     Min = Mass[i];
                     Kolvo = i;
                 }
             }
             Console.WriteLine("Перед первым минимальным числом массива " + Kolvo + " элементов");
             #endregion
        }
    }
}
