package main

import (
	"fmt"
	"sort"
	"strconv"
)

// ВАРИАНТ № А5/Б31
// 1. Дано четырехзначное целое ненулевое положительное число N (N>0). Проверить истинность высказывания: "Все цифры
// данного числа различны".
// 2. Дан целочисленный массив, состоящий из N элементов (N > 0, N может быть четным или нечетным числом). Поменять
// порядок его элементов на обратный. Вычислить и вывести сумму и произведение всех его элементов.
// 3. Дан целочисленный массив, состоящий из N элементов (N > 0), содержащий, по крайней мере, два нуля. Вычислить
// сумму чисел из данного набора, расположенных между этими двумя нулями. Если нули идут подряд, то вывести 0. Если
// в массиве имеется только одно значение 0, то вычислить сумму всех его элементов.
// 4. Написать функцию int Min4(A, B, C, D) целого типа, возвращающую одно минимальное значение из 4-х своих аргументов
// (параметры A, B, C и D - целые числа).
// 5. Вводится строка. Длина строки может быть разной. Заменить на символ '%' (процент) каждый второй символ исходной
// строки. Вывести полученную строку и общее количество замен этих символов.

func main() {
	//task01
	{
		fmt.Println("Задение 1")
		var (
			N  int
			n1 int
			n2 int
			n3 int
			n4 int
		)
	mSt:
		fmt.Println("Введите 4-хзначное число")
		_, err := fmt.Scan(&N)

		if err != nil {
			fmt.Println(err)
			goto mSt
		}
		if (N < 1000) || (N > 9999) {
			fmt.Println("Число не четырёхзначное")
			goto mSt
		}

		n1 = N / 1000
		n2 = N/100 - n1*10
		n3 = N/10 - n1*100 - n2*10
		n4 = N - n1*1000 - n2*100 - n3*10

		if (n1 != n2) && (n1 != n3) && (n1 != n4) && (n2 != n3) && (n2 != n4) && (n3 != n4) {
			fmt.Println("Все цифры данного числа различны")
		} else {
			fmt.Println("Не все цифры данного числа различны")
		}
	}

	//task02
	{
		fmt.Println("\nЗадение 2")
		var mas []int
	m2_1:
		fmt.Println("Введите кол-во элементов массива")
		var el int
		var f int
		_, err := fmt.Scan(&el)

		if err != nil {
			fmt.Println(err)
			goto m2_1
		}

		for i := 0; i < el; i++ {
		m1_2:
			fmt.Println("Введите ", i+1, " элемент массива")
			_, err := fmt.Scan(&f)

			if err != nil {
				fmt.Println(err)
				goto m1_2
			}
			mas = append(mas, f)
		}

		for i, j := 0, len(mas)-1; i < j; i, j = i+1, j-1 {
			mas[i], mas[j] = mas[j], mas[i]
		}

		fmt.Println("Получившийся массив: ", mas)
	}

	//task03

	{
		fmt.Println("\nЗадение 3")
		var mas []int
	m2_3:
		fmt.Println("Введите кол-во элементов массива")
		var el int
		var f int
		_, err := fmt.Scan(&el)

		if err != nil {
			fmt.Println(err)
			goto m2_3
		}

		for i := 0; i < el; i++ {
		m1_4:
			fmt.Println("Введите ", i+1, " элемент массива")
			_, err := fmt.Scan(&f)

			if err != nil {
				fmt.Println(err)
				goto m1_4
			}
			mas = append(mas, f)
		}
		Sum := 0
		cc := 0
		r := 0

		for i := 0; i < len(mas); i++ {

			if cc == 1 {
				Sum += mas[i]
			}

			if r < 2 {
				if mas[i] == 0 {
					if cc == 1 {
						cc = 0
						r++
					} else {
						cc = 1
						r++
					}
				}
			}

		}

		if r == 1 {
			Sum = 0
			for i := 0; i < len(mas); i++ {
				Sum += mas[i]
			}
			fmt.Println("Сумма всех элементов массива: ", Sum)
		} else {
			fmt.Println("Искомая сумма элементов массива: ", Sum)
		}
	}
	//task04
	{
		fmt.Println("\nЗадение 4")
	m41:
		fmt.Println("Введите 1 число")
		A := 0
		_, err := fmt.Scan(&A)

		if err != nil {
			fmt.Println(err)
			goto m41
		}
	m42:
		fmt.Println("Введите 2 число")
		B := 0
		_, err = fmt.Scan(&B)

		if err != nil {
			fmt.Println(err)
			goto m42
		}
	m43:
		fmt.Println("Введите 3 число")
		C := 0
		_, err = fmt.Scan(&C)

		if err != nil {
			fmt.Println(err)
			goto m43
		}

	m44:
		fmt.Println("Введите 4 число")
		D := 0
		_, err = fmt.Scan(&D)

		if err != nil {
			fmt.Println(err)
			goto m44
		}
		min := Min4(A, B, C, D)

		fmt.Println("Минимальное число: ", min)
	}

	//task02
	{
		fmt.Println("\nЗадение 5")
		var mas []int
	m5_1:
		fmt.Println("Введите кол-во элементов массива")
		var el int
		var f int
		_, err := fmt.Scan(&el)

		if err != nil {
			fmt.Println(err)
			goto m5_1
		}

		for i := 0; i < el; i++ {
		m5_2:
			fmt.Println("Введите ", i+1, " элемент массива")
			_, err := fmt.Scan(&f)

			if err != nil {
				fmt.Println(err)
				goto m5_2
			}
			mas = append(mas, f)
		}

		var sl []string

		for i := 0; i < el; i++ {
			if (i%2 == 1) || (i == 1) {
				sl = append(sl, "%")
			} else {
				sl = append(sl, strconv.Itoa(mas[i]))
			}
		}

		fmt.Println("Получившийся массив: ", sl)
	}
}

func Min4(A int, B int, C int, D int) int {
	var sl []int
	sl = append(sl, A, B, C, D)
	sort.Ints(sl)
	return sl[0]
}
