﻿// ВАРИАНТ № А5 / Б46
// 1. Проверить истинность высказывания : 
// "Данные целые числа X и Y являются координатами точки, лежащей во второй координатной четверти".
// 2. Дан целочисленный массив, состоящий из N элементов(N > 0, N - четное число).Поменять местами его первый элемент со вторым, 
// третий - с четвертым и т.д.Вывести полученный массив.
// 3. Дан целочисленный массив, состоящий из N элементов(N > 0).Проверить, образует ли данный набор возрастающую 
//последовательность.Если образует, то вывести True, если нет - вывести False.
// 4. Написать функцию double RingS(R1, R2) вещественного типа, находящую площадь кольца, заключенного между двумя окружностями с 
// общим центром и радиусами R1 и R2(R1 и R2 — вещественные, R1 > R2).Воспользоваться формулой площади круга радиуса R : S = π·R2.
// В качестве значения π использовать 3.14.
#include "stdafx.h"
#include <conio.h>
#include <locale.h>
#include <math.h>

int x, y;
double RingS(double vR1, double vR2);
char vInBuf[100];
char vInBufF[100];
char *pvInBuf;
FILE *pFile1;	
FILE *pFile4;
FILE *pFile2;
FILE *pFile3;
FILE *pFileO1;
FILE *pFileO4;
FILE *pFileO3;
FILE *pFileO2;
int vResult = 0;
char g[1];
int _tmain(int argc, _TCHAR* argv[])
{
	setlocale(LC_ALL, "Ru");
	pvInBuf = &vInBuf[0];

	pFile1 = fopen("input2.txt", "r");
	pFile2 = fopen("input3.txt", "r");
	pFile3 = fopen("input4.txt", "r");
	pFile4 = fopen("input1.txt", "r");
	pFileO1 = fopen("output1.txt", "w");
	pFileO4 = fopen("output4.txt", "w");
	pFileO3 = fopen("output3.txt", "w");
	pFileO2 = fopen("output2.txt", "w");

	if (pFile1 == NULL)
	{
		printf("\nOpen-1 error !");
		vResult = getch();
		goto m9;
	}

	if (pFile2 == NULL)
	{
		printf("\nOpen-2 error !");
		vResult = getch();
		goto m9;
	}
	// TASK 1

m200:													//задание 1
	vResult = fscanf(pFile1, "%d", &x);						//ищем х и у
	if (vResult == EOF) goto m800;
	vResult = fscanf(pFile1, "%d", &y);
	if (vResult == EOF) goto m800;
	goto m200;

m800:
	if (x < 0 && y > 0)
	{
		vResult = fprintf(pFileO1, "%s\n", "Данные целые числа X и Y являются координатами точки, лежащей во второй координатной четверти");
	}
	else
	{
		vResult = fprintf(pFileO1, "%s\n", "Данные целые числа X и Y НЕ являются координатами точки, лежащей во второй координатной четверти");
	}





	// TASK 2
	printf("\nTASK 2");

m2:

	vResult = fscanf(pFile1, "%s", pvInBuf);
	if (vResult == EOF) goto m8;

	goto m2;

m8:
	vResult = fclose(pFile1);

	for (int i = 0; i < 1000; i++)
	{
		vInBufF[0] = pvInBuf[i + 1];
		pvInBuf[i + 1] = pvInBuf[i];
		pvInBuf[i] = vInBufF[0];
		i++;
		if (pvInBuf[i + 1] == '\0') break;
	}
	printf("\n%s", pvInBuf);
	vResult = fprintf(pFileO2, "\n%s", pvInBuf);

	// TASK 3
	printf("\n\nTASK 3\n");
m12:
	vResult = fscanf(pFile2, "%s", pvInBuf);

	if (vResult == EOF) goto m13;

	goto m12;

m13:
	vResult = fclose(pFile2);
	for (int i = 0; i < 10; i++)
	{
		if (pvInBuf[i + 1] == '\0') break;
		g[1] = pvInBuf[i + 1];
		g[1] = g[1] - 1;
		if (pvInBuf[i] != g[1]) goto m11;

	}
	vResult = fprintf(pFileO3, "\n%s", "True");
	goto m14;
m11:
	vResult = fprintf(pFileO3, "\n%s", "False");

	// TASK 4
m14:
	double vR1;
	double vR2;
	double vS;
	double pi = 3.14;
	vResult = fscanf(pFile3, "%lf", &vR1);
	if (vResult == EOF) goto m15;
	vResult = fscanf(pFile3, "%lf", &vR2);
	if (vResult == EOF) goto m15;
	goto m14;
	
m15:
	vResult = fprintf(pFileO4, "\n%lf", RingS(vR1, vR2));
	vResult = fclose(pFile3);
	vResult = fclose(pFileO4);
	vResult = fclose(pFileO3);
	vResult = fclose(pFileO2);
	vResult = fclose(pFile4);
	vResult = fclose(pFileO1);

m9:

	return 0;
}

double RingS(double vR1, double vR2)
{
	double vS;
	double pi = 3.14;
	vS = (pi * (vR1*vR1)) - (pi * (vR2*vR2));
	return vS;
}