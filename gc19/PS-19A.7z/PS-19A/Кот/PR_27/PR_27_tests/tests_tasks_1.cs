﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using dll_tasks;

namespace PR_27_tests
{
    [TestClass]
    public class tests_tasks_1
    {
        [TestMethod]
        public void test_task_1_1()
        {
            int num = 555;
            int expected = 1;

            task_1 task1 = new task_1();
            int actual = task1.num_culc(num);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_1_2()
        {
            int num = -555;
            int expected = 0;

            task_1 task1 = new task_1();
            int actual = task1.num_culc(num);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_1_3()
        {
            int num = 432353;
            int expected = 0;

            task_1 task1 = new task_1();
            int actual = task1.num_culc(num);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_1_4()
        {
            int num = 12;
            int expected = 1;

            task_1 task1 = new task_1();
            int actual = task1.num_culc(num);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_1_5()
        {
            int num = 321;
            int expected = 0;

            task_1 task1 = new task_1();
            int actual = task1.num_culc(num);

            Assert.AreEqual(expected, actual);
        }
    }
}
