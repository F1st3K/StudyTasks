﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using dll_tasks;

namespace PR_27_tests
{
    [TestClass]
    public class tests_tasks_5
    {
        [TestMethod]
        public void test_task5_1()
        {
            string[] str1 = {"wwwljsdfw", "jhgsadww", "sdfwwww", "wwwwwwwkjdslfj", "wwjkshdfw"};
            int expected = 1;

            task_5 task5 = new task_5();
            int actual = task5.string_working(str1);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task5_2()
        {
            string[] str1 = { "wwwljsdfw", "jhgsadww", "sdfwwww", "wwwwwwwkjdslfj", "wwjkshdfw" };
            int expected = 2;

            task_5 task5 = new task_5();
            int actual = task5.string_working(str1);

            Assert.AreEqual(expected, actual);
        }
    }
}
