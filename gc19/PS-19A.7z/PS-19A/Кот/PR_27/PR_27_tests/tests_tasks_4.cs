﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using dll_tasks;

namespace PR_27_tests
{
    [TestClass]
    public class tests_tasks_4
    {
        [TestMethod]
        public void test_task4_1()
        {
            string str = "abcdefg";
            int expected = 1;

            task_4 task4 = new task_4();
            int actual = task4.alphabet(str);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task4_2()
        {
            string str = "sdadfgdfg";
            int expected = 0;

            task_4 task4 = new task_4();
            int actual = task4.alphabet(str);

            Assert.AreEqual(expected, actual);
        }
    }
}
