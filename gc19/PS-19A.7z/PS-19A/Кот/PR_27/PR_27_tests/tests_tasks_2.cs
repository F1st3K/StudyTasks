﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using dll_tasks;

namespace PR_27_tests
{
    [TestClass]
    public class tests_tasks_2
    {
        [TestMethod]
        public void test_task_2_1()
        {
            int[] mass = new int[29] { 1, 2, 3, 5, 67, 12, 57, 1, 23, 56, 1, 2, 15, 5, 67, 23, 57, 1, 32, 12, 1, 2, 3, 11, 67, 12, 57, 6, 7};
            int expected = 1;

            task_2 task2 = new task_2();
            int actual = task2.weather(mass);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_2_2()
        {
            int[] mass = new int[30] { 1, 2, 3, 5, 10, 11, 57, 1, 21, 56, 1, 2, 6, 5, 67, 23, 15, 1, 2, 12, 1, 2, 3, 11, 67, 12, 57, 6, 7, 11 };
            int expected = 0;

            task_2 task2 = new task_2();
            int actual = task2.weather(mass);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_2_3()
        {
            int[] mass = new int[30] { 1, 2, 3, 5, 67, 12, 57, -1, 23, 56, 1, 2, 15, 5, 67, -23, 57, 1, 32, 12, 1, 2, 3, 11, 67, 12, 57, 6, 7, 11 };
            int expected = 2;

            task_2 task2 = new task_2();
            int actual = task2.weather(mass);

            Assert.AreEqual(expected, actual);
        }
    }
}
