﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using dll_tasks;

namespace PR_27_tests
{
    [TestClass]
    public class tests_tasks_3
    {
        [TestMethod]
        public void test_task_3_1()
        {
            int A = 5;
            int B = 5;
            int C = 5;
            int D = 5;
            int E = 5;

            int expected = 1;

            task_3 task3 = new task_3();
            int actual = task3.Min5(A, B, C, D, E);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_3_2()
        {
            int A = 7;
            int B = 1;
            int C = 3;
            int D = -2;
            int E = 11;

            int expected = 2;

            task_3 task3 = new task_3();
            int actual = task3.Min5(A, B, C, D, E);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_3_3()
        {
            int A = 7;
            int B = 1;
            int C = 0;
            int D = -2;
            int E = 11;

            int expected = 3;

            task_3 task3 = new task_3();
            int actual = task3.Min5(A, B, C, D, E);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void test_task_3_4()
        {
            int A = 7;
            int B = 1;
            int C = 3;
            int D = -2;
            int E = 11;

            int expected = 4;

            task_3 task3 = new task_3();
            int actual = task3.Min5(A, B, C, D, E);

            Assert.AreEqual(expected, actual);
        }
    }
}
