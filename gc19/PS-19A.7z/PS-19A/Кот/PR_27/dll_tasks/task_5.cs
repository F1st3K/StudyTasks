﻿//5. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
//Длина строки может быть разной. Определить и вывести на экран количество слов, которые содержат ровно четыре буквы 'w'.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dll_tasks
{
    public class task_5
    {
        /// <summary>
        /// Данный метод получает строку - предложение где слова разделены подчёркиваниями. Строка развибавется на строковый массив, а дальше идёт работа с элементами массива
        /// </summary>
        /// <param name="str1"></param>
        /// <returns>Метод возвращает флаг, для Unit теста</returns>

        public int string_working(string[] str1)
        {
            string str2;

            int flag = 0;

            int cout = 0, words = 0;

            if (str1.Length < 10) { flag = 2; }

            for (int i = 0; i < str1.Length; i++)
            {
                str2 = str1[i];

                for (int l = 0; l < str2.Length; l++)
                {
                    if (str2[l] == 'w')
                    {
                        cout++;
                    }

                    if (cout == 4) { words += 1; cout = 0; }
                }
            }

            Console.WriteLine("Количество слов в 4 w: {0}", words);

            if (words == 0)
            {
                flag = 1;
            }

            return flag;
        }
    }
}
