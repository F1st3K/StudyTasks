﻿//4. Вводится строка, содержащая цифры (от 0 до 9) и строчные латинские буквы.
//Если буквы в строке упорядочены по алфавиту (abcdefghijklmnopqrstuvwxyz), то вывести число 0;
//в противном случае вывести номер первого символа строки, нарушающего алфавитный порядок.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dll_tasks
{
    public class task_4
    {
        /// <summary>
        /// Данный метод получает строку - алфавит, идёт проверка, расположены ли в строке буквы по алфавиту. Проверка идёт сортировкой по возрастанию OrderBy
        /// </summary>
        /// <param name="str"></param>
        /// <returns>Метод возвращает флаг, для Unit теста</returns>

        public int alphabet(string str)
        {
            string Sorting;

            int flag = 0;

            if (string.Compare(new string(str.OrderBy(c => c).ToArray()), str) == 0) //Проверка сортировкой OrderBy (по возрастанию), в этом случае по алфавитному порядку
            {
                Sorting = "По алфавиту";
                flag = 1;
            }

            else { Sorting = "Не по алфавиту"; flag = 0; }

            Console.WriteLine(string.Format("Буквы в алфавите расположены: {0}", Sorting));

            return flag;
        }
    }
}
