﻿//2. В вещественном массиве известны данные о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году).
//Найти общее число осадков, выпавших по четным числам месяца.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dll_tasks
{
    public class task_2
    {
        /// <summary>
        /// Данный метод получает массив чисел в к отором находятся осадки (массив заполняетмя рандомно). После получения идёт поиск общее число осадков по чётным дням.
        /// </summary>
        /// <param name="mass"></param>
        /// <returns>Метод возвращает флаг, для Unit теста</returns>

        public int weather(int[] mass)
        {
            int flag = 0;
            int sum = 0;

            if (mass.Length < 30) { flag = 1; }
            else if (mass.Length > 30) { flag = 0; }

            for (int i = 0; i < mass.Length; i++)
            {
                if (mass[i] % 2 == 0) { sum += mass[i]; }
                if (mass[i] < 0) { flag = 2; }
            }

            Console.WriteLine("Сумма осадков по чётным дням: {0}", sum);

            return flag;
        }
    }
}
