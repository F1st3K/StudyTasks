﻿//3. Написать функцию int Min5(A, B, C, D, E) целого типа, возвращающую одно минимальное значение из 5-и своих аргументов (параметры A, B, C, D и E - целые числа).

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dll_tasks
{
    public class task_3
    {
        /// <summary>
        /// Данный метод получате 5 чисел, и ищет минимальное из них
        /// </summary>
        /// <param name="A"></param>
        /// <param name="B"></param>
        /// <param name="C"></param>
        /// <param name="D"></param>
        /// <param name="E"></param>
        /// <returns>Метод возвращает флаг, для Unit теста</returns>

        public int Min5(int A, int B, int C, int D, int E)
        {
            int[] mass = new int[5];

            int flag = 0;
            int min = 0;

            mass[0] = A;
            mass[1] = B;
            mass[2] = C;
            mass[3] = D;
            mass[4] = E;

            min = mass[0];

            for (int i = 0; i < 5; i++)
            {
                if (min > mass[i])
                {
                    min = mass[i];
                }

                if (mass[i] == 0) { flag = 3; }
                else { flag = 4; }
            }

            if (mass[0] == mass[1] && mass[1] == mass[2] && mass[2] == mass[3] && mass[3] == mass[4]) { flag = 1; }
            else { flag = 2; Console.WriteLine("Минимальное введёное число: {0}", min); }

            return flag;
        }
    }
}
