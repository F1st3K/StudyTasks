﻿//1. Проверить истинность высказывания: "Сумма всех цифр данного целого положительного трехзначного числа является нечетным числом".

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dll_tasks
{
    public class task_1
    {
        //__________________________________________Задание 1

        /// <summary>
        /// Данный метод получает число, делит его на цифры, и проверяет сумму чисел на неёчтность
        /// </summary>
        /// <param name="num"></param>
        /// <returns>Метод возвращает флаг, для Unit теста</returns>

        public int num_culc(int num)
        {
            int sum = 0;
            int flag = 0;

            int[] mass = new int[3];

            string str;
            str = Convert.ToString(num);

            if (num > 0 && num % 1 == 0 && str.Length == 3)
            {
                num = Convert.ToInt32(str);

                mass[0] = num / 1000;
                mass[1] = (num / 100) % 10;
                mass[2] = (num % 100) / 10;

                sum = mass[0] + mass[1] + mass[2];

                if (sum % 1 != 0) { Console.WriteLine("Сумма цифр числа НЕ чётная!"); flag = 1; }

                else if (sum % 1 == 0) { Console.WriteLine("Сумма цифр числа чётная!"); flag = 0; }
            }

            else { Console.WriteLine("Число не подходит под условие!"); flag = 0; }

            return flag;
        }
    }
}
