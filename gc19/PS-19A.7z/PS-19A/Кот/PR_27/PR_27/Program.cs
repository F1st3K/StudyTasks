﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using dll_tasks;

namespace PR_27
{
    class Program
    {
        static void Main(string[] args)
        {
            //__________________________________________Задание 1

m100:       Console.WriteLine("Задание 1 - Введите положительное трёхзначное число: ");

            int num = 0;

            try
            {
                num = Convert.ToInt32(Console.ReadLine());
            }

            catch (FormatException) { Console.WriteLine("Не верный формат!"); goto m100; }
            catch (OverflowException) { Console.WriteLine("Переполнение переменной!"); goto m100; }

            task_1 task1 = new task_1();
            task1.num_culc(num);

            //__________________________________________Задание 2

            Console.WriteLine("Задание 2");

            int[] mass = new int[30];

            Random rand = new Random(); 

            for (int i = 0; i < mass.Length; i++)
            {
                mass[i] = rand.Next(1, 21);
                Console.WriteLine("Число массива: {0}", mass[i]);
            }

            task_2 task2 = new task_2();
            task2.weather(mass);

            //__________________________________________Задание 3

            task_3 task3 = new task_3();
            int A, B, C, D, E;

m101:       Console.WriteLine("Задание 3 - Введите 5 чисел через Enter: ");

            try
            {
                A = Convert.ToInt32(Console.ReadLine());
                B = Convert.ToInt32(Console.ReadLine());
                C = Convert.ToInt32(Console.ReadLine());
                D = Convert.ToInt32(Console.ReadLine());
                E = Convert.ToInt32(Console.ReadLine());
            }

            catch (FormatException) { Console.WriteLine("Не верный формат!"); goto m101; }

            task3.Min5(A, B, C, D, E);

            //__________________________________________Задание 4

            Console.WriteLine("Задание 4 - Введите строку алфавит: ");
            string str = Convert.ToString(Console.ReadLine());

            task_4 task4 = new task_4();
            task4.alphabet(str);

            //__________________________________________Задание 5

            Console.WriteLine("Задание 5 - Введите строку разделённую подчёркиваниями с буквами w: ");
            string[] str1 = Console.ReadLine().Split(new char[] { '_' });

            task_5 task5 = new task_5();
            task5.string_working(str1);

            Console.ReadKey();
        }
    }
}
