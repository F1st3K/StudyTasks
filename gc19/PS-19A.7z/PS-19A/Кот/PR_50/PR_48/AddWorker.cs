﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PR_48
{
    public partial class AddWorker : Form
    {
        public AddWorker()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ViewInDataBase();
        }

        private void AddInDB_Click(object sender, EventArgs e)
        {
            try
            {
                //проверяем заполнение всех полей
                if (surname.Text == "" || name.Text == "" || patronymic.Text == "" || post.Text == "" || number.Text == "")
                {
                    MessageBox.Show("Ошибка! Заполните все поля!", "Сообщение пользователю", MessageBoxButtons.OK);
                }
                else
                {
                    //забираем введенные значения с формы
                    string Surname_worker = surname.Text.ToString();
                    string Name_worker = name.Text.ToString();
                    string Patronymic_worker = patronymic.Text.ToString();
                    string Post = post.Text.ToString();
                    string Phone_number = number.Text.ToString();

                    // строка подключения к нашей БД MS Access
                    string con = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source = worker.mdb;";

                    // создаем виртуальное подключение
                    OleDbConnection oleDbConn = new OleDbConnection(con);

                    // открываем подключение к базе
                    oleDbConn.Open();

                    // создаем запрос - в нашем случае это ввод данных
                    OleDbCommand sql = new OleDbCommand("INSERT INTO workers (surname_worker, name_worker, patronymic_worker, post, phone_number) VALUES ('" + Surname_worker + "','" + Name_worker + "', '" + Patronymic_worker + "', '" + Post + "', '" + Phone_number + "');");

                    // привязываем запрос к "конекту"
                    sql.Connection = oleDbConn;

                    //выполняем запрос
                    sql.ExecuteNonQuery();

                    // обязательно закрываем подключение к БД
                    oleDbConn.Close();

                    //выводим сообщение пользователю что книга в БД добавлена
                    MessageBox.Show("Запись добавлена!", "Сообщение пользователю", MessageBoxButtons.OK);

                    //обновляем нашу таблицу которая на форме с уже 
                    //новой записью (отдельной функцией)
                    ViewInDataBase();

                    //очищаем все поля ввода на форме после успешного 
                    //добавления информации в БД

                    surname.Clear();
                    name.Clear();
                    patronymic.Clear();
                    post.Clear();
                    number.Clear();
                }
            }

            catch { MessageBox.Show("Ошибка. Такой таблицы нет!"); };
        }

        public void ViewInDataBase()
        {
            try
            {
                string connection = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source = worker.mdb;";

                // создаем подключение
                using (OleDbConnection oleDbConnection = new OleDbConnection(connection)) //подключение
                {
                    // создаем виртуальную таблицу
                    DataTable memory_table = new DataTable(); //вииртуальная таблица в оперативной памяти

                    // открываем подключение к базе
                    oleDbConnection.Open();

                    // создаем запрос к бд
                    OleDbCommand sql1 = new OleDbCommand("SELECT * FROM workers;");

                    // привязываем запрос к коннекту
                    sql1.Connection = oleDbConnection;

                    // выполняем запрос
                    sql1.ExecuteNonQuery();

                    // создаем новый адаптер для манипулирования данными
                    OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

                    // заполняем адаптер полученными данными из базы (файла) MS Access
                    da1.Fill(memory_table);

                    //остальные поля обязательно!
                    memory_table.Columns["surname_worker"].ColumnName = "Фамилия";
                    memory_table.Columns["name_worker"].ColumnName = "Имя";
                    memory_table.Columns["patronymic_worker"].ColumnName = "Отчество";
                    memory_table.Columns["post"].ColumnName = "Должность";
                    memory_table.Columns["phone_number"].ColumnName = "Номер телефона";

                    // связываем интерфейс с бд
                    dataGridView1Workers.DataSource = memory_table;

                    dataGridView1Workers.Columns[0].Visible = false;
                    dataGridView1Workers.Columns[1].Width = 80;
                    dataGridView1Workers.Columns[2].Width = 90;
                    dataGridView1Workers.Columns[3].Width = 200;
                    dataGridView1Workers.Columns[4].Width = 70;
                    dataGridView1Workers.Columns[5].Width = 90;
                }
            }

            catch { MessageBox.Show("Ошибка. Такой таблицы нет!"); }
        }

        private void surname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void name_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void patronymic_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void post_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else
                e.Handled = true;
        }

        private void number_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }
    }
}
