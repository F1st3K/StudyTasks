﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR_48
{
    public partial class menu : Form
    {
        public menu()
        {
            InitializeComponent();
        }

        private void add_workers_Click(object sender, EventArgs e)
        {
            AddWorker addWorker = new AddWorker();
            addWorker.Show();
        }

        private void edit_workers_Click(object sender, EventArgs e)
        {
            EditWorker editWorker = new EditWorker();
            editWorker.Show();
        }

        private void remove_workers_Click(object sender, EventArgs e)
        {
            RemoveWorkers remove_workers = new RemoveWorkers();
            remove_workers.Show();
        }
    }
}
