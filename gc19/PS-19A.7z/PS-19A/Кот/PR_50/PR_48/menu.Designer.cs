﻿namespace PR_48
{
    partial class menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.remove_workers = new System.Windows.Forms.Button();
            this.edit_workers = new System.Windows.Forms.Button();
            this.add_workers = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.remove_workers);
            this.groupBox1.Controls.Add(this.edit_workers);
            this.groupBox1.Controls.Add(this.add_workers);
            this.groupBox1.Location = new System.Drawing.Point(40, 54);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(205, 282);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Выбор операции";
            // 
            // remove_workers
            // 
            this.remove_workers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.remove_workers.Location = new System.Drawing.Point(7, 196);
            this.remove_workers.Name = "remove_workers";
            this.remove_workers.Size = new System.Drawing.Size(192, 48);
            this.remove_workers.TabIndex = 2;
            this.remove_workers.Text = "Удалить";
            this.remove_workers.UseVisualStyleBackColor = true;
            this.remove_workers.Click += new System.EventHandler(this.remove_workers_Click);
            // 
            // edit_workers
            // 
            this.edit_workers.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.edit_workers.Location = new System.Drawing.Point(6, 119);
            this.edit_workers.Name = "edit_workers";
            this.edit_workers.Size = new System.Drawing.Size(192, 48);
            this.edit_workers.TabIndex = 1;
            this.edit_workers.Text = "Редактировать";
            this.edit_workers.UseVisualStyleBackColor = true;
            this.edit_workers.Click += new System.EventHandler(this.edit_workers_Click);
            // 
            // add_workers
            // 
            this.add_workers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.add_workers.Location = new System.Drawing.Point(7, 45);
            this.add_workers.Name = "add_workers";
            this.add_workers.Size = new System.Drawing.Size(192, 48);
            this.add_workers.TabIndex = 0;
            this.add_workers.Text = "Добавить";
            this.add_workers.UseVisualStyleBackColor = true;
            this.add_workers.Click += new System.EventHandler(this.add_workers_Click);
            // 
            // menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 365);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "menu";
            this.Text = "Главное меню";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button remove_workers;
        private System.Windows.Forms.Button edit_workers;
        private System.Windows.Forms.Button add_workers;
    }
}