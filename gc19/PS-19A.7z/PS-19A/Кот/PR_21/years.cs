﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var_10
{
    class years
    {
        int Year = 0;
        int Month = 1;
        int Days = 1;

        public years(int year)
        {
            Year = year;
        }

        public void calculations()
        {
            Month = Year * 30;
            Days = Year * 365;
        }

        public void print_result()
        {
            Console.WriteLine("Месяцы и дни соответственно: {0} {1}", Month, Days);
        }
    }
}
