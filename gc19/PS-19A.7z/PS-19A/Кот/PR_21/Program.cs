﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using var_10;

namespace var_10
{
    class Program
    {
        static void Main(string[] args)
        {
        m100:

            int year = 0;

            try
            {
                Console.WriteLine("Введите годы: ");
                year = Convert.ToInt32(Console.ReadLine());
            }

            catch (FormatException)
            {
                Console.WriteLine("Не верный формат, вводите целое число!");
                goto m100;
            }

            catch(OverflowException)
            {
                Console.WriteLine("Слишком большое число!");
                goto m100;
            }

            years Years = new years(year);

            Years.calculations();
            Years.print_result();

            Console.ReadKey();
        }
    }
}
