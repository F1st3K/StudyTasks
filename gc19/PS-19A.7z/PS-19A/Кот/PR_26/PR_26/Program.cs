﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Kot;

namespace PR_26
{
    class Program
    {
        static void Main(string[] args)
        {
            //_________________________________________________________Задание 1

            Console.WriteLine("Задание 1 - Введите четырёхзначное число: ");
            int num1;

            PR26 tasks = new PR26();

            try { num1 = Convert.ToInt32(Console.ReadLine()); tasks.task_1(num1); }

            catch (FormatException) { Console.WriteLine("Не верный формат!"); }
            catch (OverflowException) { Console.WriteLine("Переполнение!"); }

            //_________________________________________________________Задание 2

            Console.WriteLine("Задание 2 - Введите четырёхзначное число: ");
            int num2;

            try { num2 = Convert.ToInt32(Console.ReadLine()); tasks.task_2(num2); }

            catch (FormatException) { Console.WriteLine("Не верный формат!"); }
            catch (OverflowException) { Console.WriteLine("Переполнение!"); }

            //_________________________________________________________Задание 3

            Console.WriteLine("Задание 3 - Введите сторону равностороннего треугольника: ");

            try { double num3 = Convert.ToInt32(Console.ReadLine()); tasks.TriangleP(num3); }

            catch (OutOfMemoryException) { Console.WriteLine("Переполнение памяти!"); }
            catch (ArgumentOutOfRangeException) { Console.WriteLine("Выход за границу!"); }

            Console.ReadKey();
        }
    }
}
