﻿//1. Проверить истинность высказывания: "Сумма двух первых цифр данного целого положительного четырехзначного числа равна сумме двух его последних цифр".

//2. Задано целое положительное четырехзначное число N (N > 0). Найти разницу между произведениями первых двух и последних двух его цифр.

//3. Написать функцию double TriangleP(a) вещественного типа,
//вычисляющую по стороне a равностороннего треугольника его периметр P = 3·a (параметр a является вещественным).
//С помощью этой процедуры найти периметры трех равносторонних треугольников с данными сторонами.

//4. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими).
//Длина строки может быть разной. Определить и вывести слова, которые содержат ровно три буквы 'n'.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kot
{
    public class PR26
    {
        int[] mass = new int[4];

        int Num = 0, sum1 = 0, sum2 = 0, Pro1 = 1, Pro2 = 1, Raz = 0;
        string str;

        //_________________________________________________________Задание 1

        public void task_1(int num1)
        {
            if (num1 % 1 == 0)
            {
                if (num1 > 0)
                {
                    str = Convert.ToString(num1);

                    if (str.Length == 4)
                    {
                        num1 = Convert.ToInt32(str);

                        mass[0] = num1 / 1000;
                        mass[1] = (num1 / 100) % 10;
                        mass[2] = (num1 % 100) / 10;
                        mass[3] = num1 % 10;

                        sum1 = mass[0] + mass[1];
                        sum2 = mass[2] + mass[3];

                        if (sum1 == sum2)
                        {
                            Console.WriteLine("Суммы первых двух и последний двух цифр равны!");
                        }

                        else { Console.WriteLine("Суммы первых двух и последний двух цифр НЕ равны!"); }
                    }

                    else { Console.WriteLine("В числне не 4 цифры!"); }
                }

                else { Console.WriteLine("Число не положительное!"); }
            }

            else { Console.WriteLine("Число не целое!"); }
        }

        //_________________________________________________________Задание 2

        public void task_2(int num2)
        {
            Num = num2;

            if (Num % 1 == 0)
            {
                if (Num > 0)
                {
                    str = Convert.ToString(Num);

                    if (str.Length == 4)
                    {
                        Num = Convert.ToInt32(str);

                        mass[0] = Num / 1000;
                        mass[1] = (Num / 100) % 10;
                        mass[2] = (Num % 100) / 10;
                        mass[3] = Num % 10;

                        Pro1 = mass[0] * mass[1];
                        Pro2 = mass[2] * mass[3];

                        Raz = Pro1 - Pro2;

                        Console.WriteLine("Ответ: {0}", Raz);
                    }

                    else { Console.WriteLine("В числне не 4 цифры!"); }
                }

                else { Console.WriteLine("Число не положительное!"); }
            }

            else { Console.WriteLine("Число не целое!"); }
        }

        //_________________________________________________________Задание 3

        public double TriangleP(double num3)
        {
            double P = num3 * 3;
            Console.WriteLine("Периметр: {0}", P);

            return P;
        }
    }
}
