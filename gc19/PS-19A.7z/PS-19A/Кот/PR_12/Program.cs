﻿//1. Задано целое положительное четырехзначное число N (N > 0). 
//Найти разницу между произведениями первых двух и последних двух его цифр.

//2. Ввести два ненулевых положительных целых числа. Найти и вывести на экран их сумму, разность, произведение и частное.

//3. Проверить истинность высказывания: "Цифры данного целого положительного четырехзначного числа образуют возрастающую последовательность"

//4. Проверить истинность высказывания: "Данное целое положительное число является четным трехзначным числом".

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR_12
{
    class Program
    {
        static void Main(string[] args)
        {

            //_____________________________________________________________________Задание 1

            m100:

            try
            {
                Console.WriteLine("Введите целое положительное четырёхзначное число:");
                int Num = Convert.ToInt32(Console.ReadLine());

                int Num1_1 = Num;

                if (Num1_1 < 0)
                {
                    Console.WriteLine("Число не положительное, введите число заново!");
                    goto m100;
                }

                if (Num1_1 % 1 != 0)
                {
                    Console.WriteLine("Число не целое, введите число заново!");
                    goto m100;
                }

                int i = 0;

                while (Num1_1 != 0)
                {
                    Num1_1 = Num1_1 / 10;
                    i++;
                }

                if (i > 4 || i < 4)
                {
                    Console.WriteLine("В числе не 4 цифры, введите число заново!");
                    goto m100;
                }

                int[] mass = new int[4];

                mass[0] = Num / 1000;
                mass[1] = (Num / 100) % 10;
                mass[2] = (Num % 100) / 10;
                mass[3] = Num % 10;

                int IN1 = mass[0] * mass[1];
                int IN2 = mass[2] * mass[3];

                int Otv = IN1 - IN2;

                Console.WriteLine("Ответ:{0} ", Otv);
            }

            catch
            {
                Console.WriteLine("Возникло исключение!     Не верный формат!");
                goto m100;
            }

            //_____________________________________________________________________Задание 2

            m101:

            try
            {

                Console.WriteLine("Введите первое не нулевое положительное число:");
                float Num1 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Введите второе не нулевое положительное число:");
                float Num2 = Convert.ToInt32(Console.ReadLine());

                if (Num1 < 0 || Num1 == 0)
                {
                    Console.WriteLine("Число не подходит под условие!");
                }

                if (Num2 < 0 || Num2 == 0)
                {
                    Console.WriteLine("Число не подходит под условие!");
                }

                float Sum = Num1 + Num2;
                float Raz = Num1 - Num2;
                float Pro = Num1 * Num2;
                float Chs = Num1 / Num2;

                Console.WriteLine("Ответ:{0},{1},{2},{3} ", Sum, Raz, Pro, Chs);
            }

            catch
            {
                Console.WriteLine("Возникло исключение!     Не верный формат!");
                goto m101;
            }

            //_____________________________________________________________________Задание 3

            m102:

            try
            {
                Console.WriteLine("Введите положительное четырёхзначное число:");
                int Num1_2 = Convert.ToInt32(Console.ReadLine());

                int Num1_2_1 = Num1_2;

                if (Num1_2_1 < 0)
                {
                    Console.WriteLine("Число не положительное, введите число заново!");
                    goto m102;
                }

                int i = 0;

                while (Num1_2_1 != 0)
                {
                    Num1_2_1 = Num1_2_1 / 10;
                    i++;
                }

                if (i > 4 || i < 4)
                {
                    Console.WriteLine("В числе не 4 цифры, введите число заново!");
                    goto m102;
                }

                int[] mass1 = new int[4];

                mass1[0] = Num1_2 / 1000;
                mass1[1] = (Num1_2 / 100) % 10;
                mass1[2] = (Num1_2 % 100) / 10;
                mass1[3] = Num1_2 % 10;

                if (mass1[0] < mass1[1] && mass1[1] < mass1[2] && mass1[2] < mass1[3])
                {
                    Console.WriteLine("Цифры данного целого положительного четырехзначного числа образуют возрастающую последовательность!");
                }

                else
                {
                    Console.WriteLine("Цифры данного целого положительного четырехзначного числа НЕ образуют возрастающую последовательность!");
                }

            }

            catch
            {
                Console.WriteLine("Возникло исключение!     Не верный формат!");
                goto m102;
            }

            //_____________________________________________________________________Задание 4

            m103:

            try
            {
                Console.WriteLine("Введите целое положительное трёхзначное число:");
                int Numb = Convert.ToInt32(Console.ReadLine());

                int Numb1 = Numb;

                if (Numb < 0)
                {
                    Console.WriteLine("Число не положительное!");
                    goto m103;
                }

                if (Numb1 % 1 != 0)
                {
                    Console.WriteLine("Число не целое, введите число заново!");
                    goto m103;
                }

                int i = 0;

                while (Numb1 != 0)
                {
                    Numb1 = Numb1 / 10;
                    i++;
                }

                if (i > 3 || i < 3)
                {
                    Console.WriteLine("В числе не 3 цифры, введите число заново!");
                    goto m103;
                }

                else
                {
                    Console.WriteLine("Все условия совпали!");
                }
            }

            catch
            {
                Console.WriteLine("Возникло исключение!     Не верный формат!");
                goto m103;
            }

            while (Console.ReadKey().Key != ConsoleKey.Escape);

        }
    }
}
