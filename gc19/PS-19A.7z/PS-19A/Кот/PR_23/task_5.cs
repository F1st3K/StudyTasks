﻿//5. Вводится строка, содержащая буквы и цифры. Длина строки может быть разной. Вывести сумму и произведение цифр этой введенной строки.
//Чтобы избежать целочисленного переполнения при произведении,
//вычислять это выражение с помощью вещественной переменной и выводить его как вещественное число.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using var_10;

namespace var_10
{
    public class task_5
    {
        string STR;

        double num = 0;
        double sum = 0;
        double pro = 0;

        ///<summary>
        ///Передаю данные в конструтор
        ///</summary>

        public task_5(string str)
        {
            STR = str;
        }

        public void calculation()
        {
            for (int i = 0; i < STR.Length; i++)
            {
                if (STR[i] == '0' || STR[i] == '1' || STR[i] == '2' || STR[i] == '3' || STR[i] == '4' || STR[i] == '5' || STR[i] == '6' || STR[i] == '7' || STR[i] == '8' || STR[i] == '9')
                {
                    num = STR[i] - '0';

                    sum += num;
                    pro *= num;
                }
            }

            Console.WriteLine("Сумма и произведение соответственно: {0} {1}", sum, pro);
        }
    }
}
