﻿//2. Даны пять целых ненулевых положительных чисел. Найти сумму двух наименьших чисел.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using var_10;

namespace var_10
{
    public class task_2
    {
        int[] mas = new int[5];
        int pos = 0, pos1 = 0;

        ///<summary>
        ///Пеередаю число в конструктор
        ///</summary>

        public task_2(int[] mass)
        {
            mas = mass;
        }

        ///<summary>
        ///Ищу первое и и второе наименьшее число
        ///</summary>

        public void calculation()
        {
            for (int i = 0; i < mas.Length; i++)
            {
                pos = mas[i];
                i++;

                if (pos < mas[i])
                {
                    pos = mas[i];
                }
            }

            for (int i = 0; i < mas.Length; i++)
            {
                pos1 = mas[i];
                i++;

                if (pos1 < mas[i] && pos1 != pos)
                {
                    pos1 = mas[i];
                }
            }
        }
    }
}
