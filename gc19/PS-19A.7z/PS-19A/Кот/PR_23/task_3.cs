﻿//3. В вещественном массиве известны данные о количестве осадков, выпавших за каждый день месяца N (N - любой месяц в году).
//Найти общее число осадков, выпавших по нечетным числам этого месяца.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using var_10;

namespace var_10
{
    public class task_3
    {
        int[] mas = new int[30];
        int sum = 0;

        int flag_t = 0;

        ///<summary>
        ///передаю массив в конструктор
        ///</summary>

        public task_3(int[] mass)
        {
            mas = mass;
        }

        ///<summary>
        ///ищу осадки по нечётным дням 
        ///</summary>

        public void calculation()
        {
            for (int i = 0; i < 30; i++)
            {
                if (mas[i] % 2 != 0)
                {
                    sum += mas[i];
                }
            }
        }
    }
}
