﻿//1. Проверить истинность высказывания: "Цифры данного целого положительного трехзначного числа, введенного с клавиатуры, образуют убывающую последовательность".

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using var_10;

namespace var_10
{
    public class task_1
    {
        int Num = 0;

        int num1 = 0;
        int num2 = 0;
        int num3 = 0;

        int flag = 0;

        ///<summary>
        ///Пеередаю число в конструктор
        ///</summary>

        public task_1(int num)
        {
            Num = num;
        }

        public int calculation()
        {
            if (Num > 0)
            {
                if (Num % 1 == 0)
                {
                    ///<summary>
                    ///Проверка на 3 цифры в числе
                    ///</summary>

                    if (Num.ToString().Length == 3)
                    {
                        num1 = Num / 1000;
                        num2 = (Num / 100) % 10;
                        num3 = (Num % 100) / 10;
                    }

                    else
                    {
                        Console.WriteLine("В числе не 3 цифры!");
                        return flag = 1;
                    }

                    if (num1 > num2 && num2 > num3)
                    {
                        Console.WriteLine("Последовательность убывает!");
                        return flag = 0;
                    }

                    else
                    {
                        Console.WriteLine("Последовательность НЕ убывает!");
                        return flag = 1;
                    }
                }

                else
                {
                    Console.WriteLine("Число не целое!");
                    return flag = 1;
                }
            }

            else
            {
                Console.WriteLine("Число НЕ положительное!");
                return flag = 1;
            }
        }
    }
}
