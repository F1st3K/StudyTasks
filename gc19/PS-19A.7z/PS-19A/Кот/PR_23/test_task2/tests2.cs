﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using var_10;

namespace var_10
{
    [TestClass]
    public class tests2
    {
        [TestMethod]
        public void task_test_1()
        {
            task_2 test = new task_2();
        }
    }
}
