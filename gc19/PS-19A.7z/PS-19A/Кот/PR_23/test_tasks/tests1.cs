﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using var_10;

namespace var_10
{
    //__________________________________________________________Задание 1

    [TestClass]
    public class tests1
    {
        int num1 = 321;

        [TestMethod]
        public void task_test_1()
        {
            task_1 task1 = new task_1(num1);
            int res = task1.calculation();

            Assert.AreEqual(1, res);
        }

        [TestMethod]
        public void task_test_2()
        {
            task_1 task1 = new task_1(num1);
            int res = task1.calculation();

            Assert.AreEqual(1, res);
        }

        [TestMethod]
        public void task_test_3()
        {
            task_1 task1 = new task_1(num1);
            int res = task1.calculation();
            
            Assert.AreEqual(1, res);
        }

        [TestMethod]
        public void task_test_4()
        {
            task_1 task1 = new task_1(num1);
            int res = task1.calculation();
            
            Assert.AreEqual(1, res);
        }

        [TestMethod]
        public void task_test_5()
        {
            task_1 task1 = new task_1(num1);
            int res = task1.calculation();
            
            Assert.AreEqual(0, res);
        }
    }

    //__________________________________________________________Задание 2

    public class tests2
    {
        [TestMethod]
        public void task_test_2_1()
        {
            int[] mass = new int[5] {1, 7, 2, 8, 9};

            task_2 task2 = new task_2(mass);

            //не придумал никаких тестов!
        }
    }

    //__________________________________________________________Задание 3

    public class tests3
    {
        [TestMethod]
        public void task_test_3_1()
        {
            int[] mass = new int[30] { 1, 7, 2, 8, 9, 5, 7, 4, 6, 2, 8, 4, 2, 9, 12, 56, 21, 78, 32, 12, 67, 4, 8, 32, 12, 98, 3, 7, 3, 9 };

            task_3 task3 = new task_3(mass);

            //не придумал никаких тестов!
        }
    }

    //__________________________________________________________Задание 4

        public class tests4
        {
            double num = 10;

            [TestMethod]
            public void task_test_4_1()
            {
                task_4 task4 = new task_4(num);
                double res = task4.Factorial();

                Assert.AreEqual(0, res);
            }
        }

    //__________________________________________________________Задание 5

    public class tests5
    {
        [TestMethod]
        public void task_test_5_1()
        {
            string str = "skdfh23jklgnj7kkjlsdf234kjlg09jfng990ksdnf93kl0";

            task_5 task5 = new task_5(str);
        }
    }
}
