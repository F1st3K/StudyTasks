﻿//4. Написать функцию double Factorial(N) вещественного типа, вычисляющую значение факториала N! = 1*2*…*N (N > 0 — параметр целого типа;
//вещественное возвращаемое значение используется для того, чтобы избежать целочисленного переполнения при больших значениях N).

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using var_10;

namespace var_10
{
    public class task_4
    {
        double Num = 0;
        double flag = 0;

        double fuc = 1;

        ///<summary>
        ///Передаю данные в конструтор
        ///</summary>

        public task_4(double num)
        {
            Num = num;
        }

        public double Factorial()
        {
            if (Num == 0)
            {
                Console.WriteLine("Нуль вводить нельзя!");
            }

            for (int i = 1; i < Num; i++)
            {
                fuc *= i;
            }

            if (Num == 0)
            {
                return 1;
            }

            return 0;
        }
    }
}
