﻿namespace Password_Generator
{
    partial class PassGenerator
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PassGenerator));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Count = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Len = new System.Windows.Forms.TextBox();
            this.Symbols = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Uppercase = new System.Windows.Forms.CheckBox();
            this.Lowercase = new System.Windows.Forms.CheckBox();
            this.Digits = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Result = new System.Windows.Forms.ListBox();
            this.Generate = new System.Windows.Forms.Button();
            this.Language = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Change_the_language = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Count);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.Len);
            this.groupBox1.Controls.Add(this.Symbols);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Uppercase);
            this.groupBox1.Controls.Add(this.Lowercase);
            this.groupBox1.Controls.Add(this.Digits);
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // Count
            // 
            resources.ApplyResources(this.Count, "Count");
            this.Count.Name = "Count";
            this.Count.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Count_KeyPress);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // Len
            // 
            resources.ApplyResources(this.Len, "Len");
            this.Len.Name = "Len";
            this.Len.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Len_KeyPress);
            // 
            // Symbols
            // 
            resources.ApplyResources(this.Symbols, "Symbols");
            this.Symbols.Name = "Symbols";
            this.Symbols.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // Uppercase
            // 
            resources.ApplyResources(this.Uppercase, "Uppercase");
            this.Uppercase.Name = "Uppercase";
            this.Uppercase.UseVisualStyleBackColor = true;
            // 
            // Lowercase
            // 
            resources.ApplyResources(this.Lowercase, "Lowercase");
            this.Lowercase.Name = "Lowercase";
            this.Lowercase.UseVisualStyleBackColor = true;
            // 
            // Digits
            // 
            resources.ApplyResources(this.Digits, "Digits");
            this.Digits.Name = "Digits";
            this.Digits.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Result);
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // Result
            // 
            this.Result.FormattingEnabled = true;
            resources.ApplyResources(this.Result, "Result");
            this.Result.Name = "Result";
            // 
            // Generate
            // 
            resources.ApplyResources(this.Generate, "Generate");
            this.Generate.Name = "Generate";
            this.Generate.UseVisualStyleBackColor = true;
            this.Generate.Click += new System.EventHandler(this.Generate_Click);
            // 
            // Language
            // 
            this.Language.AutoCompleteCustomSource.AddRange(new string[] {
            resources.GetString("Language.AutoCompleteCustomSource"),
            resources.GetString("Language.AutoCompleteCustomSource1")});
            this.Language.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            resources.ApplyResources(this.Language, "Language");
            this.Language.FormattingEnabled = true;
            this.Language.Name = "Language";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Change_the_language);
            this.groupBox3.Controls.Add(this.Language);
            this.groupBox3.Controls.Add(this.label1);
            resources.ApplyResources(this.groupBox3, "groupBox3");
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.TabStop = false;
            // 
            // Change_the_language
            // 
            resources.ApplyResources(this.Change_the_language, "Change_the_language");
            this.Change_the_language.Name = "Change_the_language";
            this.Change_the_language.UseVisualStyleBackColor = true;
            this.Change_the_language.Click += new System.EventHandler(this.Change_the_language_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightGray;
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            // 
            // PassGenerator
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.Generate);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "PassGenerator";
            this.ShowIcon = false;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PassGenerator_FormClosing);
            this.Load += new System.EventHandler(this.PassGenerator_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox Symbols;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox Uppercase;
        private System.Windows.Forms.CheckBox Lowercase;
        private System.Windows.Forms.CheckBox Digits;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Generate;
        private System.Windows.Forms.TextBox Len;
        private System.Windows.Forms.ComboBox Language;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Change_the_language;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Count;
        private System.Windows.Forms.ListBox Result;
    }
}

