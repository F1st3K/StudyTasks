﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using System.IO;

namespace Password_Generator
{
    public partial class PassGenerator : Form
    {
        public PassGenerator()
        {
            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {
                Thread.CurrentThread.CurrentUICulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
                Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.GetCultureInfo(Properties.Settings.Default.Language);
            }

            InitializeComponent();
        }

        HashSet<Delegate> Functions = new HashSet<Delegate>();
        List<string> Passwords = new List<string>();

        public void Generate_Click(object sender, EventArgs e)
        {
            Passwords.Clear();
            Result.Items.Clear();

            File.WriteAllBytes(@"password.txt", new byte[0]);

            if (Convert.ToInt32(Count.Text) <= 0)
            {
                MessageBox.Show(Messages.CountExeption);
                return;
            }

            if (Convert.ToInt32(Count.Text) > 20)
            {
                MessageBox.Show(Messages.LengthException);
                return;
            }

            if (Len.Text == "" || Convert.ToInt32(Len.Text) > 20 || Convert.ToInt32(Len.Text) < 8)
            {
                MessageBox.Show(Messages.TextExceptionLen);
                return;
            }

            if (Digits.Checked == false && Lowercase.Checked == false && Uppercase.Checked == false && Symbols.Checked == false)
            {
                MessageBox.Show(Messages.GenegateException);
                return;
            }

            if (Digits.Checked)
                Functions.Add(new Delegate(digits));
            else if (Digits.Checked == false) Functions.Remove(new Delegate(digits));

            if (Lowercase.Checked)
                Functions.Add(new Delegate(lowercase));
            else if (Lowercase.Checked == false) Functions.Remove(new Delegate(lowercase));

            if (Uppercase.Checked)
                Functions.Add(new Delegate(uppercase));
            else if (Uppercase.Checked == false) Functions.Remove(new Delegate(uppercase));

            if (Symbols.Checked)
                Functions.Add(new Delegate(symbols));
            else if (Symbols.Checked == false) Functions.Remove(new Delegate(symbols));

            Generator();
        }

        public static Random rnd = new Random();
        delegate string Delegate();

        public static string digits()
        {
            string rez = "";

            rez += Convert.ToString(rnd.Next(0, 10));

            return rez;
        }

        public static string lowercase()
        {
            string rez = "";

            rez += (char)rnd.Next('a', 'z' + 1);

            return rez;
        }

        public static string uppercase()
        {
            string rez = "";

            rez += (char)rnd.Next('A', 'Z' + 1);

            return rez;
        }

        public static string symbols()
        {
            string rez = "";

            rez += (char)rnd.Next('!', '/');

            return rez;
        }

        int cout = 1;
        string Password = "";

        Random NewChar = new Random();
        public void Generator()
        {
            Password = "";

            for (int l = 0; l < Convert.ToInt32(Len.Text); l++)
            {
                Delegate FTest = Functions.ElementAt(NewChar.Next(Functions.Count));

                Password += FTest();
            }

            try
            {
                Passwords.Add(Password);
                Result.Items.Add(Password + "\n");
            }

            catch (InvalidOperationException) { }

            if (cout <= Convert.ToInt32(Count.Text) - 1)
            {
                cout++;

                if (cout - 1 < Convert.ToInt32(Count.Text))
                {
                    Generator();
                }
            }

            else { cout = 1; }

            WritingToAfile();
        }

        private void Len_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 59) && e.KeyChar != 8)
                e.Handled = true;
        }

        private void PassGenerator_Load(object sender, EventArgs e)
        {
            Language.DataSource = new System.Globalization.CultureInfo[]
            {
                System.Globalization.CultureInfo.GetCultureInfo("ru-RU"),
                System.Globalization.CultureInfo.GetCultureInfo("en-US")
            };

            Language.DisplayMember = "NativeName";
            Language.ValueMember = "Name";

            if (!String.IsNullOrEmpty(Properties.Settings.Default.Language))
            {
                Language.SelectedValue = Properties.Settings.Default.Language;
            }
        }

        private void PassGenerator_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void Change_the_language_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Language = Language.SelectedValue.ToString();
            Properties.Settings.Default.Save();

            Application.Restart();
        }

        public void WritingToAfile()
        {
            using (StreamWriter sw = new StreamWriter(@"password.txt"))
            {
                foreach (string item in Passwords)
                {
                    sw.WriteLine(item + "\n");
                } 
            }
        }

        private void Count_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar <= 47 || e.KeyChar >= 59) && e.KeyChar != 8)
                e.Handled = true;
        }
    }
}