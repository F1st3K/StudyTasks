//1. Проверить истинность высказывания:
//"Данные целые числа X и Y являются координатами точки, лежащей во второй координатной четверти".

//2. В вещественном массиве известны данные о количестве осадков,
//выпавших за каждый день месяца N (N - любой месяц в году).
//Найти общее число осадков, выпавших по четным числам месяца.

package main

import (
	"io/ioutil"
	"os"
	"strconv"
	"strings"
	"unicode"
)

func main() {

	//___________________________________________Задание 1

	println("Задание 1")

	f, err := os.Create("output_1.txt")
	if err != nil {
		panic(err)
	}

	f, err = os.Open("input_1.txt")
	check(err)

	c, err := ioutil.ReadAll(f)
	check(err)

	s_mass := strings.Split(string(c), " ")

	X, err := strconv.Atoi(string(s_mass[0]))
	Y, err := strconv.Atoi(string(s_mass[1]))

	var rez string

	if X < 0 && Y > 0 {

		rez = "Высказывание верно!"
	} else {

		rez = "Высказывание НЕ верно!"
	}

	println(rez)

	err = ioutil.WriteFile("output_1.txt", []byte(rez), 0644)
	check(err)

	err = f.Close()
	if err != nil {
		return
	}

	//___________________________________________Задание 2

	println("Задание 2")

	var mass_1 [30]int

	kol := 0

	f, err = os.Create("output_2.txt")
	if err != nil {
		panic(err)
	}

	f, err = os.Open("input_2.txt")
	check(err)

	c, err = ioutil.ReadAll(f)
	check(err)

	s_mass_1 := strings.Split(string(c), " ")

	for i := 0; i < 30; i++ {

		mass_1[i], err = strconv.Atoi(string(s_mass_1[i]))

		if i%2 == 0 {

			kol += mass_1[i]
		}
	}

	println("Сумма осадков по чётным дням: ", kol)

	err = ioutil.WriteFile("output_2.txt", []byte(strconv.Itoa(kol)), 0644)
	check(err)

	f.Close()

	//___________________________________________Задание 3

	println("Задание 3")

	f, err = os.Create("output_3.txt")
	if err != nil {
		panic(err)
	}

	f, err = os.Open("input_3.txt")
	check(err)

	c, err = ioutil.ReadAll(f)
	check(err)

	s_mass_1 = strings.Split(string(c), " ")

	var mass_2 [30]int

	for i := 0; i < 30; i++ {

		mass_2[i], err = strconv.Atoi(string(s_mass_1[i]))
	}

	sr1, sr2, sr3 := 0, 0, 0
	cout := 0

	for i := 0; i < 10; i++ {

		cout += mass_2[i]
	}

	sr1 = cout / 10
	cout = 0

	for i := 10; i < 20; i++ {

		cout += mass_2[i]
	}

	sr2 = cout / 10

	for i := 20; i < 30; i++ {

		cout += mass_2[i]
	}

	sr3 = cout / 10

	println("Среднее число осадков за 3 декады соответственно: ", int(sr1), int(sr2), int(sr3))

	var rez1 string

	rez1 += strconv.Itoa(sr1) + " " + strconv.Itoa(sr2) + " " + strconv.Itoa(sr3)

	err = ioutil.WriteFile("output_3.txt", []byte(rez1), 0644)
	check(err)

	f.Close()

	//___________________________________________Задание 4

	var year int

	println("Задание 4")

	f, err = os.Create("output_4.txt")
	if err != nil {
		panic(err)
	}

	f, err = os.Open("input_4.txt")
	check(err)

	c, err = ioutil.ReadAll(f)
	check(err)

	year, _ = strconv.Atoi(string(c))

	rezf := IsLeapYear(year)
	println("Результат: ", rezf)

	err = ioutil.WriteFile("output_4.txt", []byte(rezf), 0644)
	check(err)

	f.Close()

	//_______________________________________________Задание 5

	println("Задание 5")

	f, err = os.Create("output_5.txt")
	if err != nil {
		panic(err)
	}

	f, err = os.Open("input_5.txt")
	check(err)

	c, err = ioutil.ReadAll(f)
	check(err)

	var str5 string
	cout1 := 0

	str5 = string(c)

	for i := 0; i < len(str5); i++ {

		if str5[i] < unicode.MaxASCII && unicode.IsLower(rune(str5[i])) {
			cout1++
		}
	}

	println("Результат:", cout1)

	err = ioutil.WriteFile("output_5.txt", []byte(strconv.Itoa(cout1)), 0644)
	check(err)

	f.Close()
}

func check(e error) {
	if e != nil {
		panic(e)
	}
}

func IsLeapYear(year int) string {

	var rez string

	if year%4 == 0 || year%400 == 0 {

		rez = "true"

	} else {

		rez = "false"
	}

	return rez
}
