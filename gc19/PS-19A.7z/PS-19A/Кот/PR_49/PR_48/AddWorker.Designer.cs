﻿namespace PR_48
{
    partial class AddWorker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1Workers = new System.Windows.Forms.DataGridView();
            this.AddInDB = new System.Windows.Forms.Button();
            this.surname = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.patronymic = new System.Windows.Forms.TextBox();
            this.post = new System.Windows.Forms.TextBox();
            this.number = new System.Windows.Forms.TextBox();
            this.surnameL = new System.Windows.Forms.Label();
            this.nameL = new System.Windows.Forms.Label();
            this.patronymicL = new System.Windows.Forms.Label();
            this.postL = new System.Windows.Forms.Label();
            this.numberL = new System.Windows.Forms.Label();
            this.Append_strings = new System.Windows.Forms.GroupBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1Workers)).BeginInit();
            this.Append_strings.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(5, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(799, 294);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1Workers);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(791, 268);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Сотрудники";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1Workers
            // 
            this.dataGridView1Workers.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1Workers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1Workers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1Workers.Location = new System.Drawing.Point(3, 3);
            this.dataGridView1Workers.Name = "dataGridView1Workers";
            this.dataGridView1Workers.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1Workers.Size = new System.Drawing.Size(785, 262);
            this.dataGridView1Workers.TabIndex = 0;
            // 
            // AddInDB
            // 
            this.AddInDB.Location = new System.Drawing.Point(683, 304);
            this.AddInDB.Name = "AddInDB";
            this.AddInDB.Size = new System.Drawing.Size(117, 37);
            this.AddInDB.TabIndex = 2;
            this.AddInDB.Text = "Добавить";
            this.AddInDB.UseVisualStyleBackColor = true;
            this.AddInDB.Click += new System.EventHandler(this.AddInDB_Click);
            // 
            // surname
            // 
            this.surname.Location = new System.Drawing.Point(119, 19);
            this.surname.MaxLength = 40;
            this.surname.Name = "surname";
            this.surname.Size = new System.Drawing.Size(194, 20);
            this.surname.TabIndex = 3;
            this.surname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.surname_KeyPress);
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(119, 45);
            this.name.MaxLength = 40;
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(194, 20);
            this.name.TabIndex = 4;
            this.name.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.name_KeyPress);
            // 
            // patronymic
            // 
            this.patronymic.Location = new System.Drawing.Point(119, 71);
            this.patronymic.MaxLength = 80;
            this.patronymic.Name = "patronymic";
            this.patronymic.Size = new System.Drawing.Size(194, 20);
            this.patronymic.TabIndex = 5;
            this.patronymic.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.patronymic_KeyPress);
            // 
            // post
            // 
            this.post.Location = new System.Drawing.Point(119, 97);
            this.post.MaxLength = 40;
            this.post.Name = "post";
            this.post.Size = new System.Drawing.Size(194, 20);
            this.post.TabIndex = 6;
            this.post.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.post_KeyPress);
            // 
            // number
            // 
            this.number.Location = new System.Drawing.Point(119, 123);
            this.number.MaxLength = 11;
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(194, 20);
            this.number.TabIndex = 7;
            this.number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.number_KeyPress);
            // 
            // surnameL
            // 
            this.surnameL.AutoSize = true;
            this.surnameL.Location = new System.Drawing.Point(21, 25);
            this.surnameL.Name = "surnameL";
            this.surnameL.Size = new System.Drawing.Size(56, 13);
            this.surnameL.TabIndex = 8;
            this.surnameL.Text = "Фамилия";
            // 
            // nameL
            // 
            this.nameL.AutoSize = true;
            this.nameL.Location = new System.Drawing.Point(21, 48);
            this.nameL.Name = "nameL";
            this.nameL.Size = new System.Drawing.Size(29, 13);
            this.nameL.TabIndex = 9;
            this.nameL.Text = "Имя";
            // 
            // patronymicL
            // 
            this.patronymicL.AutoSize = true;
            this.patronymicL.Location = new System.Drawing.Point(21, 74);
            this.patronymicL.Name = "patronymicL";
            this.patronymicL.Size = new System.Drawing.Size(54, 13);
            this.patronymicL.TabIndex = 10;
            this.patronymicL.Text = "Отчество";
            // 
            // postL
            // 
            this.postL.AutoSize = true;
            this.postL.Location = new System.Drawing.Point(21, 100);
            this.postL.Name = "postL";
            this.postL.Size = new System.Drawing.Size(65, 13);
            this.postL.TabIndex = 11;
            this.postL.Text = "Должность";
            // 
            // numberL
            // 
            this.numberL.AutoSize = true;
            this.numberL.Location = new System.Drawing.Point(21, 126);
            this.numberL.Name = "numberL";
            this.numberL.Size = new System.Drawing.Size(93, 13);
            this.numberL.TabIndex = 12;
            this.numberL.Text = "Номер телефона";
            // 
            // Append_strings
            // 
            this.Append_strings.Controls.Add(this.surname);
            this.Append_strings.Controls.Add(this.numberL);
            this.Append_strings.Controls.Add(this.name);
            this.Append_strings.Controls.Add(this.postL);
            this.Append_strings.Controls.Add(this.patronymic);
            this.Append_strings.Controls.Add(this.patronymicL);
            this.Append_strings.Controls.Add(this.post);
            this.Append_strings.Controls.Add(this.nameL);
            this.Append_strings.Controls.Add(this.number);
            this.Append_strings.Controls.Add(this.surnameL);
            this.Append_strings.Location = new System.Drawing.Point(12, 304);
            this.Append_strings.Name = "Append_strings";
            this.Append_strings.Size = new System.Drawing.Size(335, 163);
            this.Append_strings.TabIndex = 13;
            this.Append_strings.TabStop = false;
            this.Append_strings.Text = "Добавление";
            // 
            // AddWorker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 489);
            this.Controls.Add(this.Append_strings);
            this.Controls.Add(this.AddInDB);
            this.Controls.Add(this.tabControl1);
            this.Name = "AddWorker";
            this.Text = "Добавление сотрудника";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1Workers)).EndInit();
            this.Append_strings.ResumeLayout(false);
            this.Append_strings.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1Workers;
        private System.Windows.Forms.Button AddInDB;
        private System.Windows.Forms.TextBox surname;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.TextBox patronymic;
        private System.Windows.Forms.TextBox post;
        private System.Windows.Forms.TextBox number;
        private System.Windows.Forms.Label surnameL;
        private System.Windows.Forms.Label nameL;
        private System.Windows.Forms.Label patronymicL;
        private System.Windows.Forms.Label postL;
        private System.Windows.Forms.Label numberL;
        private System.Windows.Forms.GroupBox Append_strings;
    }
}

