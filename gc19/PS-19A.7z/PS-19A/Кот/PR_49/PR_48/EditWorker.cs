﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PR_48
{
    public partial class EditWorker : Form
    {
        public EditWorker()
        {
            InitializeComponent();
        }

        string ID_worker = "";

        private void Edit_worker_Click(object sender, EventArgs e)
        {
            if (surname.Text == "" || name.Text == "" || patronymic.Text == "" || post.Text == "" || number.Text == "")
            {
                MessageBox.Show("Ошибка! Заполните все поля!", "Сообщение пользователю", MessageBoxButtons.OK);
            }
            else
            {
                string con = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source = worker.mdb;"; // строка подключения
                OleDbConnection oleDbConn = new OleDbConnection(con); // создаем подключение
                oleDbConn.Open(); // открываем подключение к базе
                OleDbCommand sql = new OleDbCommand("UPDATE workers SET surname_worker = '" + surname.Text.ToString() + "', name_worker = '" + name.Text + "', patronymic_worker = '" + patronymic.Text + "', post = '" + post.Text + "', phone_number = '" + number.Text + "' Where id = " + Convert.ToInt32(ID_worker) + ";"); // создаем запрос
                sql.Connection = oleDbConn; // привязываем запрос к конекту
                sql.ExecuteNonQuery(); //выполнение

                oleDbConn.Close();

                ViewInDataBase();

                surname.Text = "";
                name.Text = "";
                patronymic.Text = "";
                post.Text = "";
                number.Text = "";

                //Edit_worker.Enabled = false;
            }
        }

        public void ViewInDataBase()
        {
            try
            {
                string connection = "Provider = Microsoft.Jet.OLEDB.4.0; Data Source = worker.mdb;";

                // создаем подключение
                using (OleDbConnection oleDbConnection = new OleDbConnection(connection)) //подключение
                {
                    // создаем виртуальную таблицу
                    DataTable memory_table = new DataTable(); //вииртуальная таблица в оперативной памяти

                    // открываем подключение к базе
                    oleDbConnection.Open();

                    // создаем запрос к бд
                    OleDbCommand sql1 = new OleDbCommand("SELECT * FROM workers;");

                    // привязываем запрос к коннекту
                    sql1.Connection = oleDbConnection;

                    // выполняем запрос
                    sql1.ExecuteNonQuery();

                    // создаем новый адаптер для манипулирования данными
                    OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

                    // заполняем адаптер полученными данными из базы (файла) MS Access
                    da1.Fill(memory_table);

                    //остальные поля обязательно!
                    memory_table.Columns["surname_worker"].ColumnName = "Фамилия";
                    memory_table.Columns["name_worker"].ColumnName = "Имя";
                    memory_table.Columns["patronymic_worker"].ColumnName = "Отчество";
                    memory_table.Columns["post"].ColumnName = "Должность";
                    memory_table.Columns["phone_number"].ColumnName = "Номер телефона";

                    // связываем интерфейс с бд
                    dataGridView1Workers.DataSource = memory_table;

                    dataGridView1Workers.Columns[0].Visible = false;
                    dataGridView1Workers.Columns[1].Width = 80;
                    dataGridView1Workers.Columns[2].Width = 90;
                    dataGridView1Workers.Columns[3].Width = 200;
                    dataGridView1Workers.Columns[4].Width = 70;
                    dataGridView1Workers.Columns[5].Width = 90;
                }
            }

            catch { MessageBox.Show("Ошибка. Такой таблицы нет!"); }
        }

        private void EditWorker_Load(object sender, EventArgs e)
        {
            ViewInDataBase();
        }

        private void dataGridView1Workers_RowHeaderMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            //получаем одну запись по выделению в dataGridView
            ID_worker = dataGridView1Workers.SelectedCells[0].Value.ToString();

            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source = worker.mdb;"; // строка подключения
            OleDbConnection oleDbConn1 = new OleDbConnection(con1); // создаем подключение
            DataTable dt1 = new DataTable(); // создаем таблицу

            oleDbConn1.Open(); // открываем подключение к базе
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM workers Where id = " + Convert.ToInt32(ID_worker) + ";"); // создаем запрос
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);
            sql1.Connection = oleDbConn1; // привязываем запрос к конекту
            sql1.ExecuteNonQuery(); //выполнение

            da1.Fill(dt1);

            //разбиваем полученную информацию из БД по текстбоксам на форме
            surname.Text = dt1.Rows[0].ItemArray.GetValue(1).ToString();
            name.Text = dt1.Rows[0].ItemArray.GetValue(2).ToString();
            patronymic.Text = dt1.Rows[0].ItemArray.GetValue(3).ToString();
            post.Text = dt1.Rows[0].ItemArray.GetValue(4).ToString();
            number.Text = dt1.Rows[0].ItemArray.GetValue(5).ToString();

            oleDbConn1.Close();
        }
    }
}
