﻿//ВАРИАНТ № А14/Б32
//1. Дан целочисленный массив, состоящий из N элементов (N > 0). 
//Преобразовать массив, прибавив к четным числам первый элемент. Первый и последний элементы массива не изменять. 
//Вывести новый полученный массив.

//2. Дан целочисленный массив, состоящий из N элементов (N > 0). 
//Найти максимальный и минимальный элемент в массиве и вычислить их сумму.

//3. Написать функцию int Min5(A, B, C, D, E) целого типа, возвращающую одно
//минимальное значение из 5-и своих аргументов (параметры A, B, C, D и E - целые числа).

//4. Написать функцию bool Even(K) логического типа, возвращающую True, если целый параметр 
//K является четным, и False в противном случае. С ее помощью найти количество четных чисел 
//в наборе из 10 целых положительных чисел.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR17
{
    class Program
    {
        #region Основная функция
        static void Main(string[] args)
        {
            int N;

            Console.WriteLine("Задание1");
            m1:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m1;
            }
            if (N < 20)
            {
                Console.WriteLine("Кол-во чисел в массиве должно быть больше или равно 20");
                goto m1;
            }

            int[] MAS = TASK1(N);
            Console.Write("Ответ: ");
            for (int z = 0; z < N; z++)
            {
                Console.Write(MAS[z] + " ");
            }
            Console.WriteLine();


            Console.WriteLine("Задание2");
            ma2:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto ma2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto ma2;
            }
            if (N < 20)
            {
                Console.WriteLine("Кол-во чисел в массиве должно быть больше или равно 20");
                goto ma2;
            }

            int SUM = TASK2(N);

            Console.WriteLine("Ответ: Сумма минимального и максимального числа равна " + SUM);

            int A1, A2, A3, A4, A5;
            Console.WriteLine("Задание3");

            mk1:
            try
            {
                Console.WriteLine("Введите 1 целое число");
                A1 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto mk1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto mk1;
            }

            mk2:
            try
            {
                Console.WriteLine("Введите 2 целое число");
                A2 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto mk2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto mk2;
            }

            mk3:
            try
            {
                Console.WriteLine("Введите 3 целое число");
                A3 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto mk3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto mk3;
            }

            mk4:
            try
            {
                Console.WriteLine("Введите 4 целое число");
                A4 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto mk4;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto mk4;
            }

        mk5:
            try
            {
                Console.WriteLine("Введите 5 целое число");
                A5 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto mk5;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto mk5;
            }

            int otv3 = Min5(A1, A2, A3, A4, A5);
            Console.WriteLine("Ответ: Минимальное число = " + otv3);

            Console.WriteLine("Задание4");

            int[] SAM = new int[10];

            for (int x = 0; x < 10; x++)
            {
            ml1:
                try
                {
                    x++;
                    Console.WriteLine("Введите " + x + " целое число");
                    x--;
                    SAM[x] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto ml1;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto ml1;
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Ошибка переполнения массива");
                    goto ml1;
                }
            }

            int col = 0;

            for (int x = 0; x < 10; x++)
            {
                if (Even(SAM[x]) == true)
                {
                    col++;
                }
            }

            Console.WriteLine("Ответ: " + col + " чисел являются четными");

            Console.ReadKey();
        }
        #endregion

        #region Функция 1 задания
        static int[] TASK1(int N)
        {
            int i;
            int[] MAS1 = new int[N];


            for (i = 0; i < N; i++)
            {
            m2:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива");
                    i--;
                    MAS1[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m2;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m2;
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Ошибка переполнения массива");
                    goto m2;
                }
            }

            int A = MAS1[0];

            for (i = 1; i < N; i++)
            {
                if (i % 2 != 0 && i != N - 1)
                {
                    MAS1[i] += A;
                }
            }

            return MAS1;
        }
        #endregion

        #region Функция 2 задания
        static int TASK2(int N)
        {
            int i;
            int[] MAS1 = new int[N];


            for (i = 0; i < N; i++)
            {
            m2:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива");
                    i--;
                    MAS1[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m2;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m2;
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Ошибка переполнения массива");
                    goto m2;
                }
            }

            int min = MAS1.Min();
            int max = MAS1.Max();

            min += max;

            return min;
        }
        #endregion

        #region Функция 3 задания

        static int Min5(int A, int B, int C, int D, int E)
        {
            int[] MAS = new int[5];
            MAS[0] = A;
            MAS[1] = B;
            MAS[2] = C;
            MAS[3] = D;
            MAS[4] = E;

            int MIN = MAS.Min();
            return MIN;
        }

        #endregion

        #region Функция 4 задания

        static bool Even(int K)
        {
            if (K % 2 == 0 && K != 0)
            {
                bool R = true;
                return R;
            }
            else
            {
                bool R = false;
                return R;
            }
           
        }

        #endregion
    }
}
