package var14;
import java.util.Objects;
import java.util.Scanner;
import java.util.InputMismatchException;

//ВАРИАНТ № 14

//1. Проверить истинность высказывания:
// "Сумма двух первых цифр данного целого
// положительного четырехзначного числа равна
// сумме двух его последних цифр".

//2. Даны два целых положительных числа A и B
// (число A меньше числа B). Вывести все четные
// числа, расположенные между данными числами
// (не включая сами эти числа), в порядке их
// убывания, а также количество этих чисел и их сумму.

//3. Дан целочисленный массив, состоящий из N элементов
// (N > 0). Найти максимальный и минимальный элемент в
// массиве и вычислить их сумму.

//4. Вводится строка, состоящая из слов, разделенных
// подчеркиваниями (одним или несколькими). Длина
// строки может быть разной. Найти и вывести длину
// самого большого слова и вывести это слово на экран.

//5. Вводится строка, содержащая буквы и цифры.
// Длина строки может быть разной. Вывести сумму
// и произведение цифр этой введенной строки.
// Чтобы избежать целочисленного переполнения
// при произведении, вычислять это выражение с
// помощью вещественной переменной и выводить
// его как вещественное число.



public class Main {

    public static void main(String[] args) {

        int A, A1, A2, A3, A4;

        System.out.println("Задание1");
        Scanner in1 = new Scanner(System.in);

        try {

            System.out.println("Введите положительное четырехзначное число");
            A = in1.nextInt();

            while (A < 1000 || A > 9999)
            {
                System.out.println("Введено не положительное четырехзначное число, введите положительное четырехзначное число");
                A = in1.nextInt();
            }

            A1 = A / 1000;
            A2 = (A - (A1 * 1000)) / 100;
            A3 = (A - (A1 * 1000) - (A2 * 100)) / 10;
            A4 = (A - (A1 * 1000) - (A2 * 100) - (A3 * 10));

            if (A1 + A2 == A3 + A4){
                System.out.println("Сумма первых двух первых чисел четырехзначного числа равна сумме двух последних числам");
            }
            else
            {
                System.out.println("Сумма первых двух первых чисел четырехзначного числа не равна сумме двух последних числам");
            }
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }

        int a, B;

        System.out.println("Задание2");
        Scanner in2 = new Scanner(System.in);

        try {
            System.out.println("Введите положительное число А (А < B)");
            a = in2.nextInt();

            while (a <= 0)
            {
                System.out.println("Число А должно быть положительным ,введите положительное число А (А < B)");
                a = in2.nextInt();
            }

            System.out.println("Введите положительное число B (А < B)");
            B = in2.nextInt();

            while (B <= 0 || a > B)
            {
                System.out.println("Число B должно быть положительным и больше числа А,введите положительное число В (А < B)");
                B = in2.nextInt();
            }

            System.out.print("Четные числа между числом А и В - ");

            for (int i = B - 1; i > a; i--)
            {
                if (i % 2 == 0)
                {
                    System.out.print(i + " ");
                }
            }

            System.out.println("");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }

        int N = 0;

        System.out.println("Задание3");
        Scanner in3 = new Scanner(System.in);

        try {
            System.out.println("Введите размер массива");
            N = in3.nextInt();

            while (N <= 0)
            {
                System.out.println("Размер массива не может быть равен нулю или быть отрицательным ,введите размер массива");
                N = in3.nextInt();
            }

            int [] MAS1 = new int [N];

            for (int i = 0; i < N; i++)
            {
                i++;
                System.out.println("Введите " + i +" число массива");
                i--;
                MAS1[i] = in3.nextInt();
            }

            int MIN, MAX;

            MIN = MAS1[0];
            MAX = MAS1[0];

            for (int i = 0; i < N; i++)
            {
                if (MAS1[i] < MIN)
                {
                    MIN = MAS1[i];
                }
                if (MAS1[i] > MAX)
                {
                    MAX = MAS1[i];
                }
            }

            MIN += MAX;

            System.out.println("Сумма максимального и минимального числа массива равна " + MIN);
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }

        String txt1;
        String [] spl;
        String rab;
        int count = 0;
        int index = 0;
        System.out.println("Задание4");
        Scanner in4 = new Scanner(System.in);

        try
        {
            System.out.println("Введите строку с подчеркиваниями");
            txt1 = in4.next();

            while (Objects.equals(txt1, ""))
            {
                System.out.println("Введна пустая строка, введите строку с подчеркиваниями");
                txt1 = in4.next();
            }

            spl = txt1.split("_");

            count = spl.length;

            for (int i = 0; i < spl.length; i++ )
            {
                rab = spl[i];
                if (count < rab.length())
                {
                    count = rab.length();
                    index = i;
                }
            }

            System.out.println("Самое длинное слово в строке - " + spl[index] + " с кол-вом символов - " + count);
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }

        double sum = 0.0;
        double mul = 1.0;
        int fl = 0;
        String txt2;
        System.out.println("Задание5");
        Scanner in5 = new Scanner(System.in);

        try
        {
            System.out.println("Введите строку с цифрами");
            txt2 = in5.next();

            while (Objects.equals(txt2, ""))
            {
                System.out.println("Введна пустая строка, введите строку с цифрами");
                txt2 = in5.next();
            }

            char [] s = txt2.toCharArray();

            for (int i = 0; i < txt2.length(); i++)
            {
                switch (s[i])
                {
                    case('0'):
                        fl = 1;
                        sum += 0;
                        mul *= 0;
                        break;
                    case('1'):
                        fl = 1;
                        sum += 1;
                        mul *= 1;
                        break;
                    case('2'):
                        fl = 1;
                        sum += 2;
                        mul *= 2;
                        break;
                    case('3'):
                        fl = 1;
                        sum += 3;
                        mul *= 3;
                        break;
                    case('4'):
                        fl = 1;
                        sum += 4;
                        mul *= 4;
                        break;
                    case('5'):
                        fl = 1;
                        sum += 5;
                        mul *= 5;
                        break;
                    case('6'):
                        fl = 1;
                        sum += 6;
                        mul *= 6;
                        break;
                    case('7'):
                        fl = 1;
                        sum += 7;
                        mul *= 7;
                        break;
                    case('8'):
                        fl = 1;
                        sum += 7;
                        mul *= 7;
                        break;
                    case('9'):
                        fl = 1;
                        sum += 7;
                        mul *= 7;
                        break;
                    default:
                        break;
                }
            }

            if (fl == 1)
            {
                System.out.println("Сумма чисел в строке - " + sum);
                System.out.println("Произведение чисел в строке - " + mul);
            }
            else
            {
                System.out.println("Числа в строке отсутвуют");
            }
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
    }
}
