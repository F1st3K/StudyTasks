﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CONVERTOR_DATA_TYPE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MaximizeBox = false;
            comboBox1.SelectedItem = "Байт";
            comboBox2.SelectedItem = "Байт";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public double data;

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.Text != "" && comboBox2.Text != "")
            {

                try
                {
                    data = Convert.ToDouble(textBox1.Text);
                }
                catch (FormatException)
                {
                    MessageBox.Show("Произошла ошибка формата при вводе данных для конвертации", "ОШИБКА ФОРМАТА", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    goto t1;
                }
                //Байты
                if (comboBox1.Text == "Байт" && comboBox2.Text == "Байт")
                {
                    ANSWER.Text = Convert.ToString(data) + " Байт";
                }
                if (comboBox1.Text == "Байт" && comboBox2.Text == "Килобайт")
                {
                    ANSWER.Text = Convert.ToString(data / 1024) + " Килобайт";
                }
                if (comboBox1.Text == "Байт" && comboBox2.Text == "Мегабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 2)) + " Мегабайт";
                }
                if (comboBox1.Text == "Байт" && comboBox2.Text == "Гигабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 3)) + " Гигабайт";
                }
                if (comboBox1.Text == "Байт" && comboBox2.Text == "Терабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 4)) + " Терабайт";
                }
                if (comboBox1.Text == "Байт" && comboBox2.Text == "Петабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 5)) + " Петабайт";
                }
                //Килобайт
                if (comboBox1.Text == "Килобайт" && comboBox2.Text == "Байт")
                {
                    ANSWER.Text = Convert.ToString(data * 1024) + " Байт";
                }
                if (comboBox1.Text == "Килобайт" && comboBox2.Text == "Килобайт")
                {
                    ANSWER.Text = Convert.ToString(data) + " Килобайт";
                }
                if (comboBox1.Text == "Килобайт" && comboBox2.Text == "Мегабайт")
                {
                    ANSWER.Text = Convert.ToString(data / 1024) + " Мегабайт";
                }
                if (comboBox1.Text == "Килобайт" && comboBox2.Text == "Гигабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 2)) + " Гигабайт";
                }
                if (comboBox1.Text == "Килобайт" && comboBox2.Text == "Терабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 3)) + " Терабайт";
                }
                if (comboBox1.Text == "Килобайт" && comboBox2.Text == "Петабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 4)) + " Петабайт";
                }
                //Мегабайт
                if (comboBox1.Text == "Мегабайт" && comboBox2.Text == "Байт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 2)) + " Байт";
                }
                if (comboBox1.Text == "Мегабайт" && comboBox2.Text == "Килобайт")
                {
                    ANSWER.Text = Convert.ToString(data * 1024) + " Килобайт";
                }
                if (comboBox1.Text == "Мегабайт" && comboBox2.Text == "Мегабайт")
                {
                    ANSWER.Text = Convert.ToString(data) + " Мегабайт";
                }
                if (comboBox1.Text == "Мегабайт" && comboBox2.Text == "Гигабайт")
                {
                    ANSWER.Text = Convert.ToString(data / 1024) + " Гигабайт";
                }
                if (comboBox1.Text == "Мегабайт" && comboBox2.Text == "Терабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 2)) + " Терабайт";
                }
                if (comboBox1.Text == "Мегабайт" && comboBox2.Text == "Петабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 3)) + " Петабайт";
                }
                //Гигабайт
                if (comboBox1.Text == "Гигабайт" && comboBox2.Text == "Байт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 3)) + " Байт";
                }
                if (comboBox1.Text == "Гигабайт" && comboBox2.Text == "Килобайт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 2)) + " Килобайт";
                }
                if (comboBox1.Text == "Гигабайт" && comboBox2.Text == "Мегабайт")
                {
                    ANSWER.Text = Convert.ToString(data * 1024) + " Мегабайт";
                }
                if (comboBox1.Text == "Гигабайт" && comboBox2.Text == "Гигабайт")
                {
                    ANSWER.Text = Convert.ToString(data) + " Гигабайт";
                }
                if (comboBox1.Text == "Гигабайт" && comboBox2.Text == "Терабайт")
                {
                    ANSWER.Text = Convert.ToString(data / 1024) + " Терабайт";
                }
                if (comboBox1.Text == "Гигабайт" && comboBox2.Text == "Петабайт")
                {
                    ANSWER.Text = Convert.ToString(data / Math.Pow(1024, 2)) + " Петабайт";
                }
                //Терабайт
                if (comboBox1.Text == "Терабайт" && comboBox2.Text == "Байт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 4)) + " Байт";
                }
                if (comboBox1.Text == "Терабайт" && comboBox2.Text == "Килобайт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 3)) + " Килобайт";
                }
                if (comboBox1.Text == "Терабайт" && comboBox2.Text == "Мегабайт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 2)) + " Мегабайт";
                }
                if (comboBox1.Text == "Терабайт" && comboBox2.Text == "Гигабайт")
                {
                    ANSWER.Text = Convert.ToString(data * 1024) + " Гигабайт";
                }
                if (comboBox1.Text == "Терабайт" && comboBox2.Text == "Терабайт")
                {
                    ANSWER.Text = Convert.ToString(data) + " Терабайт";
                }
                if (comboBox1.Text == "Терабайт" && comboBox2.Text == "Петабайт")
                {
                    ANSWER.Text = Convert.ToString(data / 1024) + " Петабайт";
                }
                //Петабайт
                if (comboBox1.Text == "Петабайт" && comboBox2.Text == "Байт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 5)) + " Байт";
                }
                if (comboBox1.Text == "Петабайт" && comboBox2.Text == "Килобайт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 4)) + " Килобайт";
                }
                if (comboBox1.Text == "Петабайт" && comboBox2.Text == "Мегабайт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 3)) + " Мегабайт";
                }
                if (comboBox1.Text == "Петабайт" && comboBox2.Text == "Гигабайт")
                {
                    ANSWER.Text = Convert.ToString(data * Math.Pow(1024, 2)) + " Гигабайт";
                }
                if (comboBox1.Text == "Петабайт" && comboBox2.Text == "Терабайт")
                {
                    ANSWER.Text = Convert.ToString(data * 1024) + " Терабайт";
                }
                if (comboBox1.Text == "Петабайт" && comboBox2.Text == "Петабайт")
                {
                    ANSWER.Text = Convert.ToString(data) + " Петабайт";
                }
            }
            else
            {
                MessageBox.Show("Вы не заполнили все данные о командах конвертации", "ОШИБКА", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                goto t1;
            }

        t1:

            button1.Enabled = false;
            button3.Enabled = true;
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8 && number != 32 && number != 127)
            {
                e.Handled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Length != 0 && !String.IsNullOrWhiteSpace(textBox1.Text))
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string[] txt;
            txt = ANSWER.Text.Split();

            data = Convert.ToDouble(txt[0]);
            if (data < 1)
            {
                MessageBox.Show(data.ToString("0.##################################### ") + txt[1], "Полное значение", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show(data.ToString("#################.##################################### ") + txt[1], "Полное значение", MessageBoxButtons.OK);
            }
        }
    }
}
