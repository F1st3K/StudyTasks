package main

import (
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"strconv"
	"strings"
)

//ВАРИАНТ № А14/Б32
//1. Из пяти целых различных ненулевых положительных и
//отрицательных чисел найти самое наименьшее число.

//2. Дано четырехзначное целое ненулевое положительное число N (N>0).
//Проверить истинность высказывания: "Все цифры данного числа различны".

//3. Дан целочисленный массив, состоящий из N элементов (N > 0).
//Заменить в массиве все элементы, встречающиеся ровно два раза
//на значение -999.

//4. Вводится строка, состоящая из слов, разделенных подчеркиваниями
//(одним или несколькими). Длина строки может быть разной. Определить
//и вывести на экран самое длинное слово а так же размер этого слова.

func main() {
	var c []byte
	var MAS1 []int
	var QWE int
	var a string
	var A10 []string

	fmt.Println("Задание1")

	f1, err := os.Open("input1.txt")

	if err != nil {
		fmt.Println("Для 1 задания не создан файл")
		goto m2
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto m2
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto m2
	}

	a = string(c)
	A10 = strings.Split(a, " ")

	if len(A10) == 5 {
		for i := 0; i < len(A10); i++ {
			o, err := strconv.Atoi(A10[i])
			if err != nil {
				fmt.Println("Ошибка формата")
				goto m2
			}
			if o != 0 {
				MAS1 = append(MAS1, o)
			} else {
				fmt.Println("Ошибка, в файл введено нулевое число")
				goto m2
			}
		}
	} else {
		fmt.Println("Ошибка, в файл введено не 5 значений")
		goto m2
	}
	f1.Close()
	QWE = MAS1[0]
	for i := 0; i < 5; i++ {
		if QWE > MAS1[i] {
			QWE = MAS1[i]
		}
	}
	f1, err = os.OpenFile("output1.txt", os.O_CREATE|os.O_RDWR, 0777)
	if err != nil {
		fmt.Println("Ошибка в создании файла")
		goto m2
	}

	a = "Минимальное число среди 5 введенных чисел равно " + strconv.Itoa(QWE)

	io.WriteString(f1, a)
	f1.Close()
m2:

	var num1 int
	var A1 int
	var A2 int
	var A3 int
	var A4 int

	fmt.Println("Задание2")

	f1, err = os.Open("input2.txt")

	if err != nil {
		fmt.Println("Для 2 задания не создан файл")
		goto m3
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto m3
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto m3
	}

	num1, err = strconv.Atoi(string(c))

	if err != nil {
		fmt.Println("Ошибка, в файл введен не верный формат данных")
		goto m3
	}

	if num1 < 1000 || num1 > 9999 {
		fmt.Println("Ошибка, в файл введено не четырехзначное число")
		goto m3
	}

	A1 = num1 / 1000
	A2 = (num1 - (A1 * 1000)) / 100
	A3 = (num1 - (A1 * 1000) - (A2 * 100)) / 10
	A4 = (num1 - (A1 * 1000) - (A2 * 100) - (A3 * 10))

	f1.Close()

	f1, err = os.OpenFile("output2.txt", os.O_CREATE|os.O_RDWR, 0777)
	if err != nil {
		fmt.Println("Ошибка в создании файла")
		goto m3
	}

	if A1 != A2 && A1 != A3 && A1 != A4 && A2 != A3 && A2 != A4 && A3 != A4 {
		a = "Все цифры введенного числа различны"

		io.WriteString(f1, a)
		f1.Close()
	} else {
		a = "Не все цифры введенного числа различны"

		io.WriteString(f1, a)
		f1.Close()
	}
m3:
	var o int
	ans2 := "Новый массив - "
	var MAS2 []int
	var flag bool = false
	var count int = 0

	fmt.Println("Задание3")
	f1, err = os.Open("input3.txt")

	if err != nil {
		fmt.Println("Для 3 задания не создан файл")
		goto m4
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto m4
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto m4
	}

	a = string(c)
	A10 = strings.Split(a, " ")

	for i := 0; i < len(A10); i++ {
		o, err = strconv.Atoi(A10[i])
		if err != nil {
			fmt.Println("Ошибка формата")
			goto m4
		}
		MAS2 = append(MAS2, o)
	}

	f1.Close()

	count = 0

	for i := 0; i < len(MAS2); i++ {
		if MAS2[i] != -999 {
			for z := 0; z < len(MAS2); z++ {
				if MAS2[z] == MAS2[i] && flag == true {
					count++
					A2 = z
				}
				if MAS2[z] == MAS2[i] && flag == false {
					count++
					flag = true
					A1 = z
				}
			}
		}
		if count == 2 {
			MAS2[A1] = -999
			MAS2[A2] = -999
		}
		flag = false
		count = 0
	}

	for i := 0; i < len(MAS2); i++ {
		ans2 += strconv.Itoa(MAS2[i]) + " "
	}

	f1, err = os.OpenFile("output3.txt", os.O_CREATE|os.O_RDWR, 0777)
	if err != nil {
		fmt.Println("Ошибка в создании файла")
		goto m4
	}

	io.WriteString(f1, ans2)
	f1.Close()
m4:
	var index int

	fmt.Println("Задание4")

	f1, err = os.Open("input4.txt")

	if err != nil {
		fmt.Println("Для 4 задания не создан файл")
		os.Exit(0)
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		os.Exit(0)
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		os.Exit(0)
	}

	a = string(c)
	A10 = strings.Split(a, "_")

	count = len(A10[0])
	index = 0

	for i := 0; i < len(A10); i++ {
		if count < len(A10[i]) {
			count = len(A10[i])
			index = i
		}
	}

	a = "Самое большое слово в строке это - " + A10[index] + " c кол-во символов в этом слове - " + strconv.Itoa(count)

	f1, err = os.OpenFile("output4.txt", os.O_CREATE|os.O_RDWR, 0777)
	if err != nil {
		fmt.Println("Ошибка в создании файла")
		os.Exit(0)
	}

	io.WriteString(f1, a)
	f1.Close()
}
