﻿//Вариант № 14/29
//1. Саратовская область (город)
//2. Ульяновская область (поселок)
//3. Тюменская область (село)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Collections;
using System.IO;

namespace ex_ArrayList
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList list = new ArrayList();
            StreamWriter sw1 = File.CreateText("out1.txt");
            StreamWriter sw2 = File.CreateText("out2.txt");
            StreamWriter sw3 = File.CreateText("out3.txt");
            string town;

            try
            {
            using (StreamReader sr = File.OpenText("oktmo.csv"))
            {
                string input = null;
                while ((input = sr.ReadLine()) != null)
                {
                    list.Add(input);
                }
            }
            }
            catch(FileNotFoundException)
            {
                sw1.WriteLine("Файл не найден");
                sw2.WriteLine("Файл не найден");
                sw3.WriteLine("Файл не найден");
                sw1.Close();
                sw2.Close();
                sw3.Close();
                return;
            }
            catch(DirectoryNotFoundException)
            {
                sw1.WriteLine("Директория не найдена");
                sw2.WriteLine("Директория не найдена");
                sw3.WriteLine("Директория не найдена");
                sw1.Close();
                sw2.Close();
                sw3.Close();
                return;
            }
            catch(ArgumentException)
            {
                sw1.WriteLine("Ошибка аргумента");
                sw2.WriteLine("Ошибка аргумента");
                sw3.WriteLine("Ошибка аргумента");
                sw1.Close();
                sw2.Close();
                sw3.Close();
                return;
            }

            for(int a=1; a<list.Count; a++)
            {
                string temp = list[a].ToString();
                string[] z = temp.Split(';');
                town = z[12];
                if (town != "")
                {
                    if ((z[16] == "Саратовская область" && z[18] == "город") || (z[16] == "Саратовская область" && town.Substring(0, 1) == "г"))
                    {
                        sw1.WriteLine(temp);
                    }
                    if ((z[16] == "Ульяновская область" && z[18] == "поселок") || (z[16] == "Ульяновская область" && town.Substring(0, 1) == "п"))
                    {
                        sw2.WriteLine(temp);
                    }
                    if ((z[16] == "Тюменская область" && z[18] == "село") || (z[16] == "Тюменская область" && town.Substring(0, 1) == "с"))
                    {
                        sw3.WriteLine(temp);
                    }
                }
            }

            sw1.Close();
            sw2.Close();
            sw3.Close();

            Console.ReadKey();
        }
    }
}
