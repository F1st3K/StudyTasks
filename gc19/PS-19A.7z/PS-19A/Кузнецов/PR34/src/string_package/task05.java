package string_package;

public class task05 {

    String TXT;
    int [] MAS = new int [2];
    int sum = 0;
    int count = 0;

    public task05(String Z)
    {
        TXT = Z;
    }

    public int [] GetAnswer()
    {
        char [] res = TXT.toCharArray();

        for (int i = 0; i < TXT.length(); i++)
        {
            if (res[i] == '0')
            {
                count++;
            }
            if (res[i] == '1')
            {
                count++;
                sum += 1;
            }
            if (res[i] == '2')
            {
                count++;
                sum += 2;
            }
            if (res[i] == '3')
            {
                count++;
                sum += 3;
            }
            if (res[i] == '4')
            {
                count++;
                sum += 4;
            }
            if (res[i] == '5')
            {
                count++;
                sum += 5;
            }
            if (res[i] == '6')
            {
                count++;
                sum += 6;
            }
            if (res[i] == '7')
            {
                count++;
                sum += 7;
            }
            if (res[i] == '8')
            {
                count++;
                sum += 8;
            }
            if (res[i] == '9')
            {
                count++;
                sum += 9;
            }
        }

        MAS[0] = count;
        MAS[1] = sum;

        return MAS;
    }
}
