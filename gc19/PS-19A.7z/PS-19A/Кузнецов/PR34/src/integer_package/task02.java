package integer_package;

public class task02 {

    int A1, A2, A3, A4;
    int N;

    public task02(int A)
    {
        N = A;
    }

    public int GetAnswer()
    {
        A1 = N/1000;
        A2 = (N - (A1 * 1000)) / 100;
        A3 = (N - (A1 * 1000) - (A2 * 100)) / 10;
        A4 = (N - (A1 * 1000) - (A2 * 100) - (A3 * 10));

        A1 = (A1 * A2) + (A3 * A4);
        return A1;
    }
}
