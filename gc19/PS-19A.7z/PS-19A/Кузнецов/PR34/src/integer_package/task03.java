package integer_package;

public class task03 {

    int Z;
    boolean ANS3;
    int even = 0, noeven = 0;

    public task03(int A)
    {
        Z = A;
    }

    public boolean GetAnswer()
    {
        double [] MAS1 = new double[31];

        System.out.print("Получившееся массив - ");
        if (Z == 1 || Z == 3 || Z == 5 || Z == 7 || Z == 8 || Z == 10 || Z == 12) {
            for (int i = 0; i < 31; i++) {
                MAS1[i] = ((Math.random() * 12));
                if (i % 2 == 0)
                {
                    noeven += MAS1[i];
                }
                else
                {
                    even += MAS1[i];
                }
                System.out.print(MAS1[i] + " ");
            }
            System.out.println("");
        }
        if (Z == 2)
        {
            for (int i = 0; i < 28; i++) {
                MAS1[i] = ((Math.random() * 12));
                if (i % 2 == 0)
                {
                    noeven += MAS1[i];
                }
                else
                {
                    even += MAS1[i];
                }
                System.out.print(MAS1[i] + " ");
            }
            System.out.println("");
        }
        if (Z == 4 || Z == 6 || Z == 9 || Z == 11)
        {
            for (int i = 0; i < 30; i++) {
                MAS1[i] = ((Math.random() * 12));
                if (i % 2 == 0)
                {
                    noeven += MAS1[i];
                }
                else
                {
                    even += MAS1[i];
                }
                System.out.print(MAS1[i] + " ");
            }
            System.out.println("");
        }

        if (even > noeven)
        {
            return ANS3 = true;
        }
        else
        {
            return ANS3 = false;
        }
    }
}
