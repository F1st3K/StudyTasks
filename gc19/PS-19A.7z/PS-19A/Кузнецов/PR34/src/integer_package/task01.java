package integer_package;



public class task01 {

    int Z;
    boolean ANS1;

    public task01(int A)
    {
        Z = A;
    }

    public boolean GetAnswer()
    {
        if ((Z > 99 && Z < 1000) && (Z % 2 == 0))
        {
            return ANS1 = true;
        }
        else
        {
            return ANS1 = false;
        }
    }

}
