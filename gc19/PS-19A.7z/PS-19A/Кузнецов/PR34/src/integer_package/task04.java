package integer_package;

import java.util.InputMismatchException;

public class task04 {
    int MUL = 1;

    public task04(){}

    public int MulRange(int A, int B)
    {
        try {
            for (int i = A; i < B+1; i++)
            {
                MUL *= i;
            }

            if (A > B)
            {
                return MUL = 0;
            }
            return MUL;
        }
        catch (InputMismatchException ex)
        {
            System.out.print("Ошибка переполнения");
            return MUL = 999999;
        }
        catch (StackOverflowError ex)
        {
            System.out.print("Ошибка переполнения");
            return MUL = 999999;
        }
    }
}
