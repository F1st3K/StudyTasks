package var14;
import integer_package.*;
import string_package.*;
import java.util.InputMismatchException;
import java.util.Scanner;

//ВАРИАНТ № А14/Б27
//1. Проверить истинность высказывания: "Данное целое положительное
// число является четным трехзна7чным числом".

//2. Задано целое положительное четырехзначное число N (N > 0).
// Найти сумму между произведениями первых двух и последних двух его цифр.

//3. В вещественном массиве известны данные о количестве осадков,
// выпавших за каждый день месяца N (N - любой месяц в году).
// Верно ли, что по четным числам выпало больше осадков, чем по нечетным?

//4. Написать функцию int MulRange(A, B) целого типа, находящую произведение
// всех целых чисел от A до B включительно (A и B — целые положительные).
// Если A > B, то функция должна возвращать число 0.

//5. Вводится строка. Длина строки может быть разной. Подсчитать
// количество содержащихся в этой строке чисел (от 0 до 9). Вычислить и вывести сумму этих чисел.


public class Main {

    public static void main(String[] args) {

        System.out.println("Задание1");
        Scanner in1 = new Scanner(System.in);
        int N = 0;

        try {
            System.out.println("Введите целое положительное число");
            N = in1.nextInt();

            while (N < 0)
            {
                System.out.println("Число должно быть положительным");
                System.out.println("Введите целое положительное число");
                N = in1.nextInt();
            }

            task01 t1 = new task01(N);

            if (t1.GetAnswer()) {
                System.out.println("Да, число трехзначное и четное");
            }
            else
            {
                System.out.println("Нет, число не трехзначное и четное");
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата, задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения, задание будет пропущено");
        }

        System.out.println("Задание2");
        Scanner in2 = new Scanner(System.in);

        try
        {
            System.out.println("Введите целое положительное четырезначное число");
            N = in2.nextInt();

            while (N < 1000 || N > 9999)
            {
                System.out.println("Введено неправильное число");
                System.out.println("Введите целое положительное четырезначное число");
                N = in2.nextInt();
            }

            task02 t2 = new task02(N);
            System.out.println("Сумма произведение первых двух цифр и последних двух цифр введенного числа равна " + t2.GetAnswer());
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата, задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения, задание будет пропущено");
        }

        System.out.println("Задание3");
        Scanner in3 = new Scanner(System.in);

        try
        {
            System.out.println("Введите число месяца (от 1 до 12)");
            N = in3.nextInt();

            while (N < 1 || N > 12)
            {
                System.out.println("Введено неверное число месяца");
                System.out.println("Введите число месяца (от 1 до 12)");
                N = in3.nextInt();
            }

            task03 t3 = new task03(N);

            if (t3.GetAnswer())
            {
                System.out.println("Да, по четным дням выпадет больше осадков");
            }
            else
            {
                System.out.println("Нет, по четным дням не выпадет больше осадков");
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата, задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения, задание будет пропущено");
        }

        System.out.println("Задание4");
        Scanner in4 = new Scanner(System.in);
        int A;
        int B;

        try
        {
            System.out.println("Введите число А (A < B)");
            A = in4.nextInt();

            System.out.println("Введите число B (A < B)");
            B = in4.nextInt();

            task04 t4 = new task04();

            System.out.println("Произведение чисел от А до В, включительно, равно " + t4.MulRange(A, B));
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата, задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения, задание будет пропущено");
        }

        System.out.println("Задание5");
        Scanner in5 = new Scanner(System.in);
        String txt;

        try {
            System.out.println("Введите строку с числами");
            txt = in5.next();

            while (txt.equals(""))
            {
                System.out.println("Введите строку с числами (не пустую)");
                txt = in5.next();
            }

            task05 t5 = new task05(txt);

            int [] MAS5 = t5.GetAnswer();

            System.out.println("Кол-во чисел в строке равно " + MAS5[0]);
            System.out.println("Сумма чисел в строке равна " + MAS5[1]);
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата, задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения, задание будет пропущено");
        }
    }
}
