﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;

//ВАРИАНТ № А14/Б32
//1. Из пяти целых различных ненулевых положительных и отрицательных чисел найти самое наименьшее число.
//2. Дано четырехзначное целое ненулевое положительное число N (N > 0). Проверить истинность высказывания: "Все цифры данного числа различны".
//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Заменить в массиве все элементы, встречающиеся ровно два раза на значение -999.
//4. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). Длина строки может быть разной. Определить и 
//вывести на экран самое длинное слово а так же размер этого слова.

namespace PR24
{
    class Program
    {
        static void Main(string[] args)
        {
            #region задание1

            int i = 0;
            int[] MAS = new int [5];
            int[] MAS1 = new int[21];
            string TXT = "asd";
            int fl = 0;
            var document = new XmlDocument();

            try
            {
                document.Load("input1.xml");
            }
            catch(FileNotFoundException)
            {
                Console.WriteLine("Ошибка, файл не найден (1 задание)");
                goto m1;
            }
            catch(ArgumentException)
            {
                Console.WriteLine("Ошибка формата (1 задание)");
                goto m1;
            }

            XmlNode root = document.DocumentElement;
            var writer = new XmlTextWriter("output1.xml", null);

            foreach (XmlNode books in root.ChildNodes)
            {
                foreach (XmlNode book in books.ChildNodes)
                {
                    try
                    {
                        MAS[i] = Convert.ToInt32(book.InnerText);
                        i++;
                    }
                    catch(FormatException)
                    {
                        Console.WriteLine("Ошибка формата (1 задание)");
                        goto m1;
                    }
                    catch (OverflowException)
                    {
                        Console.WriteLine("Ошибка переполнения (1 задание)");
                        goto m1;
                    }
                    if (MAS[i-1] == 0)
                    {
                        Console.WriteLine("Ошибка, числа не должны равняться нулю");
                        goto m1;
                    }
                }
            }
            i = MAS.Min();

            writer.WriteStartDocument();
            writer.WriteStartElement("task1");
            writer.WriteStartElement("answer");
            writer.WriteStartElement("lessnumber");
            writer.WriteString(Convert.ToString(i));
            writer.WriteEndElement();                     
            writer.WriteEndElement();                     
            writer.WriteEndElement();

            writer.Close();

            #endregion

            #region задание2

            m1:
            try
            {
                document.Load("input2.xml");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Ошибка, файл не найден (2 задание)");
                goto m2;
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Ошибка формата (2 задание)");
                goto m2;
            }
            root = document.DocumentElement;
            writer = new XmlTextWriter("output2.xml", null);
            i = 0;
            int m = 0;

            foreach (XmlNode books in root.ChildNodes)
            {
                foreach (XmlNode book in books.ChildNodes)
                {
                    try
                    {
                        m = Convert.ToInt32(book.InnerText);
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Ошибка формата (2 задание)");
                        goto m2;
                    }
                    catch (OverflowException)
                    {
                        Console.WriteLine("Ошибка переполнения (2 задание)");
                        goto m2;
                    }
                    if (m < 1000 || m > 9999)
                    {
                        Console.WriteLine("Ошибка, должно быть введено четырехзначное положительное число");
                        goto m2;
                    }
                }
            }
            int A1 = m / 1000;
            int A2 = (m - (A1 * 1000)) / 100;
            int A3 = (m - (A1 * 1000) - (A2 * 100)) / 10;
            int A4 = (m - (A1 * 1000) - (A2 * 100) - (A3 * 10));

            if (A1 != A2 && A1 != A3 && A1 != A4 && A2 != A3 && A2 != A4 && A3 != A4 )
            {
                 writer.WriteStartDocument();
                 writer.WriteStartElement("task2");
                 writer.WriteStartElement("answer");
                 writer.WriteStartElement("YESORNO");
                 writer.WriteString(Convert.ToString("YES"));
                 writer.WriteEndElement();
                 writer.WriteEndElement();
                 writer.WriteEndElement();
                 writer.Close();
             }
             else
             {
                 writer.WriteStartDocument();
                 writer.WriteStartElement("task2");
                 writer.WriteStartElement("answer");
                 writer.WriteStartElement("YESORNO");
                 writer.WriteString(Convert.ToString("NO"));
                 writer.WriteEndElement();
                 writer.WriteEndElement();
                 writer.WriteEndElement();
                 writer.Close();
             }
            

            #endregion

            #region задание3
        m2:
            try
            {
                document.Load("input3.xml");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Ошибка, файл не найден (3 задание)");
                goto m3;
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Ошибка формата (3 задание)");
                goto m3;
            }
            root = document.DocumentElement;
            writer = new XmlTextWriter("output3.xml", null);
            i = 0;
            int h = 0;
            foreach (XmlNode books in root.ChildNodes)
            {
                foreach (XmlNode book in books.ChildNodes)
                {
                    try
                    {
                        MAS1[i] = Convert.ToInt32(book.InnerText);
                        i++;
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Ошибка формата (3 задание)");
                        goto m3;
                    }
                    catch (OverflowException)
                    {
                        Console.WriteLine("Ошибка переполнения (3 задание)");
                        goto m3;
                    }
                }
            }
            int f = 0;
            for (i = 0; i < MAS1.Length; i++)
            {
                fl = 0;
                h = MAS1[i];
                for (int j = 0; j < MAS1.Length; j++)
                {
                    if (h == MAS1[j] && MAS1[j] != -999 && fl == 0 && j != i)
                    {
                        fl = 1;
                        f = j;
                        j++;
                    }
                    if (fl == 1 && h == MAS1[j] && MAS1[j] != -999 && j != i)
                    {
                        fl = 2;
                        break;                   
                    }
                }
                if (fl == 1)
                {
                    MAS1[i] = -999;
                    MAS1[f] = -999;
                }
            }

            writer.WriteStartDocument();
            writer.WriteStartElement("task3");
            writer.WriteStartElement("answer");
            writer.WriteStartElement("NEWMAS");
            for (i = 0; i < 20; i++)
            {
                writer.WriteString(Convert.ToString(MAS1[i]) + " ");
            }
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Close();



            #endregion

            #region задание4
            
            m3:
            try
            {
                document.Load("input4.xml");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("Ошибка, файл не найден (4 задание)");
                goto m4;
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Ошибка формата (4 задание)");
                goto m4;
            }
            root = document.DocumentElement;
            writer = new XmlTextWriter("output4.xml", null);
            i = 0;
            foreach (XmlNode books in root.ChildNodes)
            {
                foreach (XmlNode book in books.ChildNodes)
                {
                    try
                    {
                        TXT = Convert.ToString(book.InnerText);
                    }
                    catch (OutOfMemoryException)
                    {
                        Console.WriteLine("Ошибка, память переполнена (4 задание)");
                        goto m4;
                    }
                    catch (NullReferenceException)
                    {
                        Console.WriteLine("Ошибка, присвоено нелевое значение (4 задание)");
                        goto m4;
                    }
                    if (TXT == "")
                    {
                        Console.WriteLine("Ошибка, введена пустая строка");
                        goto m4;
                    }
                }
            }
            string[] str = TXT.Split(new Char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);
            int max = 0, index = 0;
            for (i = 0; i < str.Length - 1; i++)
            {
                if (str[i].Length > max)
                {
                    max = str[i].Length;
                    index = i;
                }
            }
            writer.WriteStartDocument();
            writer.WriteStartElement("task4");
            writer.WriteStartElement("answer");
            writer.WriteStartElement("BIGGERWORD");
            writer.WriteString(Convert.ToString(str[index]));
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.WriteEndElement();
            writer.Close();

            #endregion

        m4:
            Console.WriteLine("Нажмите любую клавишу для закрытия");
            Console.ReadKey();
        }
    }
}
