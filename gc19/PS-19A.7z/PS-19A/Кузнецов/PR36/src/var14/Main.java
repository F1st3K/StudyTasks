package var14;
import java.util.InputMismatchException;
import java.util.Objects;
import java.util.Scanner;

//ВАРИАНТ № 14
//1. Проверить истинность высказывания: "Сумма двух первых цифр данного
// целого положительного четырехзначного числа равна сумме двух его последних цифр".

//2. Даны два целых положительных числа A и B (число A меньше числа B).
// Вывести все четные числа, расположенные между данными числами
// (не включая сами эти числа), в порядке их убывания, а также количество этих чисел и их сумму.

//3. Дан целочисленный массив, состоящий из N элементов (N > 0).
// Найти максимальный и минимальный элемент в массиве и вычислить их сумму.

//4. Вводится строка, содержащая буквы и цифры. Длина строки может быть разной.
// Вывести сумму и произведение цифр этой введенной строки. Чтобы избежать
// целочисленного переполнения при произведении, вычислять это выражение с
// помощью вещественной переменной и выводить его как вещественное число.

public class Main {

    public static void main(String[] args) {

	    Scanner in1 = new Scanner(System.in);
        System.out.println("Задание1");
        int A, A1, A2, A3, A4;

        try
        {
            System.out.println("Введите положительное целое четырехзначное число  ");
            A = in1.nextInt();

            while (A < 1000 || A > 9999)
            {
                System.out.println("Ошибка, введено не четрехзначное положительное число");
                System.out.println("Введите положительное целое четырехзначное число  ");
                A = in1.nextInt();
            }

            A1 = A / 1000;
            A2 = (A - (A1 * 1000)) / 100;
            A3 = (A - (A1 * 1000) - (A2 * 100)) / 10;
            A4 = (A - (A1 * 1000) - (A2 * 100) - (A3 * 10));

            if ((A1 + A2) == (A3 + A4))
            {
                System.out.println("Да, сумма первых двух цифр равна сумме последних двух цифр");
            }
            else
            {
                System.out.println("Нет, сумма первых двух цифр не равна сумме последних двух цифр");
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        Scanner in2 = new Scanner(System.in);
        System.out.println("Задание2");
        int a = 0, b = 0, count = 0, sum = 0;

        try
        {
            System.out.println("Введите целое положителоное число А (А < B)");
            a = in2.nextInt();

            while (a <= 0)
            {
                System.out.println("Ошибка, число А не может быть отрицательным или равным нулю");
                System.out.println("Введите целое положителоное число А (А < B)");
                a = in2.nextInt();
            }

            System.out.println("Введите целое положителоное число B (А < B)");
            b = in2.nextInt();

            while (a > b)
            {
                System.out.println("Ошибка, число А не может больше числа B");
                System.out.println("Введите целое положителоное число B (А < B)");
                b = in2.nextInt();
            }

            System.out.print("Четные числа - ");

            for (int i = a; i < b; i++)
            {
                if (i != a && i != b) {
                    if (i % 2 == 0) {
                        sum += i;
                        count++;
                        System.out.print(i + " ");
                    }
                }
            }

            System.out.println("");
            System.out.println("Кол-во четных чисел - " + count);
            System.out.println("Сумма этих чисел - " + sum);
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        Scanner in3 = new Scanner(System.in);
        System.out.println("Задание3");
        int N = 0;

        try
        {
            System.out.println("Введите размер массива");
            N = in3.nextInt();

            while (N <= 0)
            {
                System.out.println("Ошибка, размер массива не может быть отрицательным");
                System.out.println("Введите размер массива");
                N = in3.nextInt();
            }

            int [] MAS = new int [N];

            for (int i = 0; i < N; i++)
            {
                i++;
                System.out.println("Введите " + i + " число массива");
                i--;
                MAS[i] = in3.nextInt();
            }

            int min = MAS[0];
            int max = MAS[0];

            for (int i = 0; i < N; i++)
            {
                if (min > MAS[i])
                {
                    min = MAS[i];
                }
                if (max < MAS[i])
                {
                    max = MAS[i];
                }
            }

            System.out.println("Максимальное число в массиве - " + max);
            System.out.println("Минимальное число в массиве - " + min);
            max += min;
            System.out.println("Сумма этих чисел - " + max);
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        Scanner in4 = new Scanner(System.in);
        System.out.println("Задание4");
        double mul = 1.0;
        String txt = "";
        int sum1 = 0;
        int fl = 0;

        try
        {
            System.out.println("Введите строку с числами и буквами");
            txt = in4.next();

            while (Objects.equals(txt, ""))
            {
                System.out.println("Ошибка, введена пустая строка");
                System.out.println("Введите строку с числами и буквами");
                txt = in4.next();
            }

            char [] s = txt.toCharArray();

            for (int i = 0; i < txt.length(); i++)
            {
                switch (s[i])
                {
                    case('0'):
                        fl = 1;
                        sum1 += 0;
                        mul *= 0;
                        break;
                    case('1'):
                        fl = 1;
                        sum1 += 1;
                        mul *= 1;
                        break;
                    case('2'):
                        fl = 1;
                        sum1 += 2;
                        mul *= 2;
                        break;
                    case('3'):
                        fl = 1;
                        sum1 += 3;
                        mul *= 3;
                        break;
                    case('4'):
                        fl = 1;
                        sum1 += 4;
                        mul *= 4;
                        break;
                    case('5'):
                        fl = 1;
                        sum1 += 5;
                        mul *= 5;
                        break;
                    case('6'):
                        fl = 1;
                        sum1 += 6;
                        mul *= 6;
                        break;
                    case('7'):
                        fl = 1;
                        sum1 += 7;
                        mul *= 7;
                        break;
                    case('8'):
                        fl = 1;
                        sum1 += 7;
                        mul *= 7;
                        break;
                    case('9'):
                        fl = 1;
                        sum1 += 7;
                        mul *= 7;
                        break;
                    default:
                        break;
                }
            }

            if (fl == 1)
            {
                System.out.println("Сумма чисел в строке - " + sum1);
                System.out.println("Произведение чисел в строке - " + mul);
            }
            else
            {
                System.out.println("Числа в строке отсутвуют");
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
    }
}
