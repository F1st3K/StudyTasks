﻿// ВАРИАНТ № А14/Б37
// 1. Проверить истинность высказывания : "Квадратное уравнение A·x2 + B·x + C = 0 с 
// данными коэффициентами A (A ≠ 0), B, C имеет ровно один вещественный корень".
// 2. Задано целое положительное четырехзначное число N(N > 0).
// Найти разницу между суммой всех его цифр и произведением четных цифр.
// 3. Дано целое положительное число N, лежащее в диапазоне от 1 до 999. 
// Вывести его строку - описание вида «четное двузначное число», «нечетное трехзначное число» и т.д.
// 4. Вводится строка, состоящая из слов разделенных точками.Длина строки может быть разной.
// Сформировать и вывести подстроку, расположенную между третьей и четвертой точками исходной строки.Если в строке менее двух точек, 
// то вывести всю исходную строку.
// 5. Вводится строка, изображающая целочисленное арифметическое выражение вида «цифра_цифра_цифра_цифра», где на месте 
// знака операции «_» находится символ умножения - «*» или деления - « / », а на месте "цифра" находится одна из цифр(от 1 до 9).
// Например, «4 * 8 / 3 * 5» результат равен 53.3.Вывести значение данного выражения(как вещественное число).

#include "stdafx.h"
#include <stdio.h>	
#include <string.h>	
#include <ctype.h>		

int _tmain(int argc, _TCHAR* argv[])
{
	int A, B, C, N, i,count,o;                                                //Наши переменные
	int OTV = 0;
	int x = 0;
	int A1, A2, A3, A4, A5;
	int B1, B2, B3, B4, B5;
	int C1, C2, C3, C4;
	double H1, H2, H3, H4, H5;
	int F;
	char TEXT1[100];
	char OTV2[100] = "";
	char OTV3[6] = "";
	printf("_____________Task1_______________\n");             //Задание1
	C1 = 1;                                                   
	C2 = 1;
	C3 = 1;
	C4 = 1;
	count = 0;
	o = 0;
	do
	{
		printf("Input A\n");
		scanf("%d", &A);
	} while (A == 0);

	printf("Input B\n");
	scanf("%d", &B);
	printf("Input C\n");
	scanf("%d", &C);

	OTV = (B * B) - (4 * A * C);

	if (OTV == 0)                                            
	{
		printf("Answer: YES\n");
	}
	else
	{
		printf("Answer: NO\n");
	}

	printf("_____________Task2_______________\n");              //Задание 2 

	do                                                        
	{
		printf("Input Integer positive four-digit number\n");
		scanf("%d", &N);
		A1 = N / 1000;
		A2 = N % 1000 / 100;
		A3 = N % 100 / 10;
		A4 = N % 10;
		A5 = N / 10000;
	} while (A5 != 0 || N <= 0 || A1 == 0);

	A = A1 + A2 + A3 + A4;

	B1 = A1 % 2;
	B2 = A2 % 2;
	B3 = A3 % 2;
	B4 = A4 % 2;

	if (B1 == 0)
	{
		C1 = A1;
	}
	if (B2 == 0)
	{
		C2 = A2;
	}
	if (B3 == 0)
	{
		C3 = A3;
	}
	if (B4 == 0)
	{
		C4 = A4;
	}

	B = C1 * C2 * C3 * C4;

	if (A == B)
	{
		printf("The sum of all numbers and the product of even numbers are equal\n");  
	}
	if (A > B)
	{
		printf("The sum of all numbers greater than the product of even numbers\n");
	}
	if (A < B)
	{
		printf("The sum of all numbers is less than the product of even numbers\n");
	}

	printf("_____________Task3_______________\n");                            //Задача 3

	do
	{                                                                                    
		printf("Enter a positive integer in the range from 1 to 999\n");       
		scanf("%d", &F);
	}
	while (F < 1 || F > 999);

	A1 = F / 100;
	A2 = (F - (A1 * 100)) / 10;
	A3 = (F - (A1 * 100)) - (A2 * 10);

	B1 = A3 % 2;

	if (A1 == 0 && A2 == 0 && B1 == 0)
	{
		printf("You entered a one-digit even number\n");
	}
	if (A1 == 0 && A2 == 0 && B1 != 0)
	{
		printf("You entered a one-digit not even number\n");
	}
	if (A1 == 0 && A2 != 0 && B1 == 0)
	{
		printf("You entered a two-digit even number\n");
	}
	if (A1 == 0 && A2 != 0 && B1 != 0)
	{
		printf("You entered a two-digit not even number\n");
	}
	if (A1 != 0 && B1 == 0)
	{
		printf("You entered a three-digit even number\n");
	}
	if (A1 != 0 && B1 != 0)
	{
		printf("You entered a three-digit not even number\n");
	}

	printf("_____________Task4_______________\n");                      //Задание 4           


	printf("Enter a string with words separated by dots\n");
	scanf("%s",TEXT1);

	for (i = 0; i < strlen(TEXT1); i++)
	{
		if (count == 3)
		{
			if (TEXT1[i] == '.')
			{
				printf("Answer: %s", OTV2);
				count += 1;
				break;
			}
			OTV2[o] = TEXT1[i];
			o += 1;
		}
		if (TEXT1[i] == '.')
		{
			count += 1;
		}		
	}
	if (count < 4)
	{
		printf("Answer: %s", TEXT1);
	}

	printf("\n_____________Task5_______________\n");                  //Задание 5

	do{
		do{
			do{
				do{
					do{
						printf("Enter Arithmetic expression of the form <Digit Sign Digit Sign Digit Sign Digit>, signs * and /, Digit by 1 to 9 \n");
						scanf("%s", &OTV3);
					} while ((OTV3[1] != '*' && OTV3[1] != '/') && (OTV3[3] != '*' && OTV3[3] != '/') && (OTV3[5] != '*' && OTV3[5] != '/'));
				} while (OTV3[0] != '1' && OTV3[0] != '2' && OTV3[0] != '3' && OTV3[0] != '4' && OTV3[0] != '5' && OTV3[0] != '6' && OTV3[0] != '7' && OTV3[0] != '8' && OTV3[0] != '9');
			} while (OTV3[2] != '1' && OTV3[2] != '2' && OTV3[2] != '3' && OTV3[2] != '4' && OTV3[2] != '5' && OTV3[2] != '6' && OTV3[2] != '7' && OTV3[2] != '8' && OTV3[2] != '9');
		} while (OTV3[4] != '1' && OTV3[4] != '2' && OTV3[4] != '3' && OTV3[4] != '4' && OTV3[4] != '5' && OTV3[4] != '6' && OTV3[4] != '7' && OTV3[4] != '8' && OTV3[4] != '9');
	} while (OTV3[6] != '1' && OTV3[6] != '2' && OTV3[6] != '3' && OTV3[6] != '4' && OTV3[6] != '5' && OTV3[6] != '6' && OTV3[6] != '7' && OTV3[6] != '8' && OTV3[6] != '9');


	H1 = OTV3[0];
	H2 = OTV3[2];
	H3 = OTV3[4];
	H4 = OTV3[6];

	H1 = H1 - 48;
	H2 = H2 - 48;
	H3 = H3 - 48;
	H4 = H4 - 48;

	if (OTV3[1] == '*')
	{
		H1 = H1 * H2;
	}
	if (OTV3[1] == '/')
	{
		H1 = H1 / H2;
	}
	if (OTV3[3] == '*')
	{
		H1 = H1 * H3;
	}
	if (OTV3[3] == '/')
	{
		H1 = H1 / H3;
	}
	if (OTV3[5] == '*')
	{
		H1 = H1 * H4;
	}
	if (OTV3[5] == '/')
	{
		H1 = H1 / H4;
	}

	printf("Answer: %lf", H1);

	return 0;
}

