﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//ВАРИАНТ № А14/Б22
//1. Ввести пять различных ненулевых целых чисел. Найти произведение трех наибольших чисел.

//2. Дан целочисленный массив, признак его завершения - число 0. Размер массива может быть разный. 
//Вывести сумму всех положительных четных чисел из данного массива. Если требуемые числа в наборе отсутствуют, то вывести 0.

//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти сумму и произведение всех четных чисел из данного массива.

//4. Написать функцию double Factorial(N) вещественного типа, вычисляющую значение факториала 
//N! = 1*2*…*N (N > 0 — параметр целого типа; вещественное возвращаемое значение используется 
//для того, чтобы избежать целочисленного переполнения при больших значениях N).

//5. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). 
//Длина строки может быть разной. Найти и вывести длину самого большого слова и вывести это слово на экран.

//6. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). 
//Длина строки может быть разной. Определить и вывести на экран количество слов, которые содержат ровно четыре буквы 'w'.

namespace PR52
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание1

            int[] MAS = new int[5];
            int MAX1, MAX2, MAX3;

            Console.WriteLine("Задание1");

            for (int i = 0; i < 5; i++)
            {
            m1:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " ненулевое число");
                    i--;
                    MAS[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch(FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m1;
                }
                catch(OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m1;
                }
                if (MAS[i] == 0)
                {
                    Console.WriteLine("Число не должно быть нулевым");
                    goto m1;
                }
            }

            MAX1 = MAS.Max();

            for (int i = 0; i < 5; i++)
            {
                if (MAS[i] == MAX1)
                {
                    MAS[i] = -999999;
                    break;
                }
            }

            MAX2 = MAS.Max();

            for (int i = 0; i < 5; i++)
            {
                if (MAS[i] == MAX2)
                {
                    MAS[i] = -999999;
                    break;
                }
            }


            MAX3 = MAS.Max();

            MAX1 = MAX1 * MAX2 * MAX3;

            Console.WriteLine("Произведение трех максимальных чисел равно " + MAX1);

            #endregion

            #region Задание2

            int[] MAS2 = new int [999999];
            int SUM = 0;
            int COUNT = 0;

            Console.WriteLine("Задание2");

            for (int i = 0; i < 999999; i++)
            {
            m2:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива (0 для завершения ввода)");
                    i--;
                    MAS2[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m2;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m2;
                }
                if (MAS2[i] == 0)
                {
                    COUNT++;
                    Console.WriteLine("Завершение массива...");
                    break;
                }
                COUNT++;
            }

            for (int i = 0; i < COUNT; i++)
            {
                if (MAS2[i] > 0 && MAS2[i] % 2 == 0)
                {
                    SUM += MAS2[i];
                }
            }

            Console.WriteLine("Сумма всех положительных четных чисел масива равна - " + SUM);

            #endregion

            #region Задание3

            int N;
            int SUM1 = 0;
            int MUL = 1;
            bool FLAG = false;

            Console.WriteLine("Задание3");

            m3:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m3;
            }
            if (N <= 0)
            {
                Console.WriteLine("Размер массива не должен быть отрицательным");
                goto m3;
            }

            int [] MAS3 = new int [N];

            for (int i = 0; i < N; i++)
            {
            m5:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива ");
                    i--;
                    MAS3[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m5;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m5;
                }
            }

            for (int i = 0; i < N; i++)
            {
                if (MAS3[i] % 2 == 0)
                {
                    FLAG = true;
                    SUM1 += MAS3[i];
                    MUL *= MAS3[i];
                }
            }

            if (FLAG == true)
            {
                Console.WriteLine("Сумма четных чисел массива равна " + SUM1 + ", а произведение равно - " + MUL);
            }
            else
            {
                Console.WriteLine("В массиве отсутствуют четные числа");
            }

            #endregion

            #region Задание4

            int A1 = 0;

            Console.WriteLine("Задание4");

            t1:
            try
            {
                Console.WriteLine("Введите число факториала, например, при вводе 5 будет выведен 5! (120)");
                A1 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto t1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto t1;
            }
            if (A1 < 0)
            {
                Console.WriteLine("Число факториала не может быть меньше 0");
                goto t1;
            }

            Console.WriteLine("Факториал числа - " + A1 + " равен - " + Factorial(A1));

            #endregion

            #region Задание5

            string txt1;
            string[] sl1;
            int count;
            int index = 0;

            Console.WriteLine("Задание5");

            t2:

            try
            {
                Console.WriteLine("Введите строку с подчеркиваниями");
                txt1 = Console.ReadLine();
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("Ошибка недостатка памяти");
                goto t2;
            }
            catch(ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка переполнения аргумента");
                goto t2;
            }
            if (txt1 == "")
            {
                Console.WriteLine("Введена пустая строка");
                goto t2;
            }

            sl1 = txt1.Split('_');
            count = sl1.Length;

            for (int i = 0; i < sl1.Length; i++ )
            {
                if (count < sl1[i].Length)
                {
                    count = sl1[i].Length;
                    index = i;
                }
            }

            Console.WriteLine("Самое больше слово - " + sl1[index] + " с кол-вом букв - " + count);

            #endregion

            #region Задание6

            string txt2;
            string word;
            int countword = 0;
            int countstring = 0;

            Console.WriteLine("Задание6");

        t3:

            try
            {
                Console.WriteLine("Введите строку с подчеркиваниями");
                txt2 = Console.ReadLine();
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("Ошибка недостатка памяти");
                goto t3;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка переполнения аргумента");
                goto t3;
            }
            if (txt2 == "")
            {
                Console.WriteLine("Введена пустая строка");
                goto t3;
            }

            sl1 = txt2.Split('_');

            for (int i = 0; i < sl1.Length; i++ )
            {
                countword = 0;
                word = sl1[i];
                char[] ch = word.ToArray();

                for (int z = 0; z < word.Length; z++)
                {
                    if (ch[z] == 'w')
                    {
                        countword++;
                    }
                }
                if (countword == 4)
                {
                    countstring++;
                }
            }

            Console.WriteLine("Кол-во слов с ровно четырьми буквами w в слове - " + countstring);

            #endregion

            Console.WriteLine("Нажмите любую клавишу для выхода из программы");
            Console.ReadKey();
        }

        static double Factorial(int N)
        {
            double ANS = 1.0;

            for (int i = 1; i < N + 1; i++ )
            {
                ANS *= Convert.ToDouble(i);
            }

            return ANS;
        }
    }
}
