package main

import (
	"fmt"
	"math"
)

//ВАРИАНТ № А14/Б32
//1. Дано вещественное число A и целое число N (N > 0).
//Вывести значение результата A в степени N: AN = A*A*...*A
//(число A перемножается N раз).

//2. Из шести целых чисел найти наибольшее и наименьшее число, а так же среднее
//арифметическое этих введенных чисел.

//3. Из пяти введенных целых положительных чисел найти два наибольших и
//вывести произведение этих двух наибольших чисел.

//4. Даны три целых ненулевых числа. Найти среднее из этих чисел
//(т. е. число, расположенное между наименьшим и наибольшим числом).

//5. Дано целое положительное число в диапазоне от 200 до 999.
//Вторая цифра не может быть единицей. Вывести строку - словесное
//описание данного числа, например: 256 - "двести пятьдесят шесть",
//874 - "восемьсот семьдесят четыре".

func main() {

	var A float64
	var Z float64
	var N int

	fmt.Println("Задание1")

	fmt.Println("Введите вещественное число А")
	fmt.Scan(&A)
	Z = A

m1:

	fmt.Println("Введите степень N")
	fmt.Scan(&N)

	if N < 0 {
		goto m1
	}

	A = math.Pow(A, float64(N))
	fmt.Printf("Число %f в степени %d равно %f\n", Z, N, A)

	fmt.Println("Задание2")

	var MAS [6]int
	var MAX int
	var MIN int
	var srar float64 = 0.0

	fmt.Println("Введите первое число")
	fmt.Scan(&MAS[0])
	fmt.Println("Введите второе число")
	fmt.Scan(&MAS[1])
	fmt.Println("Введите третье число")
	fmt.Scan(&MAS[2])
	fmt.Println("Введите четвертое число")
	fmt.Scan(&MAS[3])
	fmt.Println("Введите пятое число")
	fmt.Scan(&MAS[4])
	fmt.Println("Введите шестое число")
	fmt.Scan(&MAS[5])

	MAX = MAS[0]
	MIN = MAS[0]

	for i := 0; i < 6; i++ {
		if MAX < MAS[i] {
			MAX = MAS[i]
		}
		if MIN > MAS[i] {
			MIN = MAS[i]
		}
	}

	srar = (float64(MAS[0]) + float64(MAS[1]) + float64(MAS[2]) + float64(MAS[3]) + float64(MAS[4]) + float64(MAS[5])) / 6.0

	fmt.Printf("Минимальное число равно %d, максимальное число %d, среднее арифеметическое %f\n", MIN, MAX, srar)

	fmt.Println("Задание3")
	var MAX1 int
	var MAX2 int
	var MULM float64

c1:
	fmt.Println("Введите положительное первое число")
	fmt.Scan(&MAS[0])
	if MAS[0] <= 0 {
		goto c1
	}
c2:
	fmt.Println("Введите положительное второе число")
	fmt.Scan(&MAS[1])
	if MAS[1] <= 0 {
		goto c2
	}
c3:
	fmt.Println("Введите положительное третье число")
	fmt.Scan(&MAS[2])
	if MAS[2] <= 0 {
		goto c3
	}
c4:
	fmt.Println("Введите положительное четвертое число")
	fmt.Scan(&MAS[3])
	if MAS[3] <= 0 {
		goto c4
	}
c5:
	fmt.Println("Введите положительное пятое число")
	fmt.Scan(&MAS[4])
	if MAS[4] <= 0 {
		goto c5
	}

	MAX1 = MAS[0]

	for i := 0; i < 5; i++ {
		if MAX1 < MAS[i] {
			MAX1 = MAS[i]
			MAX2 = i
		}
	}

	MAS[MAX2] = -999999
	MAX2 = MAS[0]

	for i := 0; i < 5; i++ {
		if MAX2 < MAS[i] {
			MAX2 = MAS[i]
		}
	}

	MULM = float64(MAX1 * MAX2)

	fmt.Printf("Произведение двух наибольших чисел %f\n", MULM)

	fmt.Println("Задание4")

	var (
		B1 int
		B2 int
		B3 int
	)

a1:

	fmt.Println("Введите первое ненулевое число")
	fmt.Scan(&B1)
	if B1 == 0 {
		goto a1
	}

a2:

	fmt.Println("Введите второе ненулевое число")
	fmt.Scan(&B2)
	if B2 == 0 {
		goto a2
	}

a3:

	fmt.Println("Введите третье ненулевое число")
	fmt.Scan(&B3)
	if B3 == 0 {
		goto a3
	}

	if (B1 > B2 && B1 < B3) || (B1 < B2 && B1 > B3) {
		fmt.Printf("Среднее число %d\n", B1)
	}
	if (B2 > B1 && B2 < B3) || (B2 < B1 && B2 > B3) {
		fmt.Printf("Среднее число %d\n", B2)
	}
	if (B3 > B2 && B3 < B1) || (B3 < B2 && B3 > B1) {
		fmt.Printf("Среднее число %d\n", B3)
	}

	fmt.Println("Задание5")

	var TR int
	var (
		A1 int
		A2 int
		A3 int
	)

m10:

	fmt.Println("Введите число от 200 до 999")
	fmt.Scan(&TR)

	if TR < 200 || TR > 999 {
		fmt.Println("Число должно быть от 200 до 999")
		goto m10
	}
	if A2 == 1 {
		fmt.Println("Вторая цифра введенного числа не может быть равна единице")
		goto m10
	}

	A1 = TR / 100
	A2 = (TR - (A1 * 100)) / 10
	A3 = TR - (A1 * 100) - (A2 * 10)

	switch A1 {
	case 2:
		fmt.Print("двести ")
		break
	case 3:
		fmt.Print("триста ")
		break
	case 4:
		fmt.Print("четыреста ")
		break
	case 5:
		fmt.Print("пятьсот ")
		break
	case 6:
		fmt.Print("шестьсот ")
		break
	case 7:
		fmt.Print("семьсот ")
		break
	case 8:
		fmt.Print("восемьсот ")
		break
	case 9:
		fmt.Print("девятьсот ")
		break
	}

	switch A2 {
	case 0:
		fmt.Print("")
		break
	case 2:
		fmt.Print("двадцать ")
		break
	case 3:
		fmt.Print("тридцать ")
		break
	case 4:
		fmt.Print("сорок ")
		break
	case 5:
		fmt.Print("пятьдесят ")
		break
	case 6:
		fmt.Print("шестьдесят ")
		break
	case 7:
		fmt.Print("семьдесят ")
		break
	case 8:
		fmt.Print("восемьдесят ")
		break
	case 9:
		fmt.Print("девяносто ")
		break
	}

	switch A3 {
	case 0:
		fmt.Print("")
		break
	case 1:
		fmt.Print("один")
		break
	case 2:
		fmt.Print("два")
		break
	case 3:
		fmt.Print("три ")
		break
	case 4:
		fmt.Print("четыре")
		break
	case 5:
		fmt.Print("пять")
		break
	case 6:
		fmt.Print("шесть")
		break
	case 7:
		fmt.Print("семь")
		break
	case 8:
		fmt.Print("восемь")
		break
	case 9:
		fmt.Print("девять")
		break
	}
}
