package var14;

public class task03 {
    boolean ans3;
    double s;

    public boolean IsSquare(int K)
    {
        s = Math.sqrt(K);

        while(true)
        {
            if (s > 1)
            {
                s -= 1;
            }
            else
            {
                s -= 1;

                if (s == 0.0)
                {
                    return ans3 = true;
                }
                else
                {
                    return ans3 = false;
                }
            }
        }

    }
}
