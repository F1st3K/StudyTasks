package var14;

public class task01 {
    double ans1;
    int A;
    int A1, A2, A3, A4, A5;

    task01(int N)
    {
        A = N;
        ans1 = 1.0;
    }

    public double GetAnswer()
    {
        A1 = A / 10000;
        A2 = (A - (A1 * 10000)) / 1000;
        A3 = (A - (A1 * 10000) - (A2 * 1000)) / 100;
        A4 = (A - (A1 * 10000) - (A2 * 1000) - (A3 * 100)) / 10;
        A5 = (A - (A1 * 10000) - (A2 * 1000) - (A3 * 100) - (A4 * 10));

        ans1 = A1 * A2 * A3 * A4 * A5;

        return ans1;
    }
}
