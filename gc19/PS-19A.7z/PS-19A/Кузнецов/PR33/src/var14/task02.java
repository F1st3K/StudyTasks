package var14;

public class task02 {
    int A, A1, A2, A3;
    boolean ans1;


    task02(int N)
    {
        A = N;
    }

    public boolean GetAnswer()
    {
        A1 = A / 100;
        A2 = (A - (A1 * 100)) / 10;
        A3 = (A - (A1 * 100) - (A2 * 10));

        if (A1 + A2 + A3 == A1 * A3)
        {
            return ans1 = true;
        }
        else
        {
            return ans1 = false;
        }
    }
}
