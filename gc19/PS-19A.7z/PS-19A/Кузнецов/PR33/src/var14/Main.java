package var14;
import java.util.InputMismatchException;
import java.util.Scanner;

//ВАРИАНТ № 14
//1. Дано целое положительное пятизначное число N (N > 0). Используя операции деления и
// определения остатка от деления найти произведение всех его цифр.

//2. Ввести целое положительное трехзначное число N (N > 0). Проверить истинность высказывания:
// "Сумма всех цифр введенного числа равна произведению первой и третьей цифры введенного числа".

//3. Написать функцию bool IsSquare(K) логического типа, возвращающую True, если целый параметр K (K > 0)
// является квадратом некоторого целого числа, и False в противном случае.

public class Main {

    public static void main(String[] args) {

        int N = 0;
        double ans1 = 0.0;
        int K = 0;

        Scanner in1 = new Scanner(System.in);
        System.out.println("Задание1");

        try
        {
            System.out.println("Введите положительное пятизначное число");
            N = in1.nextInt();

            while (N < 10000 || N > 99999)
            {
                System.out.println("Вы ввели не положительное пятичзначное число");
                System.out.println("Введите положительное пятизначное число");
                N = in1.nextInt();
            }

            task01 t1 = new task01(N);

            ans1 = t1.GetAnswer();

            System.out.println("Произведение всех цифр введенного пятизначного положительного числа равно " + ans1);
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
        }

        Scanner in2 = new Scanner(System.in);
        System.out.println("Задание2");

        try
        {
            System.out.println("Введите положительное трехзначное число");
            N = in2.nextInt();

            while (N < 100 || N > 999)
            {
                System.out.println("Вы ввели не положительное трехзначное число");
                System.out.println("Введите положительное трехзначное число");
                N = in2.nextInt();
            }

            task02 t2 = new task02(N);

            if (t2.GetAnswer())
            {
                System.out.println("Да, сумма всех чисел равна произведению 1 и 3 цифр введенного числа");
            }
            else
            {
                System.out.println("Нет, сумма всех чисел не равна произведению 1 и 3 цифр введенного числа");
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
        }

        Scanner in3 = new Scanner(System.in);
        System.out.println("Задание3");

        try
        {
            System.out.println("Введите положительное число");
            K = in3.nextInt();

            while (K <= 0)
            {
                System.out.println("Ошибка, число не может быть меньше или равно 0");
                System.out.println("Введите положительное число");
                K = in3.nextInt();
            }

            task03 t3 = new task03();

            if (t3.IsSquare(K))
            {
                System.out.println("Да, число является корнем целого числа");
            }
            else
            {
                System.out.println("Нет, число не является корнем целого числа");
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
        }
    }
}
