﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//2. Ввести пять различных ненулевых целых чисел. Найти произведение наибольших чисел.

namespace var14
{
    class task02
    {
        public int[] MAS = new int[5];
        public int i;
        public int max1;
        public int max2;

        public void setdefault()
        {
            MAS[0] = 0;
            MAS[1] = 0;
            MAS[2] = 0;
            MAS[3] = 0;
            MAS[4] = 0;
            max1 = 0;
            max2 = 0;
            i = 0;
        }
        public void shownumoftask()
        {
            Console.WriteLine("Задание2");
        }
        public void getfirstnum(int a)
        {
            MAS[0] = a;
        }
        public void getsecondnum(int b)
        {
            MAS[1] = b;
        }
        public void getthirdnum(int c)
        {
            MAS[2] = c;
        }
        public void getfourthnum(int d)
        {
            MAS[3] = d;
        }
        public void getfifthnum(int e)
        {
            MAS[4] = e;
        }
        public void getfirstmax()
        {
            max1 = MAS.Max();
        }
        public void deletefirstmax()
        {
            for(i = 0; i < 5; i++)
            {
                if (MAS[i] == max1)
                {
                    MAS[i] = -99999;
                    break;
                }
            }
        }
        public void getsecondmax()
        {
            max2 = MAS.Max();
        }
        public void showanswer()
        {
            Console.WriteLine("Произведением двух максимальных чисел является число " + (max1 = max1 * max2));
        }
    }
}
