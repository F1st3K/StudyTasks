﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//5. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). 
//Требуется удалить из этой строки повторяющиеся символы. Например, если было введено "abc_cde_defg", 
//то должно быть выведено "abcdefg".

namespace var14
{
    class task05
    {
        public string TXT;

        public void shownumoftask()
        {
            Console.WriteLine("Задание5");
        }

        public string getanswer(string str)
        {
            TXT = new string(str.Distinct().ToArray());
            return TXT;
        }

        public void showanswer(string str)
        {
            Console.WriteLine("Новая строка - " + str);
        }
    }
}
