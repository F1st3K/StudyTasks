﻿//ВАРИАНТ № 14
//1. Проверить истинность высказывания: "Цифры данного целого положительного трехзначного числа, 
//введенного с клавиатуры, образуют убывающую последовательность".
//2. Ввести пять различных ненулевых целых чисел. Найти произведение наибольших чисел.
//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Поменять местами 
//минимальный и максимальный элемент этого массива. Вывести новый полученный массив.
//4. Вводится строка, изображающая целочисленное арифметическое выражение вида «цифра_цифра_цифра_цифра», 
//где на месте знака операции «_» находится символ «+» или «-», а на месте "цифра" находится одна из цифр (от 1 до 9). 
//Например, «4+7-2+5». Вывести значение данного выражения (как целое число).
//5. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). 
//Требуется удалить из этой строки повторяющиеся символы. Например, если было введено "abc_cde_defg", 
//то должно быть выведено "abcdefg".

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using var14;

namespace var14
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 0;
            int a, b, c, d, e, N;
            string TXT;
            int flag = 0;


            task02 task2 = new task02();
            task03 task3 = new task03();
            task04 task4 = new task04();
            task05 task5 = new task05();

            //__________Задание1___________//
            #region вводданных1
            Console.WriteLine("Задание1");
            m1:
            try
            {
                Console.WriteLine("Введите трехзначное число");
                n = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m1;
            }
            if (n < 100 || n > 999)
            {
                Console.WriteLine("Число должно быть трехзначным");
                goto m1;
            }
            #endregion
            task01 task1 = new task01(n);
            task1.getfirstnum();
            task1.getsecondnum();
            task1.getthirdnum();
            task1.showanswer();
            

            //__________Задание2___________//
            task2.setdefault();
            task2.shownumoftask();
            #region вводданных2
        m2:
            try
            {
                Console.WriteLine("Введите 1 число");
                a = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m2;
            }
            catch(OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            if (a == 0)
            {
                Console.WriteLine("Ошибка, число не должно равняться нулю");
                goto m2;
            }
        m3:
            try
            {
                Console.WriteLine("Введите 2 число");
                b = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m3;
            }
            if (b == 0)
            {
                Console.WriteLine("Ошибка, число не должно равняться нулю");
                goto m3;
            }
        m4:
            try
            {
                Console.WriteLine("Введите 3 число");
                c = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m4;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m4;
            }
            if (c == 0)
            {
                Console.WriteLine("Ошибка, число не должно равняться нулю");
                goto m4;
            }
        m5:
            try
            {
                Console.WriteLine("Введите 4 число");
                d = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m5;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m5;
            }
            if (d == 0)
            {
                Console.WriteLine("Ошибка, число не должно равняться нулю");
                goto m5;
            }
        m6:
            try
            {
                Console.WriteLine("Введите 5 число");
                e = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m6;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m6;
            }
            if (e == 0)
            {
                Console.WriteLine("Ошибка, число не должно равняться нулю");
                goto m6;
            }
            #endregion
            task2.getfirstnum(a);
            task2.getsecondnum(b);
            task2.getthirdnum(c);
            task2.getfourthnum(d);
            task2.getfifthnum(e);
            task2.getfirstmax();
            task2.deletefirstmax();
            task2.getsecondmax();
            task2.showanswer();

            //__________Задание3___________//
            task3.setdefault();
            task3.shownumoftask();
            #region вводданных3
        m10:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m10;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m10;
            }
            if (N <= 0)
            {
                Console.WriteLine("Ошибка, число не может быть отрицательным или равным 0");
                goto m10;
            }

            int[] MAS = new int[N];

            for (int i = 0; i < N; i++)
            {
            m20:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива");
                    i--;
                    MAS[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m20;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m20;
                }
            }
            #endregion
            task3.getmax(MAS);
            task3.getmin(MAS);
            task3.getminid(MAS, N);
            task3.getmaxid(MAS, N);
            MAS = task3.replace(MAS, N);
            task3.showanswer(MAS, N);

            //__________Задание4___________//
            task4.setdefault();
            task4.shownumoftask();
            #region вводданных4
        m7:
            try
            {
                Console.WriteLine("Введите строку вида (цифра_знак_цифра_знак_цифра_знак_цифра, цифры однозначные от 1 до 9, знаки + или -)");
                TXT = Console.ReadLine();
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("Ошибка памяти");
                goto m7;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка выхода за аргумент");
                goto m7;
            }
            if(TXT.Length < 7)
            {
                Console.WriteLine("Ошибка, неправильный ввод строки, пример (4+4-4+4)");
                goto m7;
            }
            if ((TXT[0] < '1' || TXT[0] > '9') || (TXT[1] != '+' && TXT[1] != '-') || (TXT[2] < '1' || TXT[2] > '9') || (TXT[3] != '+' && TXT[3] != '-') || (TXT[4] < '1' || TXT[4] > '9') || (TXT[5] != '+' && TXT[5] != '-') || (TXT[6] < '1' || TXT[6] > '9'))
            {
                Console.WriteLine("Ошибка, неправильный ввод строки, пример (4+4-4+4)");
                goto m7;
            }
            if (TXT.Length > 7)
            {
                Console.WriteLine("Ошибка, введен неправильный формат строки, смотрите образец");
                goto m7;
            }
            #endregion
            task4.getfirstnumber(TXT);
            task4.getsecondnumber(TXT);
            task4.getfirstsolution(TXT);
            task4.getthirdnumber(TXT);
            task4.getsecondsolution(TXT);
            task4.getfourthnumber(TXT);
            task4.getthirdsolution(TXT);
            task4.showanswer();

            //__________Задание5___________//
            task5.shownumoftask();
            #region вводданных5
        m70:
            try
            {
                Console.WriteLine("Введите строку с подчеркиваниями ('_'), одним или несколькими");
                TXT = Console.ReadLine();
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("Ошибка памяти");
                goto m70;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка выхода за аргумент");
                goto m70;
            }
            flag = 0;
            for (int i = 0; i < TXT.Length; i++ )
            {
                if (TXT[i] == '_')
                {
                    flag = 1;
                    break;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine("Ошибка, строка не содержит подчеркиваний");
                goto m70;
            }
            #endregion
            TXT = task5.getanswer(TXT);
            task5.showanswer(TXT);

            Console.WriteLine("Для завершения нажмите любую кнопку");
            Console.ReadKey();
        }
    }
}
