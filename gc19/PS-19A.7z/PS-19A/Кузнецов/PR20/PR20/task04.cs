﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//4. Вводится строка, изображающая целочисленное арифметическое выражение вида «цифра_цифра_цифра_цифра», 
//где на месте знака операции «_» находится символ «+» или «-», а на месте "цифра" находится одна из цифр (от 1 до 9). 
//Например, «4+7-2+5». Вывести значение данного выражения (как целое число).

namespace var14
{
    class task04
    {
        public int A, B, C, D;
        public void setdefault()
        {
            A = 0;
            B = 0;
            C = 0;
            D = 0;
        }
        public void shownumoftask()
        {
            Console.WriteLine("");
            Console.WriteLine("Задание4");
        }
        public void getfirstnumber(string TXT)
        {
            A = Convert.ToInt32(TXT[0]) - 48;
        }
        public void getsecondnumber(string TXT)
        {
            B = Convert.ToInt32(TXT[2]) - 48;
        }
        public void getfirstsolution(string TXT) 
        {
            if (TXT[1] == '+')
            {
                A += B;
            }
            else
            {
                A -= B;
            }
        }
        public void getthirdnumber(string TXT)
        {
            C = Convert.ToInt32(TXT[4]) - 48;
        }
        public void getsecondsolution(string TXT)
        {
            if (TXT[3] == '+')
            {
                A += C;
            }
            else
            {
                A -= C;
            }
        }
        public void getfourthnumber(string TXT)
        {
            D = Convert.ToInt32(TXT[6]) - 48;
        }
        public void getthirdsolution(string TXT)
        {
            if (TXT[5] == '+')
            {
                A += D;
            }
            else
            {
                A -= D;
            }
        }
        public void showanswer()
        {
            Console.WriteLine("Ответ = " + A);
        }
    }
}
