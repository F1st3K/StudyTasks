﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//1. Проверить истинность высказывания: "Цифры данного целого положительного трехзначного числа, 
//введенного с клавиатуры, образуют убывающую последовательность".

namespace var14
{
    class task01
    {
        public int num, A1, A2, A3;

        public task01(int n)
        {
            num = n;
        }
        public void getfirstnum()
        {
            A1 = num / 100;
        }
        public void getsecondnum()
        {
            A2 = (num - (A1 * 100)) / 10;
        }
        public void getthirdnum()
        {
            A3 = (num - (A1 * 100) - (A2 * 10));
        }
        public void showanswer()
        {
            if (A1 > A2 && A2 > A3)
            {
                Console.WriteLine("Да, число образует убывающую последовательность");
            }
            else
            {
                Console.WriteLine("Нет, число не образует убывающую последовательность");
            }
        }
    }
}
