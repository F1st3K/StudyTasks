﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Поменять местами 
//минимальный и максимальный элемент этого массива. Вывести новый полученный массив.

namespace var14
{
    class task03
    {
        public int i;
        public int max;
        public int min;

        public void setdefault()
        {
            i = 0;
            max = 0;
            min = 0;
        }
        public void shownumoftask()
        {
            Console.WriteLine("Задание3");
        }
        public void getmax(int [] MAS)
        {
            max = MAS.Max();
        }
        public void getmin(int[] MAS)
        {
            min = MAS.Min();
        }
        public void getminid(int[] MAS, int N)
        {
            for (i = 0; i < N; i ++)
            {
                if (MAS[i] == min)
                {
                    min = i;
                    break;
                }
            }
        }
        public void getmaxid(int[] MAS, int N)
        {
            for (i = 0; i < N; i++)
            {
                if (MAS[i] == max)
                {
                    max = i;
                    break;
                }
            }
        }
        public int[] replace(int[] MAS, int N)
        {
            i = MAS[max];
            MAS[max] = MAS[min];
            MAS[min] = i;
            return MAS;
        }
        public void showanswer(int[] MAS, int N)
        {
            for(i = 0; i < N; i++)
            {
                Console.Write(MAS[i] + " ");
            }
        }
    }
}
