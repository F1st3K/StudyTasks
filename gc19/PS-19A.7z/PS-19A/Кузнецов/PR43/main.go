package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

//Вариант 14
//Авиакомпания (char), тип самолета (char), номер рейса (int), время вылета (int), время прилета (int).
//Поиск по типу самолета.

type Air struct {
	AirName string // Название компании
	Jetname string // Название самолета
	Number  string // Номер рейса
	TimeOut string // Время вылета
	TimeIn  string // Время прилета
}

func main() {
	var N int
m1:
	fmt.Printf("Введите 1 - для поиска записи по номеру\n2 - для поиска по типу самолета\n3 - для выхода\n")
	_, err := fmt.Scan(&N)
	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m1
	}
	if N < 1 || N > 3 {
		fmt.Println("Введено неверное число")
		goto m1
	}
	switch N {
	case 1:
		showtonum()
		goto m1
	case 2:
		sel()
		goto m1
	case 3:
		os.Exit(0)
	}

}

func sel() {
	var A1 string
	var fl bool = false
	var TXT string
	var TXT1 []string
g1:
	fmt.Println("Введите название самолета (например, TU-134)")
	_, err := fmt.Scan(&A1)
	if err != nil {
		fmt.Println("Произошла ошибка")
		goto g1
	}

	f1, err := os.Open("input.txt")

	if err != nil {
		fmt.Println("не создан файл")
		os.Exit(0)
	}

	sc := bufio.NewScanner(f1)
	for sc.Scan() {
		TXT = sc.Text()
		if TXT == "" {
			break
		}
		TXT1 = strings.Split(TXT, ";")
		ANS := Air{TXT1[0], TXT1[1], TXT1[2], TXT1[3], TXT1[4]}
		if TXT1[1] == A1 {
			PrintJet(ANS)
			fl = true
		}
	}
	if fl != true {
		fmt.Println("По данному запросу не найдено записей")
	}
	f1.Close()
	return
}

func showtonum() {

	var A1 int
	var i int = 1
	var TXT string
	var TXT1 []string
g1:
	fmt.Println("Введите номер записи для вывода (от 1 до 15)")
	_, err := fmt.Scan(&A1)
	if err != nil {
		fmt.Println("Произошла ошибка")
		goto g1
	}
	if A1 < 1 || A1 > 15 {
		fmt.Println("Введен неверный номер записи")
		goto g1
	}

	f1, err := os.Open("input.txt")

	if err != nil {
		fmt.Println("не создан файл")
		os.Exit(0)
	}

	sc := bufio.NewScanner(f1)
	for sc.Scan() {
		TXT = sc.Text()
		TXT1 = strings.Split(TXT, ";")
		ANS := Air{TXT1[0], TXT1[1], TXT1[2], TXT1[3], TXT1[4]}
		if i == A1 {
			PrintJet(ANS)
			break
		}
		i++
	}
	f1.Close()
	return
}

func PrintJet(std Air) {
	fmt.Printf("%s	%s	  %s	%s	  %s\n______________________________\n", std.AirName, std.Jetname, std.Number, std.TimeOut, std.TimeIn)
}
