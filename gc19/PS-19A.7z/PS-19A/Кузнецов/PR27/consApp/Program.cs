﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using dllApp;

//ВАРИАНТ № А14/Б32
//1. Проверить истинность высказывания: "Сумма двух первых цифр данного четырехзначного целого положительного числа равна сумме двух его последних цифр".

//2. Дан целочисленный массив, состоящий из N элементов (N > 0). Проверить, образует ли данный набор возрастающую последовательность.
//Если образует, то вывести True, если нет - вывести False.

//3. Написать функцию int Min3(A, B, C) целого типа, возвращающую одно минимальное значение из 3-х своих аргументов 
//(параметры A, B, C - целые числа).

//4. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). 
//Требуется удалить из этой строки повторяющиеся символы. Например, если было введено "abc_cde_defg", 
//то должно быть выведено "abc_defg".

namespace consApp
{
    class Program
    {
        /// <summary>
        /// Основная функция, в которой выполняются все задания и выводятся ответы
        /// </summary>
        static void Main(string[] args)
        {
            task01 library1 = new task01();
            task02 library2 = new task02();
            task03 library3 = new task03();
            task04 library4 = new task04();

            #region Задание1

            int fourdegnumber = 0;

            Console.WriteLine("Задание1");

            m1:
            try
            {
                Console.WriteLine("Введите четырехзначное целое положительное число");
                fourdegnumber = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m1;
            }
            if (fourdegnumber < 1000 || fourdegnumber > 9999)
            {
                Console.WriteLine("Ошибка, нужно ввести четырехзначное положительное число");
                goto m1;
            }

            bool answer1 = library1.Task01(fourdegnumber);

            if (answer1 == true)
            {
                Console.WriteLine("Да, сумма двух первых чисел равна сумме двух последних цифр (четырехзначного числа)");
            }
            else
            {
                Console.WriteLine("Нет, сумма двух первых чисел не равна сумме двух последних цифр (четырехзначного числа)");
            }

            #endregion

            #region Задание2

            int sizeofarr = 0;

            Console.WriteLine("Задание2");

            m2:
            try
            {
                Console.WriteLine("Введите размер массива");
                sizeofarr = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            if (sizeofarr <= 0)
            {
                Console.WriteLine("Размер массива не может быть отрицательным или равным нулю");
                goto m2;
            }
            int[] array1 = new int[sizeofarr];

            for(int i = 0; i < sizeofarr; i++)
            {
                m3:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива");
                    i--;
                    array1[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch(FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m3;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m3;
                }
            }

            bool answer2 = library2.Task02(array1);

            if (answer2 == true)
            {
                Console.WriteLine("Да, массив образует возрастающую последовательность");
            }
            else
            {
                Console.WriteLine("Нет, массив не образует возрастающую последовательность");
            }

            #endregion

            #region Задание3

            int firstnumber = 0, secondnumber = 0, thirdnumber = 0;

            Console.WriteLine("Задание3");

            m41:
            try
            {
                Console.WriteLine("Введите 1 число");
                firstnumber = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m41;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m41;
            }

            m42:
            try
            {
                Console.WriteLine("Введите 2 число");
                secondnumber = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m42;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m42;
            }

            m43:
            try
            {
                Console.WriteLine("Введите 3 число");
                thirdnumber = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m43;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m43;
            }

            int answer3 = library3.Min3(firstnumber, secondnumber, thirdnumber);

            Console.WriteLine("Минимальное число = " + answer3);

            #endregion

            #region Задание4

            string String1;
            int flag1 = 0;

            Console.WriteLine("Задание4");

            m50:
            try
            {
                Console.WriteLine("Введите строку с подчеркиваниями");
                String1 = Console.ReadLine();
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("Ошибка, недостаточно памяти");
                goto m50;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка, ошибка переполнения аргумента");
                goto m50;
            }
            flag1 = 0;
            for (int i = 0; i < String1.Length; i++)
            {
                if (String1[i] == '_')
                {
                    flag1 = 1;
                    break;
                }
            }
            if (flag1 == 0)
            {
                Console.WriteLine("Введена строка без подчеркиваний");
                goto m50;
            }

            string answer4 = library4.Task04(String1);
            Console.WriteLine("Новая строка - " + answer4);

            #endregion

            Console.WriteLine("Введите любую клавишу для завершения программы");
            Console.ReadKey();
        }
    }
}
