﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllApp
{
    /// <summary>
    /// Класс для третьего задания
    /// </summary>
    public class task03
    {
        /// <summary>
        /// Находит минимальное число из 3 введенных чисел
        /// </summary>
        /// <param name="num1">Целое число</param>
        /// <param name="num2">Целое число</param>
        /// <param name="num3">Целое число</param>
        /// <returns>Минимальное число</returns>
        public int Min3(int num1, int num2, int num3)
        {
            int[] Arr = new int[3];
            int minimalnumber = 0;

            Arr[0] = num1;
            Arr[1] = num2;
            Arr[2] = num3;

            minimalnumber = Arr.Min();
            return minimalnumber;
        }
    }
}
