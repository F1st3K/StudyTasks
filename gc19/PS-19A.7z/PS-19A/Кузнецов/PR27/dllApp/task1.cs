﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllApp
{
    /// <summary>
    /// Класс 1 задания
    /// </summary>
    public class task01
    {
        /// <summary>
        /// Проверяет равно ли 2 первых числа 2 последним числам четырехзначного числа и выводит ответ.
        /// </summary>
        /// <param name="NUM1">Целое число</param>
        /// <returns>Положительный или отрицательный ответ</returns>
        public bool Task01(int NUM1)
        {
            bool ans = false;
            int flag = 0;

            if (NUM1 < 1000 || NUM1 > 9999)
            {
                flag = 1;
                return ans;
            }

            if (flag == 0)
            {
                int A1 = NUM1 / 1000;
                int A2 = (NUM1 - (A1 * 1000)) / 100;
                int A3 = (NUM1 - (A1 * 1000) - (A2 * 100)) / 10;
                int A4 = (NUM1 - (A1 * 1000) - (A2 * 100) - (A3 * 10));

                if ((A1 + A2) == (A3 + A4))
                {
                    ans = true;
                }
                else
                {
                    ans = false;
                }
            }

            return ans;
        }
               
    }
}
