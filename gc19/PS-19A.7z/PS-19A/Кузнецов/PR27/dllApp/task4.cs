﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllApp
{
    /// <summary>
    /// Класс для четвертого задания
    /// </summary>
    public class task04
    {
        /// <summary>
        /// Удаляет из строки повторяющееся символы
        /// </summary>
        /// <param name="Text">Строка</param>
        /// <returns>Обработанная строка</returns>
        public string Task04(string Text)
        {
            int flag1 = 0;
            for (int i = 0; i < Text.Length; i++)
            {
                if (Text[i] == '_')
                {
                    flag1 = 1;
                    break;
                }
            }

            if (flag1 == 1)
            {
                string answer4 = new string(Text.Distinct().ToArray());
                return answer4;
            }
            else
            {
                return Text;
            }
        }
    }
}
