﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dllApp
{
    /// <summary>
    /// Класс для второго задания
    /// </summary>
    public class task02
    {
        /// <summary>
        /// Проверяет расположены ли числа массива по возрастанию и выводит ответ.
        /// </summary>
        /// <param name="MAS">Целочисленный массив</param>
        /// <returns>Положительный или отрицательный ответ</returns>
        public bool Task02(int[] MAS)
        {
            bool ans2 = false;
            int work = 0;
            int flag = 0;

            for (int i = 0; i + 1 < MAS.Length; i++)
            {
                work = MAS[i];

                if (work < MAS[i + 1])
                {
                    flag = 0;
                }
                else
                {
                    flag = 1;
                    break;
                }
            }

            if (flag == 0)
            {
                ans2 = true;
            }
            else
            {
                ans2 = false;
            }
            if (MAS.Length == 1 || MAS.Length == 0)
            {
                ans2 = false;
            }

            return ans2;
        }
    }
}
