﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using dllApp;

namespace Tests
{
    [TestClass]
    public class test2
    {
        task02 library = new task02();

        [TestMethod]
        public void TestWithTrue()
        {
            int[] number = new int [3];
            number[0] = 0;
            number[1] = 1;
            number[2] = 2;
            bool expected = true;

            bool actual = library.Task02(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithFalse()
        {
            int[] number = new int[3];
            number[0] = 0;
            number[1] = 1;
            number[2] = 0;
            bool expected = false;

            bool actual = library.Task02(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithoutArray()
        {
            int[] number = new int[1];
            bool expected = false;

            bool actual = library.Task02(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithEquelNumbers()
        {
            int[] number = new int[3];
            number[0] = 1;
            number[1] = 1;
            number[2] = 1;
            bool expected = false;

            bool actual = library.Task02(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithNegativeNumbers()
        {
            int[] number = new int[3];
            number[0] = -2;
            number[1] = -1;
            number[2] = 0;
            bool expected = true;

            bool actual = library.Task02(number);

            Assert.AreEqual(expected, actual);
        }
    }
}
