﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using dllApp;

namespace Tests
{
    [TestClass]
    public class test1
    {
        task01 library = new task01();
        [TestMethod]
        public void TestWithTrue()
        {
            int number = 1221;
            bool expected = true;

            bool actual = library.Task01(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithFalse()
        {
            int number = 1222;
            bool expected = false;

            bool actual = library.Task01(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithLessNumber()
        {
            int number = 122;
            bool expected = false;

            bool actual = library.Task01(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithBiggerNumber()
        {
            int number = 12222;
            bool expected = false;

            bool actual = library.Task01(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithZero()
        {
            int number = 0;
            bool expected = false;

            bool actual = library.Task01(number);

            Assert.AreEqual(expected, actual);
        }
    }
}
