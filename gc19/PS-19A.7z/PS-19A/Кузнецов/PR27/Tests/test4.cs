﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using dllApp;

namespace Tests
{
    [TestClass]
    public class test4
    {
        task04 library = new task04();

        [TestMethod]
        public void TestWithSample()
        {
            string TXT = "abc_cde_defg";
            string expected = "abc_defg";

            string actual = library.Task04(TXT);

            Assert.AreEqual(actual, expected);
        }

        [TestMethod]
        public void TestWithoutString()
        {
            string TXT = "";
            string expected = "";

            string actual = library.Task04(TXT);

            Assert.AreEqual(actual, expected);
        }

        [TestMethod]
        public void TestWithoutReps()
        {
            string TXT = "abcsd";
            string expected = "abcsd";

            string actual = library.Task04(TXT);

            Assert.AreEqual(actual, expected);
        }

        [TestMethod]
        public void TestWithError()
        {
            string TXT = "abcsdasdasdfghssdgdgdsag_dsgsdagsdh_gsdsdgsdg";
            string expected = "a";

            string actual = library.Task04(TXT);

            Assert.AreEqual(actual, expected);
        }

        [TestMethod]
        public void TestWithoutUnderscores()
        {
            string TXT = "abcsdasdg";
            string expected = "abcsdasdg";

            string actual = library.Task04(TXT);

            Assert.AreEqual(actual, expected);
        }
    }
}
