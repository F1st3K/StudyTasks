﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using dllApp;

namespace Tests
{
    [TestClass]
    public class test3
    {
        task03 library = new task03();

        [TestMethod]
        public void TestWithPositiveNumbers()
        {
            int number1 = 1;
            int number2 = 2;
            int number3 = 3;
            int expected = 1;

            int actual = library.Min3(number1, number2, number3);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestWithNegativeNumbers()
        {
            int number1 = -1;
            int number2 = -2;
            int number3 = -3;
            int expected = -3;

            int actual = library.Min3(number1, number2, number3);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestWithNegativeAndPositiveNumbers()
        {
            int number1 = 1;
            int number2 = 5;
            int number3 = -3;
            int expected = -3;

            int actual = library.Min3(number1, number2, number3);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestWithEquelNumbers()
        {
            int number1 = 2;
            int number2 = 2;
            int number3 = 2;
            int expected = 2;

            int actual = library.Min3(number1, number2, number3);

            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestWithBigNumbers()
        {
            int number1 = 50121;
            int number2 = 20523;
            int number3 = 35021;
            int expected = 20523;

            int actual = library.Min3(number1, number2, number3);

            Assert.AreEqual(expected, actual);
        }
    }
}
