package main

import (
	"fmt"
	"math"
	"strconv"
	"strings"
)

//ВАРИАНТ № А14/Б22
//1. Задано целое положительное четырехзначное число N (N > 0).
//Найти разницу между суммой всех его цифр и произведением четных цифр.

//2. Дан целочисленный массив, состоящий из N элементов (N > 0).
//Поменять местами минимальный и максимальный элемент этого массива.
//Вывести новый полученный массив.

//3. Вводится строка, изображающая целочисленное арифметическое
//выражение вида «цифра_цифра_цифра_цифра», где на месте знака
//операции «_» находится символ «+» или «-», а на месте "цифра"
//находится одна из цифр (от 1 до 9). Например, «4+7-2+5».
//Вывести значение данного выражения (как целое число).

//4. Вводится строка, состоящая из слов, разделенных
//подчеркиваниями (одним или несколькими). Длина строки
//может быть разной. Определить и вывести количество слов,
//у которых второй и последний символ одинаковые.

//5. Вводится строка, содержащая буквы и цифры.
//Длина строки может быть разной. Вывести сумму
//и произведение цифр этой введенной строки.
//Чтобы избежать целочисленного переполнения при
//произведении, вычислять это выражение с помощью
//вещественной переменной и выводить его как вещественное число.

func main() {
	fmt.Println("Задание1")

	var N int
	var Sum int
	var fl bool = false
	var Mul int = 1

m1:

	fmt.Println("Введите целое четырехзначное положительное число N")
	_, err := fmt.Scan(&N)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m1
	}

	if N <= 0 {
		fmt.Println("Число должно быть положительным")
		goto m1
	}

	if N < 1000 || N > 9999 {
		fmt.Println("Число должно быть четырехзначным")
		goto m1
	}

	A1 := N / 1000
	A2 := (N - (A1 * 1000)) / 100
	A3 := (N - (A1 * 1000) - (A2 * 100)) / 10
	A4 := (N - (A1 * 1000) - (A2 * 100) - (A3 * 10))

	if A1%2 == 0 {
		Mul *= A1
		fl = true
	}
	if A2%2 == 0 {
		Mul *= A2
		fl = true
	}
	if A3%2 == 0 {
		Mul *= A3
		fl = true
	}
	if A4%2 == 0 {
		Mul *= A4
		fl = true
	}

	if fl == false {
		Mul = 0
	}

	Sum = A1 + A2 + A3 + A4

	Sum = int(math.Abs(float64(Sum - Mul)))
	fmt.Println("Разница между суммой всех цифр и произведением четных цифр введенного числа - ", Sum)

	fmt.Println("Задание2")

m2:

	fmt.Println("Введите размер массива")
	_, err = fmt.Scan(&N)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m2
	}

	if N <= 0 {
		fmt.Println("Рамер массива должен быть положительным")
		goto m2
	}

	var MAS []int
	var ASD int

	for i := 0; i < N; i++ {
	m3:
		i++
		fmt.Printf("Введите %d число массива\n", i)
		i--
		_, err = fmt.Scan(&ASD)

		if err != nil {
			fmt.Println("Произошла ошибка")
			goto m3
		}

		MAS = append(MAS, ASD)
	}

	MIN := MAS[0]
	MAX := MAS[0]

	for i := 0; i < N; i++ {
		if MIN > MAS[i] {
			MIN = MAS[i]
		}
		if MAX < MAS[i] {
			MAX = MAS[i]
		}
	}

	var f int = 0

	for i := 0; i < N; i++ {
		if MIN == MAS[i] {
			MAS[i] = MAX
			f = i
			break
		}
	}

	for i := 0; i < N; i++ {
		if MAX == MAS[i] && i != f {
			MAS[i] = MIN
			break
		}
	}
	fmt.Print("Новый массив - ")
	for i := 0; i < N; i++ {
		fmt.Print(MAS[i])
		fmt.Print(" ")
	}

	var TXT1 string
	fmt.Printf("\nЗадание3\n")

m4:
	fmt.Println("Введите строку вида (цифра_цифра_цифра_цифра, где на месте _ стоит знак + или -)")
	_, err = fmt.Scan(&TXT1)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m4
	}

	if (TXT1[0] >= '0' && TXT1[0] <= '9') && (TXT1[2] >= '0' && TXT1[2] <= '9') && (TXT1[4] >= '0' && TXT1[4] <= '9') && (TXT1[6] >= '0' && TXT1[6] <= '9') && (TXT1[1] == '+' || TXT1[1] == '-') && (TXT1[3] == '+' || TXT1[3] == '-') && (TXT1[5] == '+' || TXT1[5] == '-') && len(TXT1) == 7 {
		var SD string
		SD = string(TXT1[0])
		B1, _ := strconv.Atoi(SD)
		SD = string(TXT1[2])
		B2, _ := strconv.Atoi(SD)
		SD = string(TXT1[4])
		B3, _ := strconv.Atoi(SD)
		SD = string(TXT1[6])
		B4, _ := strconv.Atoi(SD)
		if TXT1[1] == '+' {
			B1 += B2
		} else {
			B1 -= B2
		}
		if TXT1[3] == '+' {
			B1 += B3
		} else {
			B1 -= B3
		}
		if TXT1[5] == '+' {
			B1 += B4
		} else {
			B1 -= B4
		}
		fmt.Println("Ответ - ", B1)
	} else {
		fmt.Println("Введен не верный формат строки")
		goto m4
	}
	fmt.Println("Задание4")

	var TXT2 string
	var L string
	var count int = 0

m5:
	fmt.Println("Введите строку с подчеркиваниями")
	_, err = fmt.Scan(&TXT2)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m5
	}

	str := strings.Split(TXT2, "_")

	for i := 0; i < len(str); i++ {
		L = str[i]
		if L[1] == L[len(L)-1] {
			count++
		}
	}

	fmt.Println("Кол-во слов у которых 2 буква и полследня одинаковые - ", count)

	fmt.Println("Задание5")
	var TXT3 string
	var sm int
	var mul float64 = 1.0
	var flag1 bool = false
	var DS string

m7:
	fmt.Println("Введите строку с цифрами")
	_, err = fmt.Scan(&TXT3)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m7
	}

	for i := 0; i < len(TXT3); i++ {
		if TXT3[i] >= '0' && TXT3[i] <= '9' {
			flag1 = true
			DS = string(TXT3[i])
			JK, _ := strconv.ParseInt(DS, 10, 64)
			sm += int(JK)
			mul *= float64(JK)
		}
	}

	if flag1 == true {
		fmt.Printf("Сумма цифр в строке - %d, произведение - %f", sm, mul)
	} else {
		fmt.Println("В строке нет цифр")
	}
}
