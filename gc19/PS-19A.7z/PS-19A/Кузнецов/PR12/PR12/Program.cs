﻿//ВАРИАНТ № А14/Б32
//1. Дано вещественное число A и целое число N (N > 0). Вывести значение результата A в степени N: AN = A*A*...*A (число A перемножается N раз).

//2. Из шести целых чисел найти наибольшее и наименьшее число, а так же среднее арифметическое этих введенных чисел.

//3. Из пяти введенных целых положительных чисел найти два наибольших и вывести произведение этих двух наибольших чисел.

//4. Даны три целых ненулевых числа. Найти среднее из этих чисел (т. е. число, расположенное между наименьшим и наибольшим числом).

//5. Дано целое положительное число в диапазоне от 200 до 999. Вторая цифра не может быть единицей. 
//Вывести строку - словесное описание данного числа, например: 256 - "двести пятьдесят шесть", 874 - "восемьсот семьдесят четыре".

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR12
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание1

            double A, AN;
            int N;

            Console.WriteLine("Задание1");

        m100:

            try
            {
                Console.WriteLine("Введите вещественное число");
                A = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат числа");
                goto m100;
            }

        m200:

            try
            {
                Console.WriteLine("Введите число, которое служит степенью");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат числа");
                goto m200;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Введен неверный формат числа");
                goto m200;
            }
            if (N <= 0)
            {
                Console.WriteLine("Введено неверная степень(N должна быть > 0)");
                goto m200;
            }

            AN = Math.Pow(A, N);
            Console.WriteLine("Ответ - AN = " + AN);

            #endregion

            #region Задание2
            int[] MAS = new int[6];
            int i = 0;
            int Flag = 0;
            double srAr = 0;
            int MAX, MIN;

            Console.WriteLine("Задание2");

            for (i = 0; i < 6; i++)
            {
                try
                {
                    Flag = 0;
                    i++;
                    Console.WriteLine("Введите " + i + " число");
                    i--;
                    MAS[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Flag = 1;
                }
                catch (IndexOutOfRangeException)
                {
                    Flag = 1;
                }
                catch (OverflowException)
                {
                    Flag = 1;
                }
                if (Flag == 1)
                {
                    i--;
                    Console.WriteLine("Введен неверный формат числа");
                }
            }

            srAr = (MAS[0] + MAS[1] + MAS[2] + MAS[3] + MAS[4] + MAS[5]) / 6.0;
            srAr = Math.Round(srAr, 2);
            MAX = MAS.Max();
            MIN = MAS.Min();
            Console.WriteLine("С помощью метода(найдено MIN и MAX соответственно): " + MIN + " и " + MAX);
            MAX = MAS[0];
            for (i = 0; i < 6; i++)
            {
                if (MAX < MAS[i])
                {
                    MAX = MAS[i];
                }
            }
            MIN = MAS[0];
            for (i = 0; i < 6; i++)
            {
                if (MIN > MAS[i])
                {
                    MIN = MAS[i];
                }
            }
            Console.WriteLine("С помощью цикла(найдено MIN и MAX соответственно): " + MIN + " и " + MAX);
            Console.WriteLine("Среднее арифметическое: " + srAr);

            #endregion

            #region Задание3

            int[] MAS1 = new int[5];
            int a;
            int Flag1, MAX1, MAX2;

            Console.WriteLine("Задание3");

            for (a = 0; a < 5; a++)
            {
               try
               {
                   Flag1 = 0;
                   a++;
                   Console.WriteLine("Введите " + a + " число");
                   a--;
                   MAS1[a] = Convert.ToInt32(Console.ReadLine());
               }
               catch (FormatException)
               {
                   Flag1 = 1;
                   Console.WriteLine("Введен неверный формат числа");
               }
               catch (IndexOutOfRangeException)
               {
                   Flag1 = 1;
                   Console.WriteLine("Введен неверный формат числа");
               }
               catch (OverflowException)
               {
                   Console.WriteLine("Введен неверный формат числа");
                   Flag1 = 1;
               }
               if (MAS1[a] < 0)
               {
                   Flag1 = 1;
               }
               if (Flag1 == 1)
               {
                   a--;
               }
           }

           MAX1 = MAS1[0];

           for (a = 0; a < 5; a++)
           {
               if (MAX1 < MAS1[a])
               {
                   MAX1 = MAS1[a];
               }
           }

           for (a = 0; a < 5; a++)
           {
               if (MAX1 == MAS1[a])
               {
                   MAS1[a] = 0;
                   a = 10;
               }
           }

           MAX2 = MAS1[0];

           for (a = 0; a < 5; a++)
           {
               if (MAX2 < MAS1[a])
               {
                   MAX2 = MAS1[a];
               }
            }

            Console.WriteLine("Первое максимальное число " + MAX1);
            Console.WriteLine("Второе максимальное число " + MAX2);
            Console.WriteLine("Произведение " + MAX1*MAX2);


            #endregion

            #region Задание4
            int a1, b, c;


            Console.WriteLine("Задание4");

        m1:

            try
            {
                Console.WriteLine("Введите первое число");
                a1 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m1;
            }

            if (a1 == 0)
            {
                Console.WriteLine("Число не должно быть равно 0");
                goto m1;
            }

        m2:

            try
            {
                Console.WriteLine("Введите второе число");
                b = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m2;
            }

            if (b == 0)
            {
                Console.WriteLine("Число не должно быть равно 0");
                goto m2;
            }

        m3:

            try
            {
                Console.WriteLine("Введите третье число");
                c = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m3;
            }
            if (c == 0)
            {
                Console.WriteLine("Число не должно быть равно 0");
                goto m3;
            }

            if ((a1 > b && a1 < c) || (a1 < b && a1 > c))
            {
                Console.WriteLine("Среднее число: " + a1);
            }
            if ((b > a1 && b < c) || (b < a1 && b > c))
            {
                Console.WriteLine("Среднее число: " + b);
            }
            if ((c > a1 && c < b) || (c < a1 && c > b))
            {
                Console.WriteLine("Среднее число: " + c);
            }

            #endregion

            #region Задание5

            int trx = 0;
            int A1, A2, A3, Fl = 0;

            Console.WriteLine("Задание5");
            
            m:
            do
            {
                try
                {
                    Fl = 0;
                    Console.WriteLine("Введите целое положительное число от 200 до 999(вторая цифра не равна 1)");
                    trx = Convert.ToInt32(Console.ReadLine());
                }
                catch(FormatException) 
                {
                    Fl = 1;
                }
                catch (OverflowException)
                {
                    Fl = 1;
                }

            }while(trx < 200 || trx > 999 || Fl != 0);

            A1 = trx / 100;
            A2 = (trx - (A1 * 100)) / 10;
            A3 = trx - (A1 * 100) - (A2 * 10);

            if (A2 == 1)
            {
                Console.WriteLine("Вторая цифра не может равняться 1");
                goto m;
            }

            

            Console.Write("Ответ: ");

            switch(A1)
            {
                case 2:
                    Console.Write("Двести ");
                    break;
                case 3:
                    Console.Write("Триста ");
                    break;
                case 4:
                    Console.Write("Четыреста ");
                    break;
                case 5:
                    Console.Write("Пятьсот ");
                    break;
                case 6:
                    Console.Write("Шестьсот ");
                    break;
                case 7:
                    Console.Write("Семьсот ");
                    break;
                case 8:
                    Console.Write("Восемьсот ");
                    break;
                case 9:
                    Console.Write("Девятьсот ");
                    break;
            }

            switch (A2)
            {
                case 2:
                    Console.Write("двадцать ");
                    break;
                case 3:
                    Console.Write("тридцать ");
                    break;
                case 4:
                    Console.Write("сорок ");
                    break;
                case 5:
                    Console.Write("пятьдесят ");
                    break;
                case 6:
                    Console.Write("шестьдесят ");
                    break;
                case 7:
                    Console.Write("семьдесят ");
                    break;
                case 8:
                    Console.Write("восемьдесят ");
                    break;
                case 9:
                    Console.Write("девяносто ");
                    break;
                case 0:
                    Console.Write(" ");
                    break;
            }

            switch (A3)
            {
                case 0:
                    Console.Write(" ");
                    break;
                case 1:
                    Console.Write("один ");
                    break;
                case 2:
                    Console.Write("два ");
                    break;
                case 3:
                    Console.Write("три ");
                    break;
                case 4:
                    Console.Write("четыре ");
                    break;
                case 5:
                    Console.Write("пять ");
                    break;
                case 6:
                    Console.Write("шесть ");
                    break;
                case 7:
                    Console.Write("семь ");
                    break;
                case 8:
                    Console.Write("восемь ");
                    break;
                case 9:
                    Console.Write("девять ");
                    break;
            }

            #endregion

            Console.ReadKey();
            }
        }
    }
