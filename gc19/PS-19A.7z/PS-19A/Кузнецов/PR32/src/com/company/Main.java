package com.company;
import java.util.InputMismatchException;
import java.util.Scanner;

//ВАРИАНТ № А14/Б32
//1. Дан целочисленный массив, состоящий из N элементов (N > 0). Преобразовать массив,
//прибавив к четным числам первый элемент. Первый и последний элементы массива не изменять.
// Вывести новый полученный массив.

//2. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти максимальный и
// минимальный элемент в массиве и вычислить их сумму.

//3. Написать функцию int Min5(A, B, C, D, E) целого типа, возвращающую одно минимальное
// значение из 5-и своих аргументов (параметры A, B, C, D и E - целые числа).

//4. Написать функцию bool Even(K) логического типа, возвращающую True, если целый
// параметр K является четным, и False в противном случае. С ее помощью найти количество
// четных чисел в наборе из 10 целых положительных чисел.

public class Main {

    public static void main(String[] args) {

        int a = 2;
        Scanner in = new Scanner(System.in);

        while(a != 0) {
            try {
                System.out.println("Меню");
                System.out.println("Введите 1 - для выполнения 1-го задания, 2 - для 2-го задания, 3 - для 3-го задания, 4 - для 4-го задания, 0 - для выхода");
                a = in.nextInt();

                while (a < 0 || a > 4) {
                    System.out.println("Введено не правильное число");
                    System.out.println("Введите 1 - для выполнения 1-го задания, 2 - для 2-го задания, 3 - для 3-го задания, 4 - для 4-го задания, 0 - для выхода");
                    a = in.nextInt();
                }
            } catch (InputMismatchException ex) {
                System.out.println("Ошибка формата");
                System. exit(0);
            } catch (StackOverflowError ex) {
                System.out.println("Ошибка переполнения");
                System. exit(0);
            }

            switch (a) {
                case (0):

                    break;

                case (1):

                    //region Задание1

                    int N = 0;
                    int M = 0;
                    int fl = 1;
                    Scanner in1 = new Scanner(System.in);
                    System.out.println("Задание1");

                    try {
                        System.out.println("Введите размер массива");
                        N = in1.nextInt();
                        if (N > 0 && N < 20)
                        {
                            fl = 0;
                        }
                        if (fl == 0)
                        {
                            System.out.println("Размер массива не может быть меньше 0, хотите продолжить с заданным размером (1 - да, 2 - нет)");
                            M = in1.nextInt();
                            while (M < 1 || M > 2)
                            {
                                System.out.println("Введен неверный вариант ответа");
                                System.out.println("Введите вариант ответа");
                                M = in1.nextInt();
                            }
                            if (M == 1)
                            {
                                fl = 1;
                            }
                            else
                            {
                                while (fl == 0)
                                {
                                    System.out.println("Введите размер массива (больше 20)");
                                    N = in1.nextInt();
                                    while (N < 0) {
                                        System.out.println("Размер массива не может быть 0 или меньше");
                                        System.out.println("Введите размер массива (больше 20)");
                                        N = in1.nextInt();
                                    }
                                    if (N < 20)
                                    {
                                        fl = 0;
                                    }
                                    else
                                    {
                                        fl = 1;
                                    }
                                }
                            }
                        }

                        while (N < 0) {
                            System.out.println("Размер массива не может быть 0");
                            System.out.println("Введите размер массива");
                            N = in1.nextInt();
                        }

                        int[] MAS = TASK1(N);

                        if (MAS[0] != 999999) {
                            System.out.print("Новый массив - ");
                            for (int i = 0; i < N; i++) {
                                System.out.print(MAS[i] + " ");
                            }
                            System.out.println("");
                        } else {
                            break;
                        }
                    } catch (InputMismatchException ex) {
                        System.out.println("Ошибка формата");
                        break;
                    } catch (StackOverflowError ex) {
                        System.out.println("Ошибка переполнения");
                        break;
                    }


                    //endregion
                    break;

                case (2):

                    //region Задание2

                    int N1 = 0;
                    int fl1 = 1;
                    Scanner in2 = new Scanner(System.in);
                    System.out.println("Задание2");

                    try {
                        System.out.println("Введите размер массива");
                        N1 = in2.nextInt();
                        if (N1 > 0 && N1 < 20)
                        {
                            fl1 = 0;
                        }
                        if (fl1 == 0)
                        {
                            System.out.println("Размер массива не может быть меньше 0, хотите продолжить с заданным размером (1 - да, 2 - нет)");
                            M = in2.nextInt();
                            while (M < 1 || M > 2)
                            {
                                System.out.println("Введен неверный вариант ответа");
                                System.out.println("Введите вариант ответа");
                                M = in2.nextInt();
                            }
                            if (M == 1)
                            {
                                fl1 = 1;
                            }
                            else
                            {
                                while (fl1 == 0)
                                {
                                    System.out.println("Введите размер массива (больше 20)");
                                    N1 = in2.nextInt();
                                    while (N1 < 0) {
                                        System.out.println("Размер массива не может быть 0 или меньше");
                                        System.out.println("Введите размер массива (больше 20)");
                                        N1 = in2.nextInt();
                                    }
                                    if (N1 < 20)
                                    {
                                        fl1 = 0;
                                    }
                                    else
                                    {
                                        fl1 = 1;
                                    }
                                }
                            }
                        }

                        while (N1 < 0) {
                            System.out.println("Размер массива не может быть 0");
                            System.out.println("Введите размер массива");
                            N1 = in2.nextInt();
                        }

                        int[] MAS = TASK2(N1);

                        if (MAS[0] != 999999) {
                            System.out.println("Максимальное число массива равно " + MAS[0] + ", минимальное число массива равно " + MAS[1] + ", их сумма равна " + MAS[2]);
                        } else {
                            break;
                        }
                    } catch (InputMismatchException ex) {
                        System.out.println("Ошибка формата");
                        break;
                    } catch (StackOverflowError ex) {
                        System.out.println("Ошибка переполнения");
                        break;
                    }

                    //endregion
                    break;

                case (3):

                    //region Задание3

                    int A = 0, B = 0, C = 0, D = 0, E = 0;
                    Scanner in3 = new Scanner(System.in);
                    System.out.println("Задание3");

                    try
                    {
                        System.out.println("Введите 1 число");
                        A = in3.nextInt();
                    }
                    catch (InputMismatchException ex)
                    {
                        System.out.println("Ошибка формата");
                        break;
                    }
                    catch (StackOverflowError ex)
                    {
                        System.out.println("Ошибка переполнения");
                        break;
                    }
                    try
                    {
                        System.out.println("Введите 2 число");
                        B = in3.nextInt();
                    }
                    catch (InputMismatchException ex)
                    {
                        System.out.println("Ошибка формата");
                        break;
                    }
                    catch (StackOverflowError ex)
                    {
                        System.out.println("Ошибка переполнения");
                        break;
                    }
                    try
                    {
                        System.out.println("Введите 3 число");
                        C = in3.nextInt();
                    }
                    catch (InputMismatchException ex)
                    {
                        System.out.println("Ошибка формата");
                        break;
                    }
                    catch (StackOverflowError ex)
                    {
                        System.out.println("Ошибка переполнения");
                        break;
                    }
                    try
                    {
                        System.out.println("Введите 4 число");
                        D = in3.nextInt();
                    }
                    catch (InputMismatchException ex)
                    {
                        System.out.println("Ошибка формата");
                        break;
                    }
                    catch (StackOverflowError ex)
                    {
                        System.out.println("Ошибка переполнения");
                        break;
                    }
                    try
                    {
                        System.out.println("Введите 5 число");
                        E = in3.nextInt();
                    }
                    catch (InputMismatchException ex)
                    {
                        System.out.println("Ошибка формата");
                        break;
                    }
                    catch (StackOverflowError ex)
                    {
                        System.out.println("Ошибка переполнения");
                        break;
                    }
                    System.out.println("Минимальное число из 5 введенных равно " + Min5(A, B, C, D, E));

                    //endregion
                    break;

                case (4):

                    //region Задание4

                    int [] MAS4 = new int [10];
                    int counter = 0;
                    int Z;
                    Scanner in4 = new Scanner(System.in);
                    System.out.println("Задание4");

                    try
                    {
                        for (int i = 0; i < MAS4.length; i++)
                        {
                            i++;
                            System.out.println("Введите " + i + " число");
                            i--;
                            MAS4[i] = in4.nextInt();
                        }

                        for (int i = 0; i < MAS4.length; i++)
                        {
                            if (Even(MAS4[i]))
                            {
                                counter += 1;
                            }
                        }

                        System.out.println("Количество четных чисел равно " + counter);
                    }
                    catch (InputMismatchException ex)
                    {
                        System.out.println("Произошла ошибка формата");
                        break;
                    }
                    catch (StackOverflowError ex)
                    {
                        System.out.println("Произошла ошибка переполнения");
                        break;
                    }

                    //endregion
                    break;

                default:

                    if (a == 10) {
                        System.out.println("Произошла ошибка формата");
                    } else {
                        System.out.println("Произошла ошибка переполнения");
                    }
            }
        }

    }

    public static int[] TASK1(int N)
    {
        Scanner in1 = new Scanner(System.in);
        int [] MAS = new int [N];
        int [] ERR = new int [1];
        ERR[0] = 999999;

        try
        {
            for (int i = 0; i < N; i++)
            {
                i++;
                System.out.println("Введите " + i + " число массива");
                i--;
                MAS[i] = in1.nextInt();
            }

            for (int i = 1; i < N - 1; i++)
            {
                if (MAS[i] % 2 == 0)
                {
                    MAS[i] += MAS[0];
                }
            }

            return MAS;
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Произошла ошибка формата");
            return ERR;
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Произошла ошибка переполнения");
            return ERR;
        }
    }

    public static int[] TASK2(int N)
    {
        Scanner in2 = new Scanner(System.in);
        int [] MAS = new int [N];
        int [] ANS = new int [3];
        int [] ERR = new int [1];
        ERR[0] = 999999;

        try
        {
            for (int i = 0; i < N; i++)
            {
                i++;
                System.out.println("Введите " + i + " число массива");
                i--;
                MAS[i] = in2.nextInt();
            }

            int MIN = MAS[0];
            int MAX = MAS[0];

            for (int i = 0; i < N; i++)
            {
                if (MIN > MAS[i])
                {
                    MIN = MAS[i];
                }
                if (MAX < MAS[i])
                {
                    MAX = MAS[i];
                }
            }

            ANS[0] = MAX;
            ANS[1] = MIN;
            MAX += MIN;
            ANS[2] = MAX;

            return ANS;
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Произошла ошибка формата");
            return ERR;
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Произошла ошибка переполнения");
            return ERR;
        }
    }

    public static int Min5(int A, int B, int C, int D, int E)
    {
        int [] MAS = new int [5];

        MAS[0] = A;
        MAS[1] = B;
        MAS[2] = C;
        MAS[3] = D;
        MAS[4] = E;

        int min = MAS[0];
        for (int i = 0; i < 5; i++)
        {
            if (min > MAS[i])
            {
                min = MAS[i];
            }
        }

        return min;
    }

    public static boolean Even(int K)
    {
        boolean ANS;

        if (K % 2 == 0)
        {
            ANS = true;
        }
        else
        {
            ANS = false;
        }

        return ANS;
    }
}
