﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using var14;

namespace var14
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, b, c;
            int i = 1;

            Console.WriteLine("Работа с памятью");
            #region ВводДанных
        m1:
            try
            {
                Console.WriteLine("Введите кол-во мегабайт (Мб)");
                a = Convert.ToDouble(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                Console.WriteLine("");
                goto m1;
            }
            catch(OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                Console.WriteLine("");
                goto m1;
            }
            if (a < 0)
            {
                Console.WriteLine("Ошибка, числа должны быть больше 0");
                Console.WriteLine("");
                goto m1;
            }
        m2:
            try
            {
                Console.WriteLine("Введите кол-во килобайт (Кб)");
                b = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                Console.WriteLine("");
                goto m2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                Console.WriteLine("");
                goto m2;
            }
            if (b < 0)
            {
                Console.WriteLine("Ошибка, числа должны быть больше 0");
                Console.WriteLine("");
                goto m2;
            }
        m3:
            try
            {
                Console.WriteLine("Введите кол-во байт (Б)");
                c = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                Console.WriteLine("");
                goto m3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                Console.WriteLine("");
                goto m3;
            }
            if (c < 0)
            {
                Console.WriteLine("Ошибка, числа должны быть больше 0");
                Console.WriteLine("");
                goto m3;
            }
#endregion
            WorkWithStorage WorkWithStorage = new WorkWithStorage(a, b, c);
            #region Меню
        m100:
            try
            {
                Console.WriteLine("Нажмите:");
                Console.WriteLine("1 - для отображения кол-ва памяти в Мб");
                Console.WriteLine("2 - для отображения кол-ва памяти в Кб");
                Console.WriteLine("3 - для отображения кол-ва памяти в Б");
                Console.WriteLine("4 - для отображения всей памяти с использованием Мб, Кб, Б");
                Console.WriteLine("5 - для выхода");
                i = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                Console.WriteLine("");
                goto m100;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                Console.WriteLine("");
                goto m100;
            }
            if (i < 1 || i > 5)
            {
                Console.WriteLine("Ошибка, неверное число");
                Console.WriteLine("");
                goto m100;
            }
            #endregion

            #region ВыборФункции
            switch (i)
            {
                case (1):
                    Console.WriteLine("Кол-во памяти в Мб = " + WorkWithStorage.CountMb());
                    Console.WriteLine("");
                    goto m100;
                case (2):
                    Console.WriteLine("Кол-во памяти в Кб = " + WorkWithStorage.CountKb());
                    Console.WriteLine("");
                    goto m100;
                case (3):
                    Console.WriteLine("Кол-во памяти в Б = " + WorkWithStorage.CountB());
                    Console.WriteLine("");
                    goto m100;
                case (4):
                    WorkWithStorage.ShowAll();
                    goto m100;
                case(5):
                    break;
            #endregion
            }

        }
    }
}
