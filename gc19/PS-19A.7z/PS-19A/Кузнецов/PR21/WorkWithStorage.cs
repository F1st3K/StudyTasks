﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace var14
{
    class WorkWithStorage
    {
        public double megabyte;
        public double kilobyte;
        public double obyte;
        public double storage;

        public WorkWithStorage(double a, double b, double c)
        {
            megabyte = a;
            kilobyte = b;
            obyte = c;
            storage = 0;
        }

        public void ShowAll()
        {
            Console.WriteLine("Мегабайты: " + megabyte);
            Console.WriteLine("Килобайты: " + kilobyte);
            Console.WriteLine("Байты - " + obyte);
            Console.WriteLine("");
        }
        public double CountMb()
        {
            storage = megabyte + (kilobyte / 1024) + (obyte / 1048576);
            storage = Math.Round(storage, 2);
            return storage;
        }
        public double CountKb()
        {
            storage = (megabyte * 1024) + kilobyte + (obyte / 1024);
            storage = Math.Round(storage, 2);
            return storage;
        }

        public double CountB()
        {
            storage = (megabyte * 1048576) + (kilobyte * 1024) + obyte;
            return storage;
        }
    }
}
