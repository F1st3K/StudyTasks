package main

import (
	"fmt"
	"math"
	"math/rand"
	"strconv"
	"time"
)

//ВАРИАНТ № А14/Б22
//1. Ввести целое положительное число. Проверить истинность высказывания:
//"Данное целое число является четным двузначным числом".

//2. Дан целочисленный массив, состоящий из N элементов (N > 0).
//Заменить в массиве все элементы, встречающиеся ровно два раза
//на значение -999.

//3. В вещественном массиве хранятся сведения о количестве осадков,
//выпавших за каждый день месяца N (в месяце должно быть 30 дней).
//Определить общее количество осадков, выпавших за каждую декаду
//этого месяца (декада состоит из 10 дней).

//4. Написать функцию double RingS(R1, R2) вещественного типа,
//находящую площадь кольца, заключенного между двумя окружностями
//с общим центром и радиусами R1 и R2 (R1 и R2 — вещественные, R1 > R2).
//Воспользоваться формулой площади круга радиуса R: S = π·R2.
//В качестве значения π использовать 3.14.

//5. Вводится строка, изображающая целочисленное арифметическое
//выражение вида «цифра_цифра_цифра_цифра», где на месте знака
//операции «_» находится символ «+» или «-», а на месте "цифра"
//находится одна из цифр (от 1 до 9). Например, «4+7-2+5».
//Вывести значение данного выражения (как целое число).

func main() {

	var num1 int

	fmt.Println("Задание1")

m1:
	fmt.Println("Введите целое положительное число")
	_, err := fmt.Scan(&num1)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m1
	}

	if num1 <= 0 {
		fmt.Println("Число должно быть положительным")
		goto m1
	}

	if num1 > 9 && num1 < 100 && num1%2 == 0 {
		fmt.Println("Да, введенное число двухзначное и четное")
	} else {
		fmt.Println("Нет, введенное число не двухзначное и четное")
	}

	var N int
	var A int
	var A1, A2 int
	var flag bool = false
	var count int = 0
	var MAS []int

	fmt.Println("Задание2")
m2:
	fmt.Println("Введите размер массива")
	_, err = fmt.Scan(&N)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m2
	}

	if N <= 0 {
		fmt.Println("Размер массива не должен быть меньше или равен нулю")
		goto m2
	}

	for i := 0; i < N; i++ {
	m3:
		i++
		fmt.Printf("Введите %d число массива\n", i)
		i--

		_, err = fmt.Scan(&A)

		if err != nil {
			fmt.Println("Произошла ошибка")
			goto m3
		}

		MAS = append(MAS, A)
	}

	for i := 0; i < N; i++ {
		A = MAS[i]
		if MAS[i] != -999 {
			for z := 0; z < N; z++ {
				if MAS[z] == MAS[i] && flag == true {
					count++
					A2 = z
				}
				if MAS[z] == MAS[i] && flag == false {
					count++
					flag = true
					A1 = z
				}
			}
		}
		if count == 2 {
			MAS[A1] = -999
			MAS[A2] = -999
		}
		flag = false
		count = 0
	}
	fmt.Print("Новый массив ")
	for i := 0; i < N; i++ {
		fmt.Printf("%d ", MAS[i])
	}
	fmt.Println("")

	var MAS2 []int
	var Z1 int = 0
	var Z2 int = 0
	var Z3 int = 0

	fmt.Println("Задание3")
m4:
	fmt.Println("Введите число месяца (от 1 до 12), чтобы в этом мясяце было ровно 30 дней")
	_, err = fmt.Scan(&N)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m4
	}

	if N < 1 || N > 12 {
		fmt.Println("Ошибка, введен не верное число месяца (должно быть от 1 до 12)")
		goto m4
	}

	if N != 4 && N != 6 && N != 9 && N != 11 {
		fmt.Println("Ошибка, выбран месяц не ровно с 30 днями")
		goto m4
	}

	rand.Seed(time.Now().UTC().UnixNano())

	for i := 0; i < 30; i++ {
		A = rand.Intn(100)
		MAS2 = append(MAS2, A)
	}

	for i := 0; i < 10; i++ {
		Z1 += MAS2[i]
	}
	fmt.Printf("За 1 декаду выпало %d осадков\n", Z1)
	for i := 9; i < 20; i++ {
		Z2 += MAS2[i]
	}
	fmt.Printf("За 2 декаду выпало %d осадков\n", Z2)
	for i := 19; i < 30; i++ {
		Z3 += MAS2[i]
	}
	fmt.Printf("За 3 декаду выпало %d осадков\n", Z3)

	var R1 int
	var R2 int

	fmt.Println("Задание4")

m6:
	fmt.Println("Введите R1 (радиус большей окружности, то есть R1 > R2)")
	_, err = fmt.Scan(&R1)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m6
	}

	if R1 <= 0 {
		fmt.Println("Радиус не может быть отрицательным или равным нулю")
		goto m6
	}

m7:
	fmt.Println("Введите R2 (радиус меньшей окружности, то есть R1 > R2)")
	_, err = fmt.Scan(&R2)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m7
	}

	if R2 <= 0 {
		fmt.Println("Радиус не может быть отрицательным или равным нулю")
		goto m7
	}

	if R1 > R2 {
		fmt.Println("Радиус меньшей окружности должен быть меньше радиуса большей окружности")
		goto m7
	}

	S1 := 3.14 * math.Pow(float64(R1), 2)
	S2 := 3.14 * math.Pow(float64(R2), 2)

	S1 = S2 - S1
	fmt.Printf("Площадь кольца равна %f\n", S1)

	var TXT1 string

	fmt.Printf("\nЗадание5\n")

m40:
	fmt.Println("Введите строку вида (цифра_цифра_цифра_цифра, где на месте _ стоит знак + или -)")
	_, err = fmt.Scan(&TXT1)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m40
	}

	if (TXT1[0] >= '0' && TXT1[0] <= '9') && (TXT1[2] >= '0' && TXT1[2] <= '9') && (TXT1[4] >= '0' && TXT1[4] <= '9') && (TXT1[6] >= '0' && TXT1[6] <= '9') && (TXT1[1] == '+' || TXT1[1] == '-') && (TXT1[3] == '+' || TXT1[3] == '-') && (TXT1[5] == '+' || TXT1[5] == '-') && len(TXT1) == 7 {
		var SD string
		SD = string(TXT1[0])
		B1, _ := strconv.Atoi(SD)
		SD = string(TXT1[2])
		B2, _ := strconv.Atoi(SD)
		SD = string(TXT1[4])
		B3, _ := strconv.Atoi(SD)
		SD = string(TXT1[6])
		B4, _ := strconv.Atoi(SD)
		if TXT1[1] == '+' {
			B1 += B2
		} else {
			B1 -= B2
		}
		if TXT1[3] == '+' {
			B1 += B3
		} else {
			B1 -= B3
		}
		if TXT1[5] == '+' {
			B1 += B4
		} else {
			B1 -= B4
		}
		fmt.Println("Ответ - ", B1)
	} else {
		fmt.Println("Введен не верный формат строки")
		goto m40
	}
}
