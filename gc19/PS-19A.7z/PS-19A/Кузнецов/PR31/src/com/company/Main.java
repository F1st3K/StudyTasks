package com.company;
import java.util.InputMismatchException;
import java.util.Scanner;

//ВАРИАНТ № А14/Б22
//1. Проверить истинность высказывания: "Цифры данного целого положительного
// четырехзначного числа образуют убывающую последовательность".

//2. Даны два целых положительных числа A и B (A < B).
// Найти произведение всех чисел расположенных между этими числами A и B.

//3. В вещественном массиве известны данные о количестве осадков, выпавших за каждый
// день месяца N (N - любой месяц в году). Найти общее число осадков, выпавших по четным числам месяца.

//4. Вводится строка, состоящая из цифр и символов английского алфавита. Длина строки может быть разной.
// Вывести на экран произведение всех нечетных цифр этого числа.

//5. Вводится строка, состоящая из букв и цифр. Длина строки может быть разной.
// Вывести на экран произведение цифр '3', '5' и '7', встречающихся в этой строке.

public class Main {

    public static void main(String[] args) {

	    //region Задание1

        int num1 = 0;

        Scanner in1 = new Scanner(System.in);
        System.out.println("Задание1");

        try
        {
            System.out.println("Введите целое положительное четырехзначное число");
            num1 = in1.nextInt();

            while (num1 < 1000 || num1 > 9999)
            {
                System.out.println("Введено неверное число");
                System.out.println("Введите целое положительное четырехзначное число (положительное четырехзначное)");
                num1 = in1.nextInt();
            }

            int A1 = num1 / 1000;
            int A2 = (num1 - (A1 * 1000)) / 100;
            int A3 = (num1 - (A1 * 1000) - (A2 * 100)) / 10;
            int A4 = (num1 - (A1 * 1000) - (A2 * 100) - (A3 * 10));

            if (A1 > A2 && A2 > A3 && A3 > A4)
            {
                System.out.println("Да, цифры введеного четырехзначного числа образуют убывающую последовательность");
            }
            else
            {
                System.out.println("Нет, цифры введеного четырехзначного числа не образуют убывающую последовательность");
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        //endregion

        //region Задание2

        double ans2 = 1.0;
        int A = 0, B = 0;

        Scanner in2 = new Scanner(System.in);
        System.out.println("Задание2");

        try
        {
            System.out.println("Введите целое число А (А < B)");
            A = in2.nextInt();
            System.out.println("Введите целое число B (А < B)");
            B = in2.nextInt();

            while (A > B)
            {
                System.out.println("Ошибка, число A должно быть меньше B");
                System.out.println("Введите целое число B (А < B)");
                B = in2.nextInt();
            }

            for (int i = A+1; i < B; i++)
            {
                ans2 *= i;
            }

            System.out.println("Произведение чисел между " + A + " и " + B + " равно " + ans2);
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        //endregion

        //region Задание3

        int N = 0;
        double rainy = 0.0;

        Scanner in3 = new Scanner(System.in);
        System.out.println("Задание3");

        try
        {
            System.out.println("Введите число месяца (от 1 до 12)");
            N = in3.nextInt();

            while (N < 1 || N > 12)
            {
                System.out.println("Ошибка, введено не верное число месяца");
                System.out.println("Введите число месяца (от 1 до 12)");
                N = in3.nextInt();
            }

            double [] MAS1 = new double [31];

            switch (N)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    for (int i = 0; i < 31; i++)
                    {
                        i++;
                        System.out.println("Введите " + i + " число массива");
                        i--;
                        MAS1[i] = in3.nextDouble();
                    }

                    for (int i = 0; i < 31; i++)
                    {
                        if (i % 2 != 0)
                        {
                            rainy += MAS1[i];
                        }
                    }

                    System.out.println("Общее число осадков, выпавших по четным числам месяца равно " + rainy);
                    break;

                case 4:
                case 6:
                case 9:
                case 11:
                    for (int i = 0; i < 30; i++)
                    {
                        i++;
                        System.out.println("Введите " + i + " число массива");
                        i--;
                        MAS1[i] = in3.nextDouble();
                    }

                    for (int i = 0; i < 30; i++)
                    {
                        if (i % 2 != 0)
                        {
                            rainy += MAS1[i];
                        }
                    }

                    System.out.println("Общее число осадков, выпавших по четным числам месяца равно " + rainy);
                    break;

                case 2:
                    for (int i = 0; i < 28; i++)
                    {
                        i++;
                        System.out.println("Введите " + i + " число массива");
                        i--;
                        MAS1[i] = in3.nextDouble();
                    }

                    for (int i = 0; i < 28; i++)
                    {
                        if (i % 2 != 0)
                        {
                            rainy += MAS1[i];
                        }
                    }

                    System.out.println("Общее число осадков, выпавших по четным числам месяца равно " + rainy);
                    break;
            }
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        //endregion

        //region Задание4

        double ans4 = 1.0;
        String TXT;

        Scanner in4 = new Scanner(System.in);
        System.out.println("Задание4");

        try
        {
            System.out.println("Введите строку");
            TXT = in4.next();

            while (TXT.equals(""))
            {
                System.out.println("Ошибка, введена пустая строка");
                System.out.println("Введите строку");
                TXT = in4.next();
            }

            char [] res = TXT.toCharArray();

            for (int i = 0; i < TXT.length(); i++)
            {
                if (res[i] == '1')
                {
                    ans4 *= 1;
                }
                if (res[i] == '3')
                {
                    ans4 *= 3;
                }
                if (res[i] == '5')
                {
                    ans4 *= 5;
                }
                if (res[i] == '7')
                {
                    ans4 *= 7;
                }
                if (res[i] == '9')
                {
                    ans4 *= 9;
                }
            }

            System.out.println("Произведение нечетных цифр введенной строки равно " + ans4);
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        //endregion

        //region Задание5

        String TXT2;
        double ans5 = 1.0;

        Scanner in5 = new Scanner(System.in);
        System.out.println("Задание5");

        try
        {
            System.out.println("Введите строку");
            TXT2 = in4.next();

            while (TXT2.equals(""))
            {
                System.out.println("Ошибка, введена пустая строка");
                System.out.println("Введите строку");
                TXT2 = in4.next();
            }

            char [] res1 = TXT2.toCharArray();

            for (int i = 0; i < TXT2.length(); i++)
            {
                if (res1[i] == '3')
                {
                    ans5 *= 3;
                }
                if (res1[i] == '5')
                {
                    ans5 *= 5;
                }
                if (res1[i] == '7')
                {
                    ans5 *= 7;
                }
            }

            System.out.println("Произведение цифр 3, 5, 7 введенной строки равно " + ans5);
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }

        //endregion
    }
}
