﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

//1. Задано целое положительное четырехзначное число N (N > 0). Найти разницу между произведениями первых двух и последних двух его цифр.

namespace PR22
{
    class task01
    {
        int A1, A2, A3, A4;
        int a;
        public task01(int c)
        {
            a = c;
        }
        public void inreg()
        {
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("four-degree num (task1)", a);
        }
        public void outreg()
        {
            a = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("four-degree num (task1)"));
        }
        public int getanswer()
        {
            A1 = a / 1000;
            A2 = (a - (A1 * 1000)) / 100;
            A3 = (a - (A1 * 1000) - (A2 * 100)) / 10;
            A4 = a - (A1 * 1000) - (A2 * 100) - (A3 * 10);

            a = Math.Abs((A3 * A4) - (A1 * A2));

            return a;
        }
    }
}
