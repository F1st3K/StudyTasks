﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

//4. Написать функцию int RootCount(A, B, C) целого типа, определяющую количество корней квадратного уравнения A*x2 + B*x + C = 0 
//(A, B, C — вещественные параметры, A ≠ 0). Количество корней уравнения определять по значению дискриминанта: D = B2 − 4*A*C.

namespace PR22
{
    class task04
    {
        int A, B, C;
        int [] MAS = new int [3];
        public task04(int Z, int X, int V)
        {
            A = Z;
            B = X;
            C = V;
        }
        public void inreg()
        {
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("First radical (task4)", A);
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("Second radical (task4)", B);
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("Third radical (task4)", C);
        }
        public int[] outreg()
        {
            A = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("First radical (task4)"));
            B = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("Second radical (task4)"));
            C = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("Third radical (task4)"));
            MAS[0] = A;
            MAS[1] = B;
            MAS[2] = C;
            return MAS;
        }
        public int RootCount(int X, int F, int Q)
        {
            if (((F * 2) - (4 * X * Q)) == 0)
            {
                X = 1;
            }
            if (((F * 2) - (4 * X * Q)) < 0)
            {
                X = 0;
            }
            if (((F * 2) - (4 * X * Q)) > 0)
            {
                X = 2;
            }

            return X;
        }
    }
}
