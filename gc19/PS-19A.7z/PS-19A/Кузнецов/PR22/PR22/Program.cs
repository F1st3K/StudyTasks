﻿//ВАРИАНТ № А14/Б32
//1. Задано целое положительное четырехзначное число N (N > 0). Найти разницу между произведениями первых двух и последних двух его цифр.
//2. Даны три целых ненулевых числа. Найти среднее из этих чисел (т. е. число, расположенное между наименьшим и наибольшим числом).
//3. Проверить истинность высказывания: "Сумма двух первых цифр данного четырехзначного целого положительного числа равна сумме двух его последних цифр".
//4. Написать функцию int RootCount(A, B, C) целого типа, определяющую количество корней квадратного уравнения A*x2 + B*x + C = 0 
//(A, B, C — вещественные параметры, A ≠ 0). Количество корней уравнения определять по значению дискриминанта: D = B2 − 4*A*C.
//5. Вводится строка, содержащая буквы и цифры. Длина строки может быть разной. Вывести сумму и произведение цифр этой введенной строки. 
//Чтобы избежать целочисленного переполнения при произведении, вычислять это выражение с помощью вещественной переменной и выводить его как вещественное число.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace PR22
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c;
            int A, B, C;
            double SUM, MOD;
            string TXT;
            int[] MAS = new int[3];
            Console.WriteLine("задание1");
            m1:
            try
            {
                Console.WriteLine("Введите положительное четырехзначное число");
                a = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m1;
            }
            if (a < 1000 || a > 9999)
            {
                Console.WriteLine("Ошибка, введено неверное число");
                goto m1;
            }

            task01 task01 = new task01(a);

            task01.inreg();
            task01.outreg();
            a = task01.getanswer();
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22\task01").SetValue("result1", a);

            Console.WriteLine("задание2");
            m2:
            try
            {
                Console.WriteLine("Введите первое целое число");
                A = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            m3:
            try
            {
                Console.WriteLine("Введите второе целое число");
                B = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m3;
            }
            m4:
            try
            {
                Console.WriteLine("Введите третье целое число");
                C = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m4;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m4;
            }

            task02 task02 = new task02(A, B, C);

            task02.inreg();
            task02.outreg();
            a = task02.getanswer();
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22\task02").SetValue("result2", a);

            Console.WriteLine("задание3");

            m5:
            try
            {
                Console.WriteLine("Введите положительное четырехзначное число");
                a = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m5;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m5;
            }
            if (a < 1000 || a > 9999)
            {
                Console.WriteLine("Ошибка, введено неверное число");
                goto m5;
            }

            task03 task03 = new task03(a);

            task03.inreg();
            task03.outreg();
            a = task03.getanswer();
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22\task03").SetValue("result3", a);

            Console.WriteLine("задание4");
            m8:
            try
            {
                Console.WriteLine("Введите 1 корень");
                a = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m8;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m8;
            }
            if (a == 0)
            {
                Console.WriteLine("Ошибка, число A не должно быть равно 0");
                goto m8;
            }
            m9:
            try
            {
                Console.WriteLine("Введите 2 корень");
                b = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m9;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m9;
            }
            m10:
            try
            {
                Console.WriteLine("Введите 3 корень");
                c = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формтата");
                goto m10;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m10;
            }

            task04 task04 = new task04(a, b, c);

            task04.inreg();
            MAS = task04.outreg();
            A = MAS[0];
            B = MAS[1];
            C = MAS[2];
            A = task04.RootCount(A, B, C);
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22\task04").SetValue("result4", A);

            Console.WriteLine("задание5");
            m30:
            try
            {
                Console.WriteLine("Введите строку с цифрами");
                TXT = Console.ReadLine();
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("Ошибка переполнения памяти");
                goto m30;
            }
            catch(ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка переполнения аргумента");
                goto m30;
            }

            task05 task05 = new task05(TXT);

            task05.inreg();
            task05.outreg();
            SUM = task05.getsum();
            MOD = task05.getmod();

            Registry.CurrentUser.CreateSubKey(@"Software\PR_22\task05").SetValue("result5(sum)", SUM);
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22\task05").SetValue("result5(mod)", MOD);

            Console.ReadKey();
        }
    }
}
