﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

//5. Вводится строка, содержащая буквы и цифры. Длина строки может быть разной. Вывести сумму и произведение цифр этой введенной строки. 
//Чтобы избежать целочисленного переполнения при произведении, вычислять это выражение с помощью вещественной переменной и выводить его как вещественное число.

namespace PR22
{
    class task05
    {
        string TXT;
        double sum = 0;
        double a;
        double mod = 1;
        public task05(string F)
        {
            TXT = F;
        }
        public void inreg()
        {
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("Text (task5)", TXT);
        }
        public void outreg()
        {
            TXT = Convert.ToString(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("Text (task5)"));
        }
        public double getsum()
        {
            for (int i = 0; i < TXT.Length; i++)
            {
                a = Convert.ToDouble(TXT[i] - 48);

                if (a >= 1 && a <= 9)
                {
                    sum += a;
                }
            }

            return sum;
        }
        public double getmod()
        {
            for (int i = 0; i < TXT.Length; i++)
            {
                a = Convert.ToDouble(TXT[i] - 48);

                if (a >= 1 && a <= 9)
                {
                    mod *= a;
                }
            }

            return mod;
        }
    }
}
