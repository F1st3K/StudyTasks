﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

//3. Проверить истинность высказывания: "Сумма двух первых цифр данного четырехзначного целого положительного числа равна сумме двух его последних цифр".

namespace PR22
{
    class task03
    {
        int A1, A2, A3, A4;
        int a;
        public task03(int z)
        {
            a = z;
        }

        public void inreg()
        {
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("four-degree num (task3)", a);
        }
        public void outreg()
        {
            a = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("four-degree num (task3)"));
        }
        public int getanswer()
        {
            A1 = a / 1000;
            A2 = (a - (A1 * 1000)) / 100;
            A3 = (a - (A1 * 1000) - (A2 * 100)) / 10;
            A4 = a - (A1 * 1000) - (A2 * 100) - (A3 * 10);

            if (A1 + A2 == A3 + A4)
            {
                a = 1;
            }
            else
            {
                a = 0;
            }

            return a;
        }
    }
}
