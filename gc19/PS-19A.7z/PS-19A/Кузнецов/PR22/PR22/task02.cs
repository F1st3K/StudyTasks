﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

//2. Даны три целых ненулевых числа. Найти среднее из этих чисел (т. е. число, расположенное между наименьшим и наибольшим числом).

namespace PR22
{
    class task02
    {
        int a, b, c;
        public task02(int z, int x, int v)
        {
            a = z;
            b = x;
            c = v;
        }
        public void inreg()
        {
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("first num (task2)", a);
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("second num (task2)", b);
            Registry.CurrentUser.CreateSubKey(@"Software\PR_22").SetValue("third num (task2)", c);
        }
        public void outreg()
        {
            a = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("first num (task2)"));
            b = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("second num (task2)"));
            c = Convert.ToInt32(Registry.CurrentUser.OpenSubKey(@"Software\PR_22").GetValue("third num (task2)"));
        }
        public int getanswer()
        {
            if ((a > b && a < c) || (a < b && a > c))
            {
                
            }
            if ((c > b && c < a) || (c < b && c > a))
            {
                a = c;
            }
            if ((b > c && b < a) || (b < c && b > a))
            {
                a = b;
            }

            return a;
        }
    }
}
