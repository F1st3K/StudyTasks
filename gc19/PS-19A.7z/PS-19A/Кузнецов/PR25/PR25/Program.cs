﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Word = Microsoft.Office.Interop.Word;

//ВАРИАНТ № А14/Б32

//1. Из шести целых чисел найти наибольшее и наименьшее число, а так же среднее арифметическое этих введенных чисел.

//2. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти сумму и произведение всех нечетных чисел из данного массива.

//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Найти и вывести количество элементов, расположенных перед первым минимальным элементом.

//4. Написать функцию double Factorial(N) вещественного типа, вычисляющую значение факториала N! = 1*2*…*N (N > 0 — параметр целого типа; 
//вещественное возвращаемое значение используется для того, чтобы избежать целочисленного переполнения при больших значениях N).

//5. Вводится строка, состоящая из слов, разделенных подчеркиваниями (одним или несколькими). Длина строки может быть разной. 
//Найти и вывести длину самого большого слова и вывести это слово на экран.

//6. Вводится строка, содержащая буквы и цифры. Длина строки может быть разной. Вывести сумму и произведение цифр этой введенной строки. 
//Чтобы избежать целочисленного переполнения при произведении, вычислять это выражение с помощью вещественной переменной и выводить его как вещественное число.

namespace PR25
{
    class Program
    {
        static void Main(string[] args)
        {
            
            #region задание1
            int[] MAS = new int[6];
            Console.WriteLine("Данные в документе Word появятся после ввода всех значений");
            Console.WriteLine("во всех заданиях с консоли");
            Console.WriteLine("");
            Console.WriteLine("Задание1");


            for (int i = 0; i < 6; i++)
            {
                m1:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " целое число");
                    i--;
                    MAS[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m1;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m1;
                }
            }

            int min = MAS.Min();
            int max = MAS.Max();
            double sr = (min + max) / 2;
            sr = Math.Round(sr , 2);

            
            #endregion

            #region задание2

            int N = 0;
            int a = 0;
            int sum = 0;
            double mod = 1.0;

            Console.WriteLine("Задание2");
            m2:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m2;
            }
            catch(OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            if (N <= 0)
            {
                Console.WriteLine("Ошибка, размер массива не может быть отрицательным");
                goto m2;
            }
            if (N < 25)
            {
                Console.WriteLine("По условию, размер массива должен быть более чем 25 чисел");
                m10:
                try
                {
                Console.WriteLine("Хотите ли вы продолжить работу с введенным размером? (1 = ДА, 0 = НЕТ)");
                a = Convert.ToInt32(Console.ReadLine());
                }
                catch(FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m10;
                }
                catch(OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m10;
                }
                if (a < 0 || a > 1)
                {
                    Console.WriteLine("Введено неверное значение ответа");
                    goto m10;
                }
                if (a == 1)
                {
                    goto m20;
                }
                if (a == 0)
                {
                    goto m2;
                }
            }

            m20:
            int[] MAS2 = new int[N];

            for (int i = 0; i < N; i++)
            {
                m3:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива");
                    i--;
                    MAS2[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m3;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m3;
                }
            }
            for (int i = 0; i < N; i++)
            {
                if (MAS2[i] % 2 != 0)
                {
                    sum += MAS2[i];
                    mod *= MAS2[i];
                }
            }



            #endregion

            #region задание3
            Console.WriteLine("Задание3");
            m21:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m21;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m21;
            }
            if (N <= 0)
            {
                Console.WriteLine("Ошибка, размер массива не может быть отрицательным");
                goto m21;
            }
            if (N < 25)
            {
                Console.WriteLine("По условию, размер массива должен быть более чем 25 чисел");
            m101:
                try
                {
                    Console.WriteLine("Хотите ли вы продолжить работу с введенным размером? (1 = ДА, 0 = НЕТ)");
                    a = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m101;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m101;
                }
                if (a < 0 || a > 1)
                {
                    Console.WriteLine("Введено неверное значение ответа");
                    goto m101;
                }
                if (a == 1)
                {
                    goto m201;
                }
                if (a == 0)
                {
                    goto m21;
                }
            }

            m201:

            int[] MAS11 = new int[N];
            for (int i = 0; i < N; i++)
            {
                m31:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива");
                    i--;
                    MAS11[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m31;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m31;
                }
            }

            int amin = MAS11.Min();

            for(int i = 0; i < N; i++)
            {
                if (MAS11[i] == amin)
                {
                    amin = i;
                    break;
                }
            }

            #endregion

            #region задание4

            int fact = 0;
            double ans3 = 1.0;
            Console.WriteLine("Задание4");
            f1:
            try
            {
                Console.WriteLine("Введите сколько чисел будет в факториале");
                fact = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto f1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto f1;
            }
            if (fact <= 0)
            {
                Console.WriteLine("Ошибка, факториал не может быть отрицательным");
                goto f1;
            }

            ans3 = Factorial(fact);

            #endregion

            #region задание5

            string TXT;

            Console.WriteLine("Задание5");
            f2:
            try
            {
                Console.WriteLine("Введите строку");
                TXT = Console.ReadLine();
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("Ошибка памяти");
                goto f2;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка аргумента");
                goto f2;
            }
            if (TXT == "")
            {
                Console.WriteLine("Ошибка, строка не может быть пустой");
                goto f2;
            }
            string[] str = TXT.Split(new Char[] { '_' }, StringSplitOptions.RemoveEmptyEntries);

            int s = 0, index = 0;
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i].Length > s)
                {
                    s = str[i].Length;
                    index = i;
                }
            }

            #endregion

            #region задание6
            Console.WriteLine("Задание6");
            double sm = 0;
            double md = 1.0;

            f3:
            try
            {
                Console.WriteLine("Введите строку");
                TXT = Console.ReadLine();
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("Ошибка памяти");
                goto f3;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка аргумента");
                goto f3;
            }
            if (TXT == "")
            {
                Console.WriteLine("Ошибка, строка не может быть пустой");
                goto f3;
            }

            for(int i = 0; i < TXT.Length; i++)
            {
                if (TXT[i] >= '0' && TXT[i] <= '9')
                {
                    sm += Convert.ToInt32(TXT[i]) - 48;
                    md *= Convert.ToInt32(TXT[i]) - 48;
                }
            }

            #endregion

            #region вывод данных
            Word.Application wdApp = new Word.Application();
            Word.Document wdDoc = null;
            Object wdMiss = System.Reflection.Missing.Value;

            wdDoc = wdApp.Documents.Add(ref wdMiss, ref wdMiss, ref wdMiss, ref wdMiss);

            wdDoc.PageSetup.Orientation = Word.WdOrientation.wdOrientPortrait;

            wdDoc.PageSetup.TopMargin = wdApp.InchesToPoints(0.59f);
            wdDoc.PageSetup.BottomMargin = wdApp.InchesToPoints(0.59f);
            wdDoc.PageSetup.LeftMargin = wdApp.InchesToPoints(0.67f);
            wdDoc.PageSetup.RightMargin = wdApp.InchesToPoints(0.59f);

            wdApp.Visible = true;

            wdApp.ActiveWindow.Selection.ParagraphFormat.LineSpacingRule = Word.WdLineSpacing.wdLineSpaceSingle;
            wdApp.ActiveWindow.Selection.ParagraphFormat.SpaceAfter = 0.59f;

            Word.Paragraph oglav;
            oglav = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            oglav.Range.Text = "Вариант 14";
            oglav.Range.Font.Bold = 1;
            oglav.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            oglav.Range.Font.Size = Convert.ToInt32(20);
            oglav.Range.InsertParagraphAfter();
            oglav.CloseUp();

            Word.Paragraph task1oglav;
            task1oglav = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task1oglav.Range.Text = "Задание 1";
            task1oglav.Range.Font.Bold = 0;
            task1oglav.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            task1oglav.Range.Font.Size = Convert.ToInt32(18);
            task1oglav.Range.InsertParagraphAfter();
            task1oglav.CloseUp();

            Word.Paragraph task1an1;
            task1an1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task1an1.Range.Text = "Минимальное число = " + Convert.ToString(min);
            task1an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task1an1.Range.Font.Size = Convert.ToInt32(14);
            task1an1.Range.InsertParagraphAfter();
            task1an1.CloseUp();

            Word.Paragraph task1an2;
            task1an2 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task1an2.Range.Text = "Максимальное число = " + Convert.ToString(max);
            task1an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task1an2.Range.Font.Size = Convert.ToInt32(14);
            task1an2.Range.InsertParagraphAfter();
            task1an2.CloseUp();

            Word.Paragraph task1an3;
            task1an3 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task1an3.Range.Text = "Среднее арифметическое минимального и максимального числа = " + Convert.ToString(sr);
            task1an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task1an3.Range.Font.Size = Convert.ToInt32(14);
            task1an3.Range.InsertParagraphAfter();
            task1an3.CloseUp();

            Word.Paragraph task2oglav;
            task2oglav = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task2oglav.Range.Text = "Задание 2";
            task2oglav.Range.Font.Bold = 0;
            task2oglav.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            task2oglav.Range.Font.Size = Convert.ToInt32(18);
            task2oglav.Range.InsertParagraphAfter();
            task2oglav.CloseUp();

            Word.Paragraph task2an1;
            task2an1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task2an1.Range.Text = "Сумма нечетных чисел массива = " + Convert.ToString(sum);
            task2an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task2an1.Range.Font.Size = Convert.ToInt32(14);
            task2an1.Range.InsertParagraphAfter();
            task2an1.CloseUp();

            Word.Paragraph task2an2;
            task2an2 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task2an2.Range.Text = "Произведение нечетных чисел массива = " + Convert.ToString(mod);
            task2an2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task2an2.Range.Font.Size = Convert.ToInt32(14);
            task2an2.Range.InsertParagraphAfter();
            task2an2.CloseUp();

            Word.Paragraph task3oglav;
            task3oglav = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task3oglav.Range.Text = "Задание 3";
            task3oglav.Range.Font.Bold = 0;
            task3oglav.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            task3oglav.Range.Font.Size = Convert.ToInt32(18);
            task3oglav.Range.InsertParagraphAfter();
            task3oglav.CloseUp();

            Word.Paragraph task3an1;
            task3an1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task3an1.Range.Text = "Количество чисел перед минимальным числом = " + Convert.ToString(amin);
            task3an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task3an1.Range.Font.Size = Convert.ToInt32(14);
            task3an1.Range.InsertParagraphAfter();
            task3an1.CloseUp();

            Word.Paragraph task4oglav;
            task4oglav = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task4oglav.Range.Text = "Задание 4";
            task4oglav.Range.Font.Bold = 0;
            task4oglav.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            task4oglav.Range.Font.Size = Convert.ToInt32(18);
            task4oglav.Range.InsertParagraphAfter();
            task4oglav.CloseUp();

            Word.Paragraph task4an1;
            task4an1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task4an1.Range.Text = "Значение факториала = " + Convert.ToString(ans3);
            task4an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task4an1.Range.Font.Size = Convert.ToInt32(14);
            task4an1.Range.InsertParagraphAfter();
            task4an1.CloseUp();

            Word.Paragraph task5oglav;
            task5oglav = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task5oglav.Range.Text = "Задание 5";
            task5oglav.Range.Font.Bold = 0;
            task5oglav.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            task5oglav.Range.Font.Size = Convert.ToInt32(18);
            task5oglav.Range.InsertParagraphAfter();
            task5oglav.CloseUp();

            Word.Paragraph task5an1;
            task5an1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task5an1.Range.Text = "Самое длинное слово = " + Convert.ToString(str[index]);
            task5an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task5an1.Range.Font.Size = Convert.ToInt32(14);
            task5an1.Range.InsertParagraphAfter();
            task5an1.CloseUp();

            Word.Paragraph task5an2;
            task5an2 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task5an2.Range.Text = "Количество букв в слове = " + Convert.ToString(s);
            task5an2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task5an2.Range.Font.Size = Convert.ToInt32(14);
            task5an2.Range.InsertParagraphAfter();
            task5an2.CloseUp();

            Word.Paragraph task6oglav;
            task6oglav = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task6oglav.Range.Text = "Задание 6";
            task6oglav.Range.Font.Bold = 0;
            task6oglav.Alignment = Word.WdParagraphAlignment.wdAlignParagraphCenter;
            task6oglav.Range.Font.Size = Convert.ToInt32(18);
            task6oglav.Range.InsertParagraphAfter();
            task6oglav.CloseUp();

            Word.Paragraph task6an1;
            task6an1 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task6an1.Range.Text = "Сумма всех чисел в строке = " + Convert.ToString(sm);
            task6an1.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task6an1.Range.Font.Size = Convert.ToInt32(14);
            task6an1.Range.InsertParagraphAfter();
            task6an1.CloseUp();

            Word.Paragraph task6an2;
            task6an2 = wdDoc.Content.Paragraphs.Add(ref wdMiss);
            task6an2.Range.Text = "Произведение всех чисел в строке = " + Convert.ToString(md);
            task6an2.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            task6an2.Range.Font.Size = Convert.ToInt32(14);
            task6an2.Range.InsertParagraphAfter();
            task6an2.CloseUp();

            Console.WriteLine("Нажмите любую клавишу для завершения программы");
            Console.ReadKey();

            #endregion
        }

        static double Factorial(int N)
        {
            double a = 1.0;

            for (int i = 1; i < N+1; i++)
            {
                a *= i;
            }

            return a;
        }

    }

}
