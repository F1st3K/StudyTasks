﻿//Вариант 14 - задание 14, 19, 02.
//Задание 14. Вычисление расстояния между населенными пунктами, изображенными на карте
//Введите исходные данные:
//Масштаб карты (количество километров в одном сантиметре) - xx.xx
//Расстояние между точками, изображающими населенные пункты (см) - xx.xx
//Расстояние между населенными пунктами: xxx.xx км.
//Задание 19. Вычисление объема трехгранной (треугольник равносторонний) призмы
//Введите исходные данные:
//Введите длину стороны основания (в сантиметрах) - xx.xx
//Введите высоту призмы (в сантиметрах) - xx.xx
//Объем призмы: xxx.xx см.куб.
//Задание 02. Вычисление объема параллелепипеда
//Введите исходные данные:
//Длина (см) - xx
//Ширина (см) - xx
//Высота (см) - xx
//Объем: xxx куб.см.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR12
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание1
            Console.WriteLine("Задание14");
            double a = 0;
            double b = 0;

            m100:
            try
            {
                Console.WriteLine("Введите маштаб карты(вещественное)");
                a = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m100;
            }
            m200:
            try
            {
                Console.WriteLine("Введите расстояние между точками в сантиметрах(вещественное)");
                b = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m200;
            }

            a = a * b;

            Console.WriteLine("Расстояние медлу точками в км: " + a);

            #endregion

            #region Задание2
            Console.WriteLine("Задание19");



            m300:
            try
            {
                Console.WriteLine("Введите длину стороны основания(вещественное)");
                a = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m300;
            }
        m400:
            try
            {
                Console.WriteLine("Введите высоту призмы(вещественное)");
                b = Convert.ToDouble(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m400;
            }

            a = (Math.Pow(a, 2) / 2) * b * Math.Sqrt(3);
            Console.WriteLine("Объем призмы: " + a);

            #endregion

            #region Задание3
            Console.WriteLine("Задание3");
            int z, x, c;

            m500:
            try
            {
                Console.WriteLine("Введите длину(целое)");
                z = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m500;
            }
            m600:
            try
            {
                Console.WriteLine("Введите ширину(целое)");
                x = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m600;
            }
            m700:
            try
            {
                Console.WriteLine("Введите высоту(целое)");
                c = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Введен неверный формат");
                goto m700;
            }

            z = z * x * c;

            Console.WriteLine("Объем параллелепипеда: " + z);

            #endregion

            Console.ReadKey();
        }
    }
}
