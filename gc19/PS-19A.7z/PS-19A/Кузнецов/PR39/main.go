package main

import (
	"fmt"
)

//ВАРИАНТ № А14/Б32
//1. Дан целочисленный массив, состоящий из N элементов (N > 0).
//Преобразовать массив, прибавив к четным числам первый элемент.
//Первый и последний элементы массива не изменять. Вывести новый
//полученный массив.

//2. Дан целочисленный массив, состоящий из N элементов (N > 0).
//Найти максимальный и минимальный элемент в массиве и вычислить
//их сумму.

//3. Написать функцию int Min5(A, B, C, D, E) целого типа,
//возвращающую одно минимальное значение из 5-и своих
//аргументов (параметры A, B, C, D и E - целые числа).

//4. Написать функцию bool Even(K) логического типа,
//возвращающую True, если целый параметр K является
//четным, и False в противном случае. С ее помощью
//найти количество четных чисел в наборе из 10 целых
//положительных чисел.

func main() {

	var ASD int
	var N int
	fmt.Println("Задание1")
m1:
	fmt.Println("Введите размер массива")
	_, err := fmt.Scan(&N)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m1
	}

	if N <= 0 {
		fmt.Printf("Размер массива не может быть меньше или равен 0)")
		goto m1
	}

	var MAS1 []int
	for i := 0; i < N; i++ {
	a1:
		i++
		fmt.Printf("Введите %d число массива - ", i)
		i--
		_, err = fmt.Scan(&ASD)

		if err != nil {
			fmt.Println("Произошла ошибка")
			goto a1
		}
		MAS1 = append(MAS1, ASD)
	}
	MAS := Task1(MAS1, N)
	fmt.Print("Новый массив - ")
	for i := 0; i < N; i++ {
		fmt.Print(MAS[i])
		fmt.Print(" ")
	}
	fmt.Printf("\n")

	fmt.Println("Задание2")
m2:
	fmt.Println("Введите размер массива")
	_, err = fmt.Scan(&N)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto m2
	}

	if N <= 0 {
		fmt.Printf("Размер массива не может быть меньше или равен 0)")
		goto m2
	}

	var MAS2 []int

	for i := 0; i < N; i++ {
	a3:
		i++
		fmt.Printf("Введите %d число массива - ", i)
		i--
		_, err = fmt.Scan(&ASD)

		if err != nil {
			fmt.Println("Произошла ошибка")
			goto a3
		}
		MAS2 = append(MAS2, ASD)
	}
	var MAX, MIN, SUM int = Task2(MAS2, N)
	fmt.Printf("Максимальное число в массиве - %d\n", MAX)
	fmt.Printf("Минимальное число в массиве - %d\n", MIN)
	fmt.Printf("Их сумма - %d\n", SUM)

	var A, B, C, D, E int

	fmt.Println("Задание3")

as1:
	fmt.Println("Введите число A")
	_, err = fmt.Scan(&A)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto as1
	}

as2:
	fmt.Println("Введите число B")
	_, err = fmt.Scan(&B)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto as2
	}

as3:
	fmt.Println("Введите число C")
	_, err = fmt.Scan(&C)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto as3
	}

as4:
	fmt.Println("Введите число D")
	_, err = fmt.Scan(&D)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto as4
	}

as5:
	fmt.Println("Введите число E")
	_, err = fmt.Scan(&E)

	if err != nil {
		fmt.Println("Произошла ошибка")
		goto as5
	}

	fmt.Printf("Минимальное число среди 5 чисел - %d\n", Min5(A, B, C, D, E))

	var Count int = 0

	fmt.Println("Задание4")

	for i := 0; i < 10; i++ {
	m123:
		i++
		fmt.Printf("Введите %d число - ", i)
		i--
		_, err = fmt.Scan(&ASD)

		if err != nil {
			fmt.Println("Произошла ошибка")
			goto m123
		}
		if ASD <= 0 {
			fmt.Println("Ошибка, число не может быть отрицательным или равным 0")
			goto m123
		}
		if Even(ASD) {
			Count++
		}
	}
	fmt.Printf("\n")
	fmt.Println("Кол-во четных чисел в 10 введенных чисел - ", Count)
}

func Task1(MAS []int, lengh int) []int {
	var AS int = MAS[0]
	for i := 1; i < lengh-1; i++ {
		if MAS[i]%2 == 0 {
			MAS[i] += AS
		}
	}
	return MAS
}

func Task2(MAS []int, lengh int) (int, int, int) {
	var MAX int = MAS[0]
	var MIN int = MAS[0]
	var SUM int

	for i := 0; i < lengh; i++ {
		if MIN > MAS[i] {
			MIN = MAS[i]
		}
		if MAX < MAS[i] {
			MAX = MAS[i]
		}
	}
	SUM = MAX + MIN

	return MAX, MIN, SUM
}

func Min5(A, B, C, D, E int) int {
	var MIN int = A
	var MAS [5]int
	MAS[0] = A
	MAS[1] = B
	MAS[2] = C
	MAS[3] = D
	MAS[4] = E

	for i := 0; i < 5; i++ {
		if MIN > MAS[i] {
			MIN = MAS[i]
		}
	}

	return MIN
}

func Even(K int) bool {
	var ans bool

	if K%2 == 0 {
		ans = true
	}
	if K%2 != 0 {
		ans = false
	}

	return ans
}
