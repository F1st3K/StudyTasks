﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kuznetsov
{
    public class PR26
    {
        public bool Task01(int N)
        {
            bool ans = false;

            int A1 = N / 100;
            int A2 = (N - (A1 * 100)) / 10;
            int A3 = (N - (A1 * 100) - (A2 * 10));

            if ((A1 + A2 + A3) == (A1 * A3))
            {
                ans = true;
            }
            else
            {
                ans = false;
            }

            return ans;
        }

        public double[] Task02(int b1, int b2)
        {
            double[] MAS2 = new double[4];

            MAS2[0] = Convert.ToDouble(b1) + Convert.ToDouble(b2);
            MAS2[1] = Convert.ToDouble(b1) - Convert.ToDouble(b2);
            MAS2[2] = Convert.ToDouble(b1) * Convert.ToDouble(b2);
            MAS2[3] = Convert.ToDouble(b1) / Convert.ToDouble(b2);

            return MAS2;
        }

        public int Min3(int A, int B, int C)
        {
            int[] MAS3 = new int[3];

            MAS3[0] = A;
            MAS3[1] = B;
            MAS3[2] = C;

            A = MAS3.Min();

            return A;
        }

        public string Task04(string TXT)
        {
            char[] s = TXT.ToArray();

            for (int i = 0; i < TXT.Length; i ++ )
            {
                if (i % 2 != 0)
                {
                    s[i] = '%';
                }
            }

            string TXT1 = new string(s);
            return TXT1;
        }
    }
}
