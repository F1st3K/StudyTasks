﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Kuznetsov;

//ВАРИАНТ № А14/Б22
//1. Ввести целое положительное трехзначное число N (N>0). Проверить истинность высказывания: 
//"Сумма всех цифр введенного числа равна произведению первой и третьей цифры введенного числа".

//2. Ввести два ненулевых положительных целых числа. Найти и вывести на экран их сумму, разность, произведение и частное.

//3. Написать функцию int Min3(A, B, C) целого типа, возвращающую одно минимальное значение из 3-х своих аргументов (параметры A, B, C - целые числа).

//4. Вводится строка. Длина строки может быть разной. Заменить на символ '%' (процент) каждый второй символ исходной строки. Вывести полученную строку 
//и общее количество замен этих символов.

namespace App
{
    class Program
    {
        static void Main(string[] args)
        {
            PR26 lib = new PR26();

            #region задание1

            int N;

            Console.WriteLine("Задание1");
            m1:
            try
            {
                Console.WriteLine("Введите трехзначное число");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m1;
            }
            catch(OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m1;
            }
            if (N < 100 || N > 999)
            {
                Console.WriteLine("Ошибка, введено не то значение");
                goto m1;
            }

            bool ans = lib.Task01(N);

            if (ans == true)
            {
                Console.WriteLine("Да, сумма всех чисел равна произведению 1 и 3 числа");
            }
            else
            {
                Console.WriteLine("Нет, сумма всех чисел не равна произведению 1 и 3 числа");
            }

            #endregion

            #region задание2

            int b1 = 0, b2 = 0;
            double[] MAS = new double[4];

            Console.WriteLine("Задание2");
            m2:
            try
            {
                Console.WriteLine("Введите 1 ненулевое положительное число");
                b1 = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            if (b1 <= 0)
            {
                Console.WriteLine("Число не должно быть отрицательным и быть равным нулю");
                goto m2;
            }

            m3:
            try
            {
                Console.WriteLine("Введите 2 ненулевое положительное число");
                b2 = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m3;
            }
            if (b2 <= 0)
            {
                Console.WriteLine("Число не должно быть отрицательным и быть равным нулю");
                goto m3;
            }

            MAS = lib.Task02(b1, b2);

            Console.WriteLine("Сумма чисел = " + MAS[0]);
            Console.WriteLine("Разность чисел = " + MAS[1]);
            Console.WriteLine("Произведение чисел = " + MAS[2]);
            Console.WriteLine("Частное чисел = " + MAS[3]);

            #endregion

            #region задание3

            int A, B, C;

            Console.WriteLine("Задание3");

            t1:
            try
            {
                Console.WriteLine("Введите 1 число");
                A = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto t1;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto t1;
            }

            t2:
            try
            {
                Console.WriteLine("Введите 2 число");
                B = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto t2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto t2;
            }

            t3:
            try
            {
                Console.WriteLine("Введите 3 число");
                C = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto t3;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto t3;
            }

            A = lib.Min3(A, B, C);

            Console.WriteLine("Минимальное число из трех = " + A);

            #endregion

            #region задание4

            string TXT, TXT1;

            Console.WriteLine("Задание4");

            m10:
            try
            {
                Console.WriteLine("Введите строку");
                TXT = Console.ReadLine();
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("Ошибка, недостаточно памяти");
                goto m10;
            }
            catch(ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка, переполнение аргумента");
                goto m10;
            }
            if (TXT == "")
            {
                Console.WriteLine("Ошибка, введена пустая строка");
                goto m10;
            }

            TXT1 = lib.Task04(TXT);

            Console.WriteLine("Получившееся строка = " + TXT1);

            #endregion

            Console.WriteLine("Нажмите любую кнопку для завершения работы программы");
            Console.ReadKey();
        }
    }
}
