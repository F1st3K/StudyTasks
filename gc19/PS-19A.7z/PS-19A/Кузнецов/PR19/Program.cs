﻿//ВАРИАНТ № А14/Б32
//1. Из шести целых чисел найти наибольшее и наименьшее число, 
//а так же среднее арифметическое этих введенных чисел.
//2. Дан целочисленный массив, состоящий из N элементов (N > 0). 
//Найти сумму и произведение всех нечетных чисел из данного массива.
//3. Дан целочисленный массив, состоящий из N элементов (N > 0). 
//Найти и вывести количество элементов, расположенных перед первым минимальным элементом.
//4. Написать функцию double Factorial(N) вещественного типа, 
//вычисляющую значение факториала N! = 1*2*…*N (N > 0 — параметр целого типа; 
//вещественное возвращаемое значение используется для того, чтобы избежать 
//целочисленного переполнения при больших значениях N).
//5. Вводится строка, содержащая буквы и цифры. Длина строки может быть разной. 
//Вывести сумму и произведение цифр этой введенной строки. Чтобы избежать целочисленного 
//переполнения при произведении, вычислять это выражение с помощью вещественной переменной 
//и выводить его как вещественное число.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19
{
    class Program
    {
        static void Main(string[] args)
        {
            #region задание1

            int i;
            int[] MAS1 = new int[6];

            Console.WriteLine("задание1");

            for(i = 0; i < 6; i++)
            {
            m1:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число");
                    i--;
                    MAS1[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch(FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m1;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m1;
                }
                catch (OutOfMemoryException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m1;
                }
                catch (ArgumentOutOfRangeException)
                {
                    Console.WriteLine("Ошибка аргумента");
                    goto m1;
                }
            }

            int min = MAS1.Min();
            int max = MAS1.Max();
            double srar = (Convert.ToDouble(MAS1[0]) + Convert.ToDouble(MAS1[1]) + Convert.ToDouble(MAS1[2]) + Convert.ToDouble(MAS1[3]) + Convert.ToDouble(MAS1[4]) + Convert.ToDouble(MAS1[5])) / 6;

            Console.WriteLine("Минимальное число = " + min);
            Console.WriteLine("Максимальное число = " + max);
            Console.WriteLine("Среднее арифметическое = " + srar);


            #endregion

            #region задание2

            Console.WriteLine("задание2");

            int N;
            int sum = 0;
            int PRO = 1;

            m2:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка аргумента");
                goto m2;
            }
            if (N <= 0)
            {
                Console.WriteLine("Размер массива должен быть больше нуля");
                goto m2;
            }

            int[] MAS2 = new int[N];

            for (i = 0; i < N; i++)
            {
            m3:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число");
                    i--;
                    MAS2[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m3;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m3;
                }
                catch (OutOfMemoryException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m3;
                }
                catch (ArgumentOutOfRangeException)
                {
                    Console.WriteLine("Ошибка аргумента");
                    goto m3;
                }
            }

            for (i = 0; i < N; i++)
            {
                if (MAS2[i] % 2 != 0)
                {
                    sum += MAS2[i];
                    PRO *= MAS2[i];
                }
            }

            Console.WriteLine("Сумма нечетных чисел равно = " + sum);
            Console.WriteLine("Произведение нечетных чисел равно = " + PRO);

            #endregion

            #region задание3

            Console.WriteLine("задание3");

            int cou = 0;

            m4:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m4;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m4;
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m4;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка аргумента");
                goto m4;
            }
            if (N <= 0)
            {
                Console.WriteLine("Размер массива должен быть больше нуля");
                goto m4;
            }

            int[] MAS4 = new int[N];

            for (i = 0; i < N; i++)
            {
            m5:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число");
                    i--;
                    MAS4[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m5;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m5;
                }
                catch (OutOfMemoryException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m5;
                }
                catch (ArgumentOutOfRangeException)
                {
                    Console.WriteLine("Ошибка аргумента");
                    goto m5;
                }
            }

            int m = MAS4.Min();

            for (i = 0; i < N; i++)
            {
                if (MAS4[i] == m)
                {
                    break;
                }
                cou++;
            }

            Console.WriteLine("Количество чисел перед минимальным числом равно " + cou);

            #endregion

            #region задание4

            Console.WriteLine("задание4");

            double otv1;

            m9:
            try
            {
                Console.WriteLine("Введите факториал");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m9;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m9;
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m9;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка аргумента");
                goto m9;
            }
            if (N <= 0)
            {
                Console.WriteLine("Число должно быть больше нуля");
                goto m9;
            }

            double otv2 = Factorial(N);

            Console.WriteLine("Факториал равен " + Convert.ToDouble(otv2));

            #endregion

            #region задание5

            Console.WriteLine("задание5");

            string TXT;
            double os = 0;
            double op = 1;

            m10:
            try
            {
                Console.WriteLine("Введите строку");
                TXT = Convert.ToString(Console.ReadLine());
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("ошибка переполнения памяти");
                goto m10;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("ошибка переполнения аргумента");
                goto m10;
            }
            if (TXT == "")
            {
                Console.WriteLine("Вы не ввели строку");
                goto m10;
            }

            for (i = 0; i < TXT.Length; i++)
            {
                if (TXT[i] == '0')
                {
                    os += 0;
                    op *= 0;
                }
                if (TXT[i] == '9')
                {
                    os += 9;
                    op *= 9;
                }
                if (TXT[i] == '8')
                {
                    os += 8;
                    op *= 8;
                }
                if (TXT[i] == '7')
                {
                    os += 7;
                    op *= 7;
                }
                if (TXT[i] == '6')
                {
                    os += 6;
                    op *= 6;
                }
                if (TXT[i] == '5')
                {
                    os += 5;
                    op *= 5;
                }
                if (TXT[i] == '4')
                {
                    os += 4;
                    op *= 4;
                }
                if (TXT[i] == '3')
                {
                    os += 3;
                    op *= 3;
                }
                if (TXT[i] == '2')
                {
                    os += 2;
                    op *= 2;
                }
                if (TXT[i] == '1')
                {
                    os += 1;
                    op *= 1;
                }
            }

            Console.WriteLine("Сумма чисел = " + os);
            Console.WriteLine("Произведение чисел = " + op);

            #endregion

            Console.ReadKey();
        }

        static double Factorial(int N)
        {
            double otv2 = 1.0;
            double fact = 1.0;


            for (int i = 0; i < N; i++)
            {
                otv2 *= fact;
                fact++;
            }

            return otv2;
     
        }
    }
}
