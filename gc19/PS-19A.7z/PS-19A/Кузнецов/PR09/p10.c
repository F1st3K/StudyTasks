//ВАРИАНТ № 14
//1. Из пяти целых положительных введенных чисел найти два наименьших.
//2. Проверить истинность высказывания: "Все цифры данного целого положительного 
//пятизначного числа введенного с клавиатуры различны".
//3. Дано целое положительное число в диапазоне от 200 до 999. 
//Вторая цифра не может быть единицей. Вывести строку - словесное описание 
//данного числа, например: 256 - "двести пятьдесят шесть", 874 - 
//"восемьсот семьдесят четыре".

int vMas[4];
int i = 0;
int A = 0;
int A1, A2, A3, A4, A5, A6;

#include "math.h"

int main()
{
	printf("________________TASK1_______________\n");
	printf("Input 5 positive numbers\n");
	
	for (i=0;i<5;i++)
	{
		do{
		scanf("%d",&vMas[i]);
		}while(vMas[i]<=0);
	}
	
	A = vMas[0];
	
	for(i=0;i<5;i++)
	{
		if (A>vMas[i])
		{
			A = vMas[i];
		}
	}
	
	for(i=0;i<5;i++)
	{
		if (A==vMas[i])
		{
			vMas[i] = 0;
			i = 6;
		}
	}
	
	A1 = A;
	
	A = vMas[0];
	
	if (A == 0)
	{
		A = vMas[2];
	}
	
	for(i=0;i<5;i++)
	{
		if (A>vMas[i] && vMas[i] != 0)
		{
			A = vMas[i];
		}
	}
	
	A2 = A;
	
	printf("The two smallest numbers: %d and %d\n", A1, A2);
	
	
		printf("________________TASK2_______________\n");
		do{
		printf("Input positive five-degree number\n");
		scanf("%d",&A);
		
		A1 = A / 10000;
		A2 = (A - (A1 * 10000)) / 1000;
		A3 = (A - (A1 * 10000) - (A2 * 1000)) / 100;
		A4 = (A - (A1 * 10000) - (A2 * 1000) - (A3 * 100))/10;
		A5 = (A - (A1 * 10000) - (A2 * 1000) - (A3 * 100) - (A4 * 10));
		A6 = A / 100000;
		}while(A6 != 0 || A1 <= 0 || A <= 0);
		
		if (A1 != A2 && A1 != A3 && A1 != A4 && A1 != A5 && A2 != A3 && A2 != A4 && A2 != A5 && A3 != A4 && A3 != A5 && A4 != A5)
		{
			printf("YES, ALL NUMBERS NO EQUEL\n");
		}
		else
		{
			printf("NO, NUMBERS EQUEL\n");
		}
	
	printf("________________TASK3_______________\n");
	
	do{
	printf("Input positive number(200 to 999), second number no equel 1\n");
	scanf("%d", &A);
	A4 = A / 1000;
	A1 = A / 100;
	A2 = (A - (A1 * 100))/10;
	A3 = A - (A1 * 100) - (A2 * 10);
	}while(A < 200 || A > 999);
	
	if (A1 == 1)
	{
		printf("One hundred ");
	}
	if (A1 == 2)
	{
		printf("Two hundred ");
	}
	if (A1 == 3)
	{
		printf("Three hundred ");
	}
	if (A1 == 4)
	{
		printf("Four hundred ");
	}
	if (A1 == 5)
	{
		printf("Five hundred ");
	}
	if (A1 == 6)
	{
		printf("Six hundred ");
	}
	if (A1 == 7)
	{
		printf("Seven hundred ");
	}
	if (A1 == 8)
	{
		printf("Eight hundred ");
	}
	if (A1 == 9)
	{
		printf("Nine hundred ");
	}
	if (A2 == 0)
	{
		printf("");
	}
	if (A2 == 2)
	{
		printf("twenty ");
	}
	if (A2 == 3)
	{
		printf("thirty ");
	}
	if (A2 == 4)
	{
		printf("fourty ");
	}
	if (A2 == 5)
	{
		printf("fifty ");
	}
	if (A2 == 6)
	{
		printf("sixty ");
	}
	if (A2 == 7)
	{
		printf("seventy ");
	}
	if (A2 == 8)
	{
		printf("eighty ");
	}
	if (A2 == 9)
	{
		printf("ninety ");
	}
	
	if (A3 == 0)
	{
		printf("\n");
	}
	if (A3 == 1)
	{
		printf("one \n");
	}
	if (A3 == 2)
	{
		printf("two \n");
	}
	if (A3 == 3)
	{
		printf("three \n");
	}
	if (A3 == 4)
	{
		printf("four \n");
	}
	if (A3 == 5)
	{
		printf("five \т");
	}
	if (A3 == 6)
	{
		printf("six \n");
	}
	if (A3 == 7)
	{
		printf("seven \n");
	}
	if (A3 == 8)
	{
		printf("eight \n");
	}
	if (A3 == 9)
	{
		printf("nine \n");
	}
	
	return 0;
}