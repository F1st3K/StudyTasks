﻿//ВАРИАНТ № А14/Б32
//1. Проверить истинность высказывания: "Все цифры данного целого положительного трехзначного числа введенного с клавиатуры различны".
//2. Даны два целых положительных числа A и B (число A меньше числа B). Вывести все четные числа, 
//расположенные между данными числами (не включая сами эти числа), в порядке их убывания, 
//а также количество этих чисел и их сумму.
//3. Вводится строка. Длина строки может быть разной. Заменить на символ '%' (процент) 
//каждый второй символ исходной строки. Вывести полученную строку и общее количество замен этих символов.
//4. Вводится строка, изображающая целое число. Длина строки может быть разной. 
//Вывести на экран произведение всех четных цифр этого числа.
//5. Вводится строка, состоящая из слов разделенных точками. Длина строки может быть разной. 
//Сформировать и вывести подстроку, расположенную между первой и второй точками исходной строки. 
//Если в строке менее двух точек, то вывести всю исходную строку.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR14
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание1

            int A, A1, A2, A3, A4;

            Console.WriteLine("Задание1");

            m1:


            try
            {
                Console.WriteLine("Введите целое положительное трехзначное число");
                A = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m1;
            }
            catch(OverflowException)
            {
                Console.WriteLine("Ошибка");
                goto m1;
            }

            A1 = A / 100;
            A2 = (A - (A1 * 100)) / 10;
            A3 = (A - (A1 * 100) - (A2 * 10));
            A4 = A / 1000;

            if (A4 != 0 || A1 == 0 || A <= 0)
            {
                Console.WriteLine("Ошибка, число должно быть трехзначным и положительным");
                goto m1;
            }

            if (A1 != A2 && A2 != A3 && A1 != A3)
            {
                Console.WriteLine("Все числа данного трезначного числа различны");
            }
            else
            {
                Console.WriteLine("Все числа данного трезначного числа не различны");
            }

            #endregion

            #region Задание2
            int S, B, i;
            int COU = 0;
            int SUM = 0;

            Console.WriteLine("Задание2");

            do
            {
            m2:
                try
                {
                    Console.WriteLine("Введите первое число(оно должно быть меньше второго числа и положительное)");
                    S = Convert.ToInt32(Console.ReadLine());
                }
                catch(OverflowException)
                {
                    Console.WriteLine("ошибка");
                    goto m2;
                }
                catch(FormatException)
                {
                    Console.WriteLine("ошибка формата");
                    goto m2;
                }
            m3:
                try
                {
                    Console.WriteLine("Введите второе число(оно должно быть больше первого числа и положительное)");
                    B = Convert.ToInt32(Console.ReadLine());
                }
                catch (OverflowException)
                {
                    Console.WriteLine("ошибка");
                    goto m3;
                }
                catch (FormatException)
                {
                    Console.WriteLine("ошибка формата");
                    goto m3;
                }
            
                }
                while(S >= B || S < 0 || B < 0);

            B--;

            for (i = B; i > S; i--)
            {
                if (i == S)
                {
                    break;
                }
                if (i % 2 == 0)
                {
                    SUM = SUM + i;
                    COU++;
                    Console.Write(i + " ");
                }
            }

            Console.WriteLine("\nКоличество четных чисел между числами " + COU);
            Console.WriteLine("\nСумма четных чисел между числами " + SUM);

            #endregion

            #region Задание3

            string TXT;
            int d;
            int COU1 = 0;

            Console.WriteLine("Задание3");

            m30:
            try
            {
                Console.WriteLine("Введите строку");
                TXT = Convert.ToString(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m30;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка");
                goto m30;
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Ошибка");
                goto m30;
            }
            catch (System.IO.IOException)
            {
                Console.WriteLine("Ошибка");
                goto m30;
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("ошибка");
                goto m30;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("ошибка");
                goto m30;
            }

            if (String.IsNullOrEmpty(TXT))
            {
                Console.WriteLine("Введено пустое значение");
                goto m30;
            }

            char[] CH = new char[TXT.Length];

            for (d = 0; d < TXT.Length; d++)
            {
                if (d % 2 != 0)
                {
                    CH[d] = '%';
                    COU1++;
                }
                else
                {
                    CH[d] = TXT[d];
                }
            }

            String TXT1 = new string(CH);
            TXT = TXT1;
            Console.WriteLine(TXT);
            Console.WriteLine("Кол-во смен: " + COU1);

            #endregion

            #region Задание4

            string TXT2;
            int z;
            bool f23 = false;
            int PR = 1;
            
            Console.WriteLine("Задание4");

        m40:
            try
            {
                Console.WriteLine("Введите строку, изображающая цифру");
                TXT2 = Convert.ToString(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m40;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка");
                goto m40;
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Ошибка");
                goto m40;
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("ошибка");
                goto m40;
            }
            catch (System.IO.IOException)
            {
                Console.WriteLine("Ошибка");
                goto m40;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("ошибка");
                goto m40;
            }
            if (String.IsNullOrEmpty(TXT2))
            {
                Console.WriteLine("Введено пустое значение");
                goto m40;
            }
            if (TXT2[0] == '0')
            {
                Console.WriteLine("Первая цифра не может быть 0");
                goto m40;
            }

            f23 = false;

            for (z = 0; z < TXT2.Length; z++)
            {
                if ((TXT2[z] >= 'A' && TXT2[z] <= 'Z') || (TXT2[z] >= 'a' && TXT2[z] <= 'z') || (TXT2[z] >= 'А' && TXT2[z] <= 'Я') || (TXT2[z] >= 'а' && TXT2[z] <= 'я'))
                {
                    f23 = true;
                }
            }

            if (f23 == false)
            {
                for (z = 0; z < TXT2.Length; z++)
                {
                    if (TXT2[z] == '2')
                    {
                        PR = PR * 2;
                    }
                    if (TXT2[z] == '4')
                    {
                        PR = PR * 4;
                    }
                    if (TXT2[z] == '6')
                    {
                        PR = PR * 6;
                    }
                    if (TXT2[z] == '8')
                    {
                        PR = PR * 8;
                    }
                }
                Console.WriteLine("Произведение всех четных чисел этого числа = " + PR);
            }
            else
            {
                Console.WriteLine("были введены буквы, а не цифры(ОШИБКА)");
                goto m40;
            }

            #endregion

            #region Задание5

            string TXT5;
            bool FL1 = false;
            bool FL2 = false;
            int c;
            int COU7 = 0;

            Console.WriteLine("Задание5");

        m60:
            try
            {
                Console.WriteLine("Введите строку(с точками делящие слова)");
                TXT5 = Convert.ToString(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m60;
            }
            catch (System.IO.IOException)
            {
                Console.WriteLine("Ошибка");
                goto m60;
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Ошибка");
                goto m60;
            }
            catch (OutOfMemoryException)
            {
                Console.WriteLine("ошибка");
                goto m60;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("ошибка");
                goto m60;
            }
            if (String.IsNullOrEmpty(TXT5))
            {
                Console.WriteLine("Введено пустое значение");
                goto m60;
            }

            for (c = 0; c < TXT5.Length; c++)
            {
                if (TXT5[c] == '.')
                {
                    FL1 = true;
                    c++;
                    break;
                }
            }


            if (FL1 == true)
            {
                for (int m = c; m < TXT5.Length; m++)
                {
                    COU7++;
                    if (TXT5[m] == '.')
                    {
                        FL2 = true;
                        break;
                    }
                }
            }

            COU7--;

            if (FL1 == true && FL2 == true)
            {
                Console.WriteLine("Слово между 1 и 2 точками");
                Console.WriteLine(TXT5.Substring(c, COU7));
            }
            else
            {
                Console.WriteLine("Полная строка");
                Console.WriteLine(TXT5);
            }

            #endregion

            Console.ReadKey();
        }
    }
}
