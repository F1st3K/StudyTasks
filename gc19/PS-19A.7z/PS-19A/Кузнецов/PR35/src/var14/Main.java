package var14;
import java.io.*;

//ВАРИАНТ № А14/Б27
//1. Дано четырехзначное целое ненулевое положительное число N (N>0). Проверить истинность высказывания:
// "Все цифры данного числа одинаковые".

//2. Задано целое положительное четырехзначное число N (N > 0). Найти сумму между произведениями первых
// двух и последних двух его цифр.

//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Проверить, чередуются ли в
// нем четные и нечетные числа. Если чередуются, то вывести 0, если нет, то вывести порядковый
// номер первого элемента, нарушающего закономерность.

//4. Вводится строка. Длина строки может быть разной. Подсчитать количество содержащихся в
// этой строке чисел (от 0 до 9). Вычислить и вывести сумму этих чисел.

//5. Вводится строка, состоящая из слов (разделенных знаком равенства - '='), содержащая,
// по крайней мере, один символ '='. Длина строки может быть разной. Вывести подстроку,
// расположенную между вторым и третьим знаком '=' исходной строки. Если строка содержит
// менее 3-х символов '=', то вывести всю строку.

public class Main {

    public static void main(String[] args) {

        int A, A1, A2, A3, A4;
        int [] Array;
        System.out.println("Задание1");
        String pathi1 = System.getProperty("user.dir") + File.separatorChar + "input1.txt";
        String patho1 = System.getProperty("user.dir") + File.separatorChar + "output1.txt";

        try (FileReader fr = new FileReader(pathi1))
        {
            BufferedReader br = new BufferedReader(fr);

            Array = br.lines().mapToInt(Integer::parseInt).toArray();

            if (Array != null) {

                A = Array[0];

                if (A < 1000 || A > 9999)
                {
                    System.out.println("Ошибка, в файле не черехзначное положительное число");
                    System.out.println("Задание будет пропущено");
                }
                else {
                    A1 = A / 1000;
                    A2 = (A - (A1 * 1000)) / 100;
                    A3 = (A - (A1 * 1000) - (A2 * 100)) / 10;
                    A4 = (A - (A1 * 1000) - (A2 * 100) - (A3 * 10));

                    if (A1 == A2 && A2 == A3 && A3 == A4)
                    {
                        try (FileWriter wr = new FileWriter(patho1))
                        {
                            wr.write("Да, все цифры введенного числа равны");
                        }
                    }
                    else
                    {
                        try (FileWriter wr = new FileWriter(patho1))
                        {
                            wr.write("Нет, не все цифры введенного числа равны");
                        }
                    }
                }
            }
            else
            {
                System.out.println("В файл не введено число");
                System.out.println("Задание будет пропущено");
            }
        }
        catch (NumberFormatException ex)
        {
            System.out.println("Ошибка формата данных в файле");
            System.out.println("Задание будет пропущено");
        }
        catch (FileNotFoundException ex)
        {
            System.out.println("Файл не найден");
            System.out.println("Задание будет пропущено");
        }
        catch (IOException ex)
        {
            System.out.println("Ошибка файла");
            System.out.println("Задание будет пропущено");
        }
        catch (ArrayIndexOutOfBoundsException ex)
        {
            System.out.println("Ошибка, в файл ничего не введено или произошел выход за границы массива");
            System.out.println("Задание будет пропущено");
        }

        System.out.println("Задание2");
        String pathi2 = System.getProperty("user.dir") + File.separatorChar + "input2.txt";
        String patho2 = System.getProperty("user.dir") + File.separatorChar + "output2.txt";

        try (FileReader fr = new FileReader(pathi2))
        {
            BufferedReader br = new BufferedReader(fr);

            Array = br.lines().mapToInt(Integer::parseInt).toArray();

            if (Array != null) {

                A = Array[0];

                if (A < 1000 || A > 9999)
                {
                    System.out.println("Ошибка, в файле не черехзначное положительное число");
                    System.out.println("Задание будет пропущено");
                }
                else {
                    A1 = A / 1000;
                    A2 = (A - (A1 * 1000)) / 100;
                    A3 = (A - (A1 * 1000) - (A2 * 100)) / 10;
                    A4 = (A - (A1 * 1000) - (A2 * 100) - (A3 * 10));

                    A1 = (A1 * A2) + (A3 * A4);

                    try (FileWriter wr = new FileWriter(patho2))
                    {
                        wr.write("Сумма произведений первых и двух и последних двух цифр введенного четрехзначного числа равна " + A1);
                    }
                }
            }
            else
            {
                System.out.println("В файл не введено число");
                System.out.println("Задание будет пропущено");
            }
        }
        catch (NumberFormatException ex)
        {
            System.out.println("Ошибка формата данных в файле");
            System.out.println("Задание будет пропущено");
        }
        catch (FileNotFoundException ex)
        {
            System.out.println("Файл не найден");
            System.out.println("Задание будет пропущено");
        }
        catch (IOException ex)
        {
            System.out.println("Ошибка файла");
            System.out.println("Задание будет пропущено");
        }
        catch (ArrayIndexOutOfBoundsException ex)
        {
            System.out.println("Ошибка, в файл ничего не введено или произошел выход за границы массива");
            System.out.println("Задание будет пропущено");
        }

        System.out.println("Задание3");
        int K = 0;
        int [] MAS3;
        String pathi3 = System.getProperty("user.dir") + File.separatorChar + "input3.txt";
        String patho3 = System.getProperty("user.dir") + File.separatorChar + "output3.txt";

        try (FileReader fr = new FileReader(pathi3)) {
            BufferedReader br = new BufferedReader(fr);

            MAS3 = br.lines().mapToInt(Integer::parseInt).toArray();
            A1 = MAS3[0];

            int fl = 0;
            for (int i = 0; i < MAS3.length - 1; i++) {
                if ((MAS3[i] % 2 == 0 && MAS3[i+1] % 2 == 0))
                {
                    fl = 1;
                    K = i + 2;
                    break;
                }
                if (MAS3[i] % 2 != 0 && MAS3[i+1] % 2 != 0)
                {
                    fl = 1;
                    K = i + 2;
                    break;
                }
            }

            if (fl == 1)
            {
                try (FileWriter wr = new FileWriter(patho3))
                {
                    wr.write("" + K);
                }
            }
            else
            {
                try (FileWriter wr = new FileWriter(patho3))
                {
                    wr.write("0");
                }
            }

        }
        catch (NumberFormatException ex)
        {
            System.out.println("Ошибка формата данных в файле");
            System.out.println("Задание будет пропущено");
        }
        catch (FileNotFoundException ex)
        {
            System.out.println("Файл не найден");
            System.out.println("Задание будет пропущено");
        }
        catch (IOException ex)
        {
            System.out.println("Ошибка файла");
            System.out.println("Задание будет пропущено");
        }
        catch (ArrayIndexOutOfBoundsException ex)
        {
            System.out.println("Ошибка, в файл ничего не введено или произошел выход за границы массива");
            System.out.println("Задание будет пропущено");
        }

        System.out.println("Задание4");
        int count = 0;
        int summ = 0;
        String pathi4 = System.getProperty("user.dir") + File.separatorChar + "input4.txt";
        String patho4 = System.getProperty("user.dir") + File.separatorChar + "output4.txt";

        try (FileReader fr = new FileReader(pathi4)) {
            BufferedReader br = new BufferedReader(fr);

            String TXT = br.readLine();
            char [] chars = TXT.toCharArray();

            for(int i = 0; i < TXT.length(); i++)
            {
                switch (chars[i])
                {
                    case('0'):
                        count++;
                        break;
                    case('1'):
                        count++;
                        summ += 1;
                        break;
                    case('2'):
                        count++;
                        summ += 2;
                        break;
                    case('3'):
                        count++;
                        summ += 3;
                        break;
                    case('4'):
                        count++;
                        summ += 4;
                        break;
                    case('5'):
                        count++;
                        summ += 5;
                        break;
                    case('6'):
                        count++;
                        summ += 6;
                        break;
                    case('7'):
                        count++;
                        summ += 7;
                        break;
                    case('8'):
                        count++;
                        summ += 8;
                        break;
                    case('9'):
                        count++;
                        summ += 9;
                        break;
                    default:
                        break;
                }
            }

            try(FileWriter wr = new FileWriter(patho4))
            {
                wr.write("Кол-во цифр в строке - " + count );
                wr.write("       Сумма цифр в строке - " + summ);
            }

        }
        catch (FileNotFoundException ex)
        {
            System.out.println("Файл не найден");
            System.out.println("Задание будет пропущено");
        }
        catch (IOException ex)
        {
            System.out.println("Ошибка файла");
            System.out.println("Задание будет пропущено");
        }
        catch (NullPointerException ex)
        {
            System.out.println("Ошибка, строка не введена");
            System.out.println("Задание будет пропущено");
        }

        System.out.println("Задание5");
        int counter = 0;
        String pathi5 = System.getProperty("user.dir") + File.separatorChar + "input5.txt";
        String patho5 = System.getProperty("user.dir") + File.separatorChar + "output5.txt";

        try (FileReader fr = new FileReader(pathi5)) {
            BufferedReader br = new BufferedReader(fr);

            String TXT1 = br.readLine();
            char [] chars1 = TXT1.toCharArray();

            for (int i = 0; i < TXT1.length(); i++)
            {
                if (chars1[i] == '=')
                {
                    counter++;
                }
            }

            if (counter == 0)
            {
                System.out.println("Ошибка, строка не содержит символов '='");
            }
            else {
                if (counter == 1 || counter == 2) {
                    try(FileWriter wr = new FileWriter(patho5))
                    {
                        wr.write(TXT1);
                    }
                }
                else
                {
                    String[] parts = TXT1.split("=");
                    try(FileWriter wr = new FileWriter(patho5))
                    {
                        wr.write(parts[2]);
                    }
                }
            }
        }
        catch (FileNotFoundException ex)
        {
            System.out.println("Файл не найден");
            System.out.println("Задание будет пропущено");
        }
        catch (IOException ex)
        {
            System.out.println("Ошибка файла");
            System.out.println("Задание будет пропущено");
        }
        catch (NullPointerException ex)
        {
            System.out.println("Ошибка, строка не введена");
            System.out.println("Задание будет пропущено");
        }
    }
}
