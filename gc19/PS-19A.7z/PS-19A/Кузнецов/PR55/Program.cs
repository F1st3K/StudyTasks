﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            #region task1

            int num;
            int A1, A2, A3, A4;
            int mul = 1;
            int fl = 0;

            Console.WriteLine("Задание1");

            m1:

            try
            {
                Console.WriteLine("Введите положительное четырехзначное число");
                num = Convert.ToInt32(Console.ReadLine());
            }
            catch(FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m1;
            }
            catch(OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m1;
            }
            if (num < 1000 || num > 9999)
            {
                Console.WriteLine("Число должно быть положительным четырехзначным");
                goto m1;
            }

            A1 = num / 1000;
            A2 = (num - (A1 * 1000)) / 100;
            A3 = (num - (A1 * 1000) - (A2 * 100)) / 10;
            A4 = (num - (A1 * 1000) - (A2 * 100) - (A3 * 10));

            if (A1 % 2 != 0)
            {
                fl = 1;
                mul *= A1;
            }
            if (A2 % 2 != 0)
            {
                fl = 1;
                mul *= A2;
            }
            if (A3 % 2 != 0)
            {
                fl = 1;
                mul *= A3;
            }
            if (A4 % 2 != 0)
            {
                fl = 1;
                mul *= A4;
            }

            if (fl != 1)
            {
                mul = 0;
            }

            Console.WriteLine("Разница между суммой всех цифр введенного числа и произведением нечетных цифр введенного числа равна " + Math.Abs((A1 + A2 + A3 + A4) - mul ));

            #endregion

            #region task2

            int N;
            int max, min, indexmax = 0, indexmin = 0;

            Console.WriteLine("Задание2");

            m2:
            try
            {
                Console.WriteLine("Введите размер массива");
                N = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m2;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m2;
            }
            if (N <= 0)
            {
                Console.WriteLine("Ошибка, размер массива не может быть отрицательным или равным нулю");
                goto m2;
            }

            int[] MAS1 = new int[N];

            for(int i = 0; i < N; i++)
            {
            m3:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число массива");
                    i--;
                    MAS1[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m3;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка переполнения");
                    goto m3;
                }
            }

            max = MAS1[0];
            min = MAS1[0];

            for (int i = 0; i < N; i++)
            {
                if (max < MAS1[i])
                {
                    max = MAS1[i];
                    indexmax = i;
                }
                if (min > MAS1[i])
                {
                    min = MAS1[i];
                    indexmin = i;
                }
            }

            Console.Write("Начальный массив ");

            for (int i = 0; i < N; i++)
            {
                Console.Write(MAS1[i]+" ");
            }
            Console.WriteLine("");

            MAS1[indexmin] = max;
            MAS1[indexmax] = min;

            Console.Write("Новый массив ");

            for (int i = 0; i < N; i++)
            {
                Console.Write(MAS1[i] + " ");
            }
            Console.WriteLine("");

            #endregion

            #region task3

            int Y;

            Console.WriteLine("Задание3");

            m4:
            try
            {
                Console.WriteLine("Введите год (положительное число)");
                Y = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m4;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m4;
            }
            if (Y <= 0)
            {
                Console.WriteLine("Ошибка, год не может быть отрицательным");
                goto m4;
            }

            Console.WriteLine("Год является високосным? " + IsLeapYear(Y));

            #endregion

            #region task4

            string txt;
            int sum = 0;
            double pow = 1.0;
            bool fl1 = false;

            Console.WriteLine("Задание4");

            m10:
            try
            {
                Console.WriteLine("Введите строку");
                txt = Console.ReadLine();
            }
            catch(OutOfMemoryException)
            {
                Console.WriteLine("Ошибка недостатка памяти");
                goto m10;
            }
            catch (ArgumentOutOfRangeException)
            {
                Console.WriteLine("Ошибка переполнения аргумента памяти");
                goto m10;
            }
            if (txt == "")
            {
                Console.WriteLine("Ошибка, введена пустая строка");
                goto m10;
            }

            char [] ch = txt.ToCharArray();

            for (int i = 0; i < ch.Length;i++)
            {
                if (ch[i] == '0')
                {
                    pow *= 0.0;
                    sum += 0;
                    fl1 = true;
                }
                if (ch[i] == '1')
                {
                    pow *= 1.0;
                    sum += 1;
                    fl1 = true;
                }
                if (ch[i] == '2')
                {
                    pow *= 2.0;
                    sum += 2;
                    fl1 = true;
                }
                if (ch[i] == '3')
                {
                    pow *= 3.0;
                    sum += 3;
                    fl1 = true;
                }
                if (ch[i] == '4')
                {
                    pow *= 4.0;
                    sum += 4;
                    fl1 = true;
                }
                if (ch[i] == '5')
                {
                    pow *= 5.0;
                    sum += 5;
                    fl1 = true;
                }
                if (ch[i] == '6')
                {
                    pow *= 6.0;
                    sum += 6;
                    fl1 = true;
                }
                if (ch[i] == '7')
                {
                    pow *= 7.0;
                    sum += 7;
                    fl1 = true;
                }
                if (ch[i] == '8')
                {
                    pow *= 8.0;
                    sum += 8;
                    fl1 = true;
                }
                if (ch[i] == '9')
                {
                    pow *= 9.0;
                    sum += 9;
                    fl1 = true;
                }
            }

            if (fl1 == false)
            {
                pow = 0;
            }

            Console.WriteLine("Произведение чисел в строке равно " + pow + ", а сумма чисел равна " + sum);

            #endregion

            #region task5

            int A = 0;

            Console.WriteLine("Задание5");

            m100:
            try
            {
                Console.WriteLine("Введите положительное число");
                A = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m100;
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка переполнения");
                goto m100;
            }
            if (A <= 0)
            {
                Console.WriteLine("Ошибка, число должно быть положительным");
                goto m100;
            }

            if (A % 2 != 0 && A < 1000 & A > 99)
            {
                Console.WriteLine("Число является трехзначным и нечетным");
            }
            else
            {
                Console.WriteLine("Число не является трехзначным и нечетным");
            }

            #endregion

            Console.WriteLine("Нажмите любую клавишу для завершения работы программы");
            Console.ReadKey();
        }

        public static bool IsLeapYear(int Y)
        {
            if (Y % 4 == 0 && !(Y % 100 == 0 && Y % 400 != 0))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
