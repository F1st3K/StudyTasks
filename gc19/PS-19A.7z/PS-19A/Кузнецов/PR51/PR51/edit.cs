﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PR51
{
    public partial class edit : Form
    {
        string ID = "";

        public edit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (movie_tittle.Text == "" || place_number.Text == "" || row_number.Text == "" || cashier_number.Text == "" || price.Text == "")
            {
                MessageBox.Show(this, "Все поля не заполнены", "Ошибка заполнения", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    string con = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";
                    OleDbConnection oleDbConn = new OleDbConnection(con);
                    oleDbConn.Open();
                    OleDbCommand sql = new OleDbCommand("UPDATE tickets SET movie_title='" + movie_tittle.Text + "', place_number = " + Convert.ToInt32(place_number.Text) + ", row_number = " + Convert.ToInt32(row_number.Text) + ", session_date = '" + dateTimePicker1.Text + "', cashier_number = " + Convert.ToInt32(cashier_number.Text) + ", price = " + Convert.ToInt32(price.Text) + " Where id=" + Convert.ToInt32(ID) + ";");
                    sql.Connection = oleDbConn;
                    sql.ExecuteNonQuery();

                    oleDbConn.Close();

                    update_db();

                    movie_tittle.Text = "";
                    place_number.Text = "";
                    row_number.Text = "";
                    cashier_number.Text = "";
                    price.Text = "";

                    button1.Enabled = false;
                }
                catch (OleDbException)
                {
                    MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    button1.Enabled = false;
                }
                catch (FieldAccessException)
                {
                    MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    button1.Enabled = false;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            menu t1 = new menu();
            t1.Show();
            Hide();
        }

        private void movie_tittle_TextChanged(object sender, EventArgs e)
        {
            if (movie_tittle.Text.Length != 0 && place_number.Text.Length != 0 && row_number.Text.Length != 0 && cashier_number.Text.Length == 7 && price.Text.Length != 0)
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void place_number_TextChanged(object sender, EventArgs e)
        {
            if (movie_tittle.Text.Length != 0 && place_number.Text.Length != 0 && row_number.Text.Length != 0 && cashier_number.Text.Length == 7 && price.Text.Length != 0)
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void place_number_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void row_number_TextChanged(object sender, EventArgs e)
        {
            if (movie_tittle.Text.Length != 0 && place_number.Text.Length != 0 && row_number.Text.Length != 0 && cashier_number.Text.Length == 7 && price.Text.Length != 0)
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void row_number_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void cashier_number_TextChanged(object sender, EventArgs e)
        {
            if (movie_tittle.Text.Length != 0 && place_number.Text.Length != 0 && row_number.Text.Length != 0 && cashier_number.Text.Length == 7 && price.Text.Length != 0)
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void cashier_number_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void price_TextChanged(object sender, EventArgs e)
        {
            if (movie_tittle.Text.Length != 0 && place_number.Text.Length != 0 && row_number.Text.Length != 0 && cashier_number.Text.Length == 7 && price.Text.Length != 0)
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void price_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void edit_Load(object sender, EventArgs e)
        {
            update_db();
        }

        public void update_db()
        {
            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            try
            {
                DataTable dt1 = new DataTable();
                oleDbConn1.Open();
                OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets;");
                sql1.Connection = oleDbConn1;
                sql1.ExecuteNonQuery();
                OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

                da1.Fill(dt1);

                dt1.Columns["movie_title"].ColumnName = "Название фильма";
                dt1.Columns["place_number"].ColumnName = "Номер места";
                dt1.Columns["row_number"].ColumnName = "Номер ряда";
                dt1.Columns["session_date"].ColumnName = "Дата сессии";
                dt1.Columns["cashier_number"].ColumnName = "Номер кассира";
                dt1.Columns["price"].ColumnName = "Цена билета";

                dataGridViewTickets.DataSource = dt1;

                dataGridViewTickets.Columns[0].Visible = false;
                dataGridViewTickets.Columns[1].Width = 100;
                dataGridViewTickets.Columns[2].Width = 60;
                dataGridViewTickets.Columns[3].Width = 60;
                dataGridViewTickets.Columns[4].Width = 60;
                dataGridViewTickets.Columns[5].Width = 120;
                dataGridViewTickets.Columns[6].Width = 80;

                oleDbConn1.Close();
            }
            catch (OleDbException)
            {
                MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            catch (FieldAccessException)
            {
                MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }

        private void dataGridViewTickets_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = dataGridViewTickets.SelectedCells[0].Value.ToString();

            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";
            OleDbConnection oleDbConn1 = new OleDbConnection(con1);
            DataTable dt1 = new DataTable();

            oleDbConn1.Open();
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets Where id = " + Convert.ToInt32(ID) + ";"); // создаем запрос
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);
            sql1.Connection = oleDbConn1;
            sql1.ExecuteNonQuery();

            da1.Fill(dt1);

            movie_tittle.Text = dt1.Rows[0].ItemArray.GetValue(1).ToString();
            place_number.Text = dt1.Rows[0].ItemArray.GetValue(2).ToString();
            row_number.Text = dt1.Rows[0].ItemArray.GetValue(3).ToString();
            dateTimePicker1.Text = dt1.Rows[0].ItemArray.GetValue(4).ToString();
            cashier_number.Text = dt1.Rows[0].ItemArray.GetValue(5).ToString();
            price.Text = dt1.Rows[0].ItemArray.GetValue(6).ToString();

            oleDbConn1.Close();
        }

        private void dataGridViewTickets_RowHeaderMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = dataGridViewTickets.SelectedCells[0].Value.ToString();

            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";
            OleDbConnection oleDbConn1 = new OleDbConnection(con1);
            DataTable dt1 = new DataTable();

            oleDbConn1.Open();
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets Where id = " + Convert.ToInt32(ID) + ";"); // создаем запрос
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);
            sql1.Connection = oleDbConn1;
            sql1.ExecuteNonQuery();

            da1.Fill(dt1);

            movie_tittle.Text = dt1.Rows[0].ItemArray.GetValue(1).ToString();
            place_number.Text = dt1.Rows[0].ItemArray.GetValue(2).ToString();
            row_number.Text = dt1.Rows[0].ItemArray.GetValue(3).ToString();
            dateTimePicker1.Text = dt1.Rows[0].ItemArray.GetValue(4).ToString();
            cashier_number.Text = dt1.Rows[0].ItemArray.GetValue(5).ToString();
            price.Text = dt1.Rows[0].ItemArray.GetValue(6).ToString();

            oleDbConn1.Close();
        }
    }
}
