﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PR51
{
    public partial class add : Form
    {
        public add()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            menu t1 = new menu();
            t1.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "" || textBox5.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Ошибка! Заполните все поля!", "Сообщение пользователю", MessageBoxButtons.OK);
            }
            else
            {
                string MovieTitle = textBox1.Text.ToString();
                string PlaceNumber = textBox2.Text.ToString();
                string RowNumber = textBox3.Text.ToString();
                string SessionTime = dateTimePicker1.Text.ToString();
                string CashierNumber = textBox5.Text.ToString();
                string Price = textBox6.Text.ToString();

                int id = 0;
                Random rnd = new Random();
                id = rnd.Next(11, 50000000);

                string con = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";

                OleDbConnection oleDbConn = new OleDbConnection(con);

                try
                {
                    oleDbConn.Open();

                    OleDbCommand sql = new OleDbCommand("INSERT INTO tickets (id, movie_title, place_number, row_number, session_date, cashier_number, price) VALUES (" + id + ",'" + MovieTitle + "'," + PlaceNumber + ", " + RowNumber + ", '" + SessionTime + "'," + CashierNumber + "," + Price + ");");

                    sql.Connection = oleDbConn;

                    sql.ExecuteNonQuery();

                    oleDbConn.Close();

                    MessageBox.Show("Билет добавлен в базу", "Сообщение пользователю", MessageBoxButtons.OK);

                    UpdatedataGridViewBooks();
                }
                catch (OleDbException)
                {
                    MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    goto t1;
                }
                catch (FieldAccessException)
                {
                    MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                    goto t1;
                }

            t1:

                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox5.Clear();
                textBox6.Clear();

                button1.Enabled = false;
            }
        }

        public void UpdatedataGridViewBooks()
        {
            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            DataTable dt1 = new DataTable();
            try
            {
                oleDbConn1.Open();
            }
            catch (OleDbException)
            {
                MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                goto t1;
            }
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets;");
            sql1.Connection = oleDbConn1;
            try
            {
                sql1.ExecuteNonQuery();
            }
            catch (FieldAccessException)
            {
                MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                goto t1;
            }
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(dt1);

            dt1.Columns["movie_title"].ColumnName = "Название фильма";
            dt1.Columns["place_number"].ColumnName = "Номер места";
            dt1.Columns["row_number"].ColumnName = "Номер ряда";
            dt1.Columns["session_date"].ColumnName = "Дата сессии";
            dt1.Columns["cashier_number"].ColumnName = "Номер кассира";
            dt1.Columns["price"].ColumnName = "Цена билета";

            dataGridViewTickets.DataSource = dt1;

            dataGridViewTickets.Columns[0].Visible = false;
            dataGridViewTickets.Columns[1].Width = 100;
            dataGridViewTickets.Columns[2].Width = 60;
            dataGridViewTickets.Columns[3].Width = 60;
            dataGridViewTickets.Columns[4].Width = 60;
            dataGridViewTickets.Columns[5].Width = 120;
            dataGridViewTickets.Columns[6].Width = 80;

        t1:

            oleDbConn1.Close();
        }

        private void add_Load(object sender, EventArgs e)
        {
            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            DataTable dt1 = new DataTable();
            try
            {
                oleDbConn1.Open();
            }
            catch (OleDbException)
            {
                MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                goto t1;
            }
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets;");
            sql1.Connection = oleDbConn1;
            try
            {
                sql1.ExecuteNonQuery();
            }
            catch (FieldAccessException)
            {
                MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                goto t1;
            }
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(dt1);

            dt1.Columns["movie_title"].ColumnName = "Название фильма";
            dt1.Columns["place_number"].ColumnName = "Номер места";
            dt1.Columns["row_number"].ColumnName = "Номер ряда";
            dt1.Columns["session_date"].ColumnName = "Дата сессии";
            dt1.Columns["cashier_number"].ColumnName = "Номер кассира";
            dt1.Columns["price"].ColumnName = "Цена билета";

            dataGridViewTickets.DataSource = dt1;

            dataGridViewTickets.Columns[0].Visible = false;
            dataGridViewTickets.Columns[1].Width = 100;
            dataGridViewTickets.Columns[2].Width = 60;
            dataGridViewTickets.Columns[3].Width = 60;
            dataGridViewTickets.Columns[4].Width = 60;
            dataGridViewTickets.Columns[5].Width = 120;
            dataGridViewTickets.Columns[6].Width = 80;

        t1:

            oleDbConn1.Close();
        }

        private void textBox6_TextChanged_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox5.Text.Length == 7 && textBox6.Text != "")
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void textBox2_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox5.Text.Length == 7 && textBox6.Text != "")
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox5.Text.Length == 7 && textBox6.Text != "")
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox5.Text.Length == 7 && textBox6.Text != "")
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox5.Text.Length == 7 && textBox6.Text != "")
            {
                button1.Enabled = true;
            }
            else
            {
                button1.Enabled = false;
            }
        } 

    }
}
