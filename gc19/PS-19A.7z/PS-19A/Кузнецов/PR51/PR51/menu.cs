﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR51
{
    public partial class menu : Form
    {
        public menu()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            add t1 = new add();
            t1.Show();
            Hide();           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            edit t1 = new edit();
            t1.Show();
            Hide();    
        }

        private void button3_Click(object sender, EventArgs e)
        {
            delete t1 = new delete();
            t1.Show();
            Hide();   
        }
    }
}
