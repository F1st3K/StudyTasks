package main

import (
	"fmt"
	"os"
	"strconv"
	"strings"
)

//ВАРИАНТ № А14/Б32
//1. Из пяти целых различных ненулевых положительных и
//отрицательных чисел найти самое наименьшее число.

//2. Дано четырехзначное целое ненулевое положительное число N (N>0).
//Проверить истинность высказывания: "Все цифры данного числа различны".

//3. Дан целочисленный массив, состоящий из N элементов (N > 0).
//Заменить в массиве все элементы, встречающиеся ровно два раза
//на значение -999.

//4. Вводится строка, состоящая из слов, разделенных подчеркиваниями
//(одним или несколькими). Длина строки может быть разной. Определить
//и вывести на экран самое длинное слово а так же размер этого слова.

func main() {
	var MAS1 []int
	var asd int
	var QWE int

	fmt.Println("Задание1")

	for i := 0; i < 5; i++ {
		fmt.Printf("Введите %d число\n", i+1)
		_, err := fmt.Scan(&asd)
		if err != nil {
			fmt.Println("Произошла ошибка ввода, переход к следующему заданию")
			goto m2
		}
		if asd == 0 {
			fmt.Println("Произошла ошибка, введено нулевое число, переход к следующему заданию")
			goto m2
		}
		MAS1 = append(MAS1, asd)
	}

	QWE = MAS1[0]
	for i := 0; i < 5; i++ {
		if QWE > MAS1[i] {
			QWE = MAS1[i]
		}
	}
	fmt.Printf("Минимальное число среди введенных равно %d\n", QWE)

m2:

	var num1 int
	var A1 int
	var A2 int
	var A3 int
	var A4 int

	fmt.Println("Задание2")

	fmt.Println("Введите четырехзначное положительное число")
	_, err := fmt.Scan(&num1)
	if err != nil {
		fmt.Println("Произошла ошибка ввода, переход к следующему заданию")
		goto m3
	}
	if num1 < 1000 || num1 > 9999 {
		fmt.Println("Ошибка, в файл введено не четырехзначное положительное число, переход к следующему заданию")
		goto m3
	}

	A1 = num1 / 1000
	A2 = (num1 - (A1 * 1000)) / 100
	A3 = (num1 - (A1 * 1000) - (A2 * 100)) / 10
	A4 = (num1 - (A1 * 1000) - (A2 * 100) - (A3 * 10))

	if A1 != A2 && A1 != A3 && A1 != A4 && A2 != A3 && A2 != A4 && A3 != A4 {
		fmt.Println("Все цифры введенного числа различны")
	} else {
		fmt.Println("Не все цифры введенного числа различны")
	}
m3:
	var N int
	ans2 := "Новый массив - "
	var MAS2 []int
	var flag bool = false
	var count int = 0

	fmt.Println("Задание3")

	fmt.Println("Введите размер массива")
	_, err = fmt.Scan(&N)
	if err != nil {
		fmt.Println("Произошла ошибка ввода, переход к следующему заданию")
		goto m4
	}
	if N <= 0 {
		fmt.Println("Произошла ошибка, размер массива не может быть равен нулю или быть отрицательным, переход к следующему заданию")
		goto m4
	}

	for i := 0; i < N; i++ {
		fmt.Printf("Введите %d число\n", i+1)
		_, err := fmt.Scan(&asd)
		if err != nil {
			fmt.Println("Произошла ошибка ввода, переход к следующему заданию")
			goto m4
		}

		MAS2 = append(MAS2, asd)
	}

	count = 0

	for i := 0; i < len(MAS2); i++ {
		if MAS2[i] != -999 {
			for z := 0; z < len(MAS2); z++ {
				if MAS2[z] == MAS2[i] && flag == true {
					count++
					A2 = z
				}
				if MAS2[z] == MAS2[i] && flag == false {
					count++
					flag = true
					A1 = z
				}
			}
		}
		if count == 2 {
			MAS2[A1] = -999
			MAS2[A2] = -999
		}
		flag = false
		count = 0
	}

	for i := 0; i < len(MAS2); i++ {
		ans2 += strconv.Itoa(MAS2[i]) + " "
	}

	fmt.Println(ans2)
m4:
	var index int
	var TXT string
	var A10 []string
	var a string

	fmt.Println("Задание4")

	fmt.Println("Введите строку с подчеркиваниями")
	_, err = fmt.Scan(&TXT)

	if err != nil {
		fmt.Println("Произошла ошибка ввода, выход из программы")
		os.Exit(0)
	}
	if TXT == "" {
		fmt.Println("Введена пустая строка, выход из программы")
		os.Exit(0)
	}

	A10 = strings.Split(TXT, "_")

	count = len(A10[0])
	index = 0

	for i := 0; i < len(A10); i++ {
		if count < len(A10[i]) {
			count = len(A10[i])
			index = i
		}
	}

	a = "Самое большое слово в строке это - " + A10[index] + " c кол-во символов в этом слове - " + strconv.Itoa(len(A10[index]))

	fmt.Println(a)
}
