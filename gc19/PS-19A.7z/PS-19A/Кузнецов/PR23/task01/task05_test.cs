﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace var14
{
    [TestClass]
    public class task05_test
    {
        [TestMethod]
        public void TestWithError()
        {
            string TXT = "4+4-2+1";
            int expected = 6;

            int actual = task05.theequation(TXT);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithBiggerText()
        {
            string TXT = "4+4-2+1-";
            int expected = 0;

            int actual = task05.theequation(TXT);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithLessText()
        {
            string TXT = "4+4-22";
            int expected = 0;

            int actual = task05.theequation(TXT);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithWords()
        {
            string TXT = "asdfgz";
            int expected = 0;

            int actual = task05.theequation(TXT);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithoutString()
        {
            string TXT = "";
            int expected = 0;

            int actual = task05.theequation(TXT);

            Assert.AreEqual(expected, actual);
        }
    }
}
