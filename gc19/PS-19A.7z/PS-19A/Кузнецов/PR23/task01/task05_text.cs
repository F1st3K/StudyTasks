﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace var14
{
    [TestClass]
    public class task05_text
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
