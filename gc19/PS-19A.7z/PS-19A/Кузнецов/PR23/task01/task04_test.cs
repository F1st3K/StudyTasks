﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace var14
{
    [TestClass]
    public class task04_test
    {
        [TestMethod]
        public void TestWithOne()
        {
            int number = 1;
            double expected = 1;

            double actual = task04.Factorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithZero()
        {
            int number = 0;
            double expected = 0;

            double actual = task04.Factorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithNotPositiveNum()
        {
            int number = -15;
            double expected = 0;

            double actual = task04.Factorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithNormalNum()
        {
            int number = 5;
            double expected = 120.0;

            double actual = task04.Factorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithBigNum()
        {
            int number = 100;
            double expected = 0;

            double actual = task04.Factorial(number);

            Assert.AreEqual(expected, actual);
        }
    }
}
