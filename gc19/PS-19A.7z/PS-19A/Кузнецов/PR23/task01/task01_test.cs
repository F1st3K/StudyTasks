﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace var14
{
    [TestClass]
    public class task01_test
    {
        [TestMethod]
        public void TestWithYes()
        {
            int number = 123;
            int expected = 1;

            int actual = task01.check_non_even(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithNo()
        {
            int number = 122;
            int expected = 0;

            int actual = task01.check_non_even(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithNonPositiveNumber()
        {
            int number = -1234;
            int expected = 0;

            int actual = task01.check_non_even(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithTwoDegreeNum()
        {
            int number = 23;
            int expected = 0;

            int actual = task01.check_non_even(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithFiveDegreeNum()
        {
            int number = 12345;
            int expected = 0;

            int actual = task01.check_non_even(number);

            Assert.AreEqual(expected, actual);
        }
    }
}
