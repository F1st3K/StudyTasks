﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace var14
{
    [TestClass]
    public class task02_test
    {
        [TestMethod]
        public void TestWithNonPositiveNum()
        {
            int number = -4;
            double expected = 0;

            double actual = task02.processedfactorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithEvenNum()
        {
            int number = 6;
            double expected = 15.0;

            double actual = task02.processedfactorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithNonPositive()
        {
            int number = 7;
            double expected = 48.0;

            double actual = task02.processedfactorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithBigEvenNumber()
        {
            int number = 123;
            double expected = 0;

            double actual = task02.processedfactorial(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWithBigNotEvenNumber()
        {
            int number = 122;
            double expected = 0;

            double actual = task02.processedfactorial(number);

            Assert.AreEqual(expected, actual);
        }
    }
}
