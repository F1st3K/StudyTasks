﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace var14
{
    [TestClass]
    public class task03_test
    {
        [TestMethod]
        public void TestWith29Days()
        {
            int number = 2;
            double expected = 29;

            double actual = task03.monthwithoutrain(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWith30Days()
        {
            int number = 4;
            double expected = 30;

            double actual = task03.monthwithoutrain(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestWith31Days()
        {
            int number = 5;
            double expected = 31;

            double actual = task03.monthwithoutrain(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestErrorBiggerError()
        {
            int number = 14;
            double expected = 0;

            double actual = task03.monthwithoutrain(number);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void TestErrorLessError()
        {
            int number = -5;
            double expected = 0;

            double actual = task03.monthwithoutrain(number);

            Assert.AreEqual(expected, actual);
        }


    }
}
