﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//5. Вводится строка, изображающая целочисленное арифметическое выражение вида 
//«цифра_цифра_цифра_цифра», где на месте знака операции «_» находится символ «+» 
//или «-», а на месте "цифра" находится одна из цифр (от 1 до 9). Например, «4+7-2+5». 
//Вывести значение данного выражения (как целое число).
//
// Код для тестирования (5 задание)


namespace var14
{
    ///<summary>
    ///Основной класс 5 задания
    ///</summary>
    public class task05
    {       
        /// <summary>
        /// Считает значение из текста
        /// </summary>
        /// <param name="TXT">Строка TXT</param>
        /// <returns>Значение примера</returns>
        public static int theequation(string TXT)
        {
            int ans = 0;

            if (TXT.Length != 7)
            {
                return 0;
            }

            if ((TXT[0] >= '1' && TXT[0] <= '9') && (TXT[1] == '+' || TXT[1] == '-') && (TXT[2] >= '1' && TXT[2] <= '9') && (TXT[3] == '+' || TXT[3] == '-') && (TXT[4] >= '1' && TXT[4] <= '9') && (TXT[5] == '+' || TXT[5] == '-') && (TXT[6] >= '1' && TXT[6] <= '9'))
            {
                ans = Convert.ToInt32(TXT[0]) - 48;
                if (TXT[1] == '+')
                {
                    ans += Convert.ToInt32(TXT[2]) - 48;
                }
                else
                {
                    ans -= Convert.ToInt32(TXT[2]) - 48;
                }

                if (TXT[3] == '+')
                {
                    ans += Convert.ToInt32(TXT[4]) - 48;
                }
                else
                {
                    ans -= Convert.ToInt32(TXT[4]) - 48;
                }

                if (TXT[5] == '+')
                {
                    ans += Convert.ToInt32(TXT[6]) - 48;
                }
                else
                {
                    ans -= Convert.ToInt32(TXT[6]) - 48;
                }

                return ans;
            }
            else
            {
                return 0;
            }
        }
    }
}
