﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//3. В вещественном массиве хранится информация о количестве осадков, 
//выпавших за каждый день месяца N (N - любой месяц в году). Определить, сколько дней 
//будет без осадков.
//
// Код для тестирования (3 задание)


namespace var14
{
    ///<summary>
    ///Основной класс 3 задания
    ///</summary>
    public class task03
    {
        /// <summary>
        /// Считает дни в месяце без осадков
        /// </summary>
        /// <param name="N">Целое число N</param>
        /// <returns>Кол-во дней без осадков</returns>
        public static int monthwithoutrain(int N)
        {
            int [] MAS = new int [31];
            int os = 0;
            if (N < 0 || N > 12)
            {
                return 0;
            }
            if (N == 1 || N == 3 || N == 5 || N == 7 || N == 8 || N == 10 || N == 12)
            {
                for (int i = 0; i < 31; i++)
                {
                    MAS[i] = 0;
                    if (MAS[i] == 0)
                    {
                        os++;
                    }
                }
                return os;
            }

            if (N == 4 || N == 6 || N == 9 || N == 14)
            {
                for (int i = 0; i < 30; i++)
                {
                    MAS[i] = 0;
                    if (MAS[i] == 0)
                    {
                        os++;
                    }
                }
                return os;
            }

            if (N == 2)
            {
                for (int i = 0; i < 29; i++)
                {
                    MAS[i] = 0;
                    if (MAS[i] == 0)
                    {
                        os++;
                    }
                }
                return os;
            }

            return 0;
        }
    }
}
