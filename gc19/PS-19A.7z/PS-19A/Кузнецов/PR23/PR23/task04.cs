﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//4. Написать функцию double Factorial(N) вещественного типа, 
//вычисляющую значение факториала N! = 1*2*…*N (N > 0 — параметр целого типа; 
//вещественное возвращаемое значение используется для того, чтобы избежать целочисленного 
//переполнения при больших значениях N).
//
// Код для тестирования (4 задание)


namespace var14
{
    ///<summary>
    ///Основной класс 4 задания
    ///</summary>
    public class task04
    {
       /// <summary>
       /// Считает факториал
       /// </summary>
       /// <param name="N">Целое число N</param>
       /// <returns>Значение факториала</returns>
        public static double Factorial(int N)
        {
            double ans = 1.0;

            if (N > 60)
            {
                return 0;
            }

            if (N <= 0)
            {
                return 0;
            }

            for(int i = 1; i < N + 1; i++)
            {
                ans *= i;
            }

            return ans;
        }
    }
}
