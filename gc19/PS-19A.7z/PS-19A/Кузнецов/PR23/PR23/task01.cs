﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//ВАРИАНТ № А14/Б32
//1. Проверить истинность высказывания: 
//"Данное целое положительное число является нечетным трехзначным числом".
//
// Код для тестирования (1 задание)

namespace var14
{

    ///<summary>
    ///Основной класс 1 задания
    ///</summary>
    public class task01
    {
        /// <summary>
        /// Проверяет трехзначность и четность
        /// </summary>
        /// <param name="a">Целое число a</param>
        /// <returns>Ответ "ДА" или "НЕТ"</returns>

        public static int check_non_even(int a)
        {
            if (a < 0)
            {
                return 0;
            }
            if (a > 99 && a < 1000 && a % 2 != 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
}
