﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//2. Дано целое число N (N > 0). Если N - нечетное, то вывести произведение нечетных чисел 
//до этого числа (1*3*5*N); если N - четное, то вывести произведение четных чисел до этого числа (2*4*6*N). 
//Чтобы избежать целочисленного переполнения, вычислять это выражение с помощью вещественной переменной и 
//выводить его как вещественное число. (Пример, 6=2*4*6; 9=1*3*5*7*9).
//
// Код для тестирования (2 задание)


namespace var14
{
    ///<summary>
    ///Основной класс 2 задания
    ///</summary>
    public class task02
    {
        /// <summary>
        /// Считает факториалы четных или нечетных чисел
        /// </summary>
        /// <param name="a">Целое число a</param>
        /// <returns>Значение факториалов</returns>
        public static double processedfactorial(int a)
        {
            int i;
            double pow = 1.0;
            if (a > 60)
            {
                return 0;
            }
            if (a <= 0)
            {
                return 0;
            }
            if (a % 2 == 0)
            {
                for (i = 1; i < a + 1; i++)
                {
                    if (i % 2 != 0)
                    {
                        pow *= i;
                    }
                }
                return pow;
            }
            else
            {
                for (i = 1; i < a + 1; i++)
                {
                    if (i % 2 == 0)
                    {
                        pow *= i;
                    }
                }
                return pow;
            }
        }
    }
}
