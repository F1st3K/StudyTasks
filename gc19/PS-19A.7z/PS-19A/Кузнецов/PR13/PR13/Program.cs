﻿//ВАРИАНТ № А14/Б32
//1. Ввести пять различных ненулевых целых чисел. Найти произведение двух наименьших чисел.
//2. Проверить истинность высказывания: "Цифры данного целого положительного трехзначного числа, введенного с клавиатуры, образуют убывающую последовательность".
//3. Дан массив ненулевых целых чисел, признак его завершения - число 0. Вывести на экран все положительные нечетные числа из данного набора, 
//а строкой ниже вывести их сумму. Если требуемые числа в наборе отсутствуют, то вывести значение -1.
//4. Дан целочисленный массив, состоящий из N элементов (N > 0), содержащий, по крайней мере, два нуля. 
//Вычислить сумму чисел из данного набора, расположенных между этими двумя нулями. Если нули идут подряд, 
//то вывести 0. Если в массиве имеется только одно значение 0, то вычислить сумму всех его элементов.
//5. Дан целочисленный массив, состоящий из N элементов (N > 0, N может быть четным или нечетным числом). 
//Поменять порядок его элементов на обратный. Вычислить и вывести сумму и произведение всех его элементов.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR13
{
    class Program
    {
        static void Main(string[] args)
        {
            #region Задание1
            int[] MAS1 = new int[5];
            int i = 0;
            int min1, min2;

            Console.WriteLine("Задание1");

            for (i = 0; i < 5; i++)
            {
            m100:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число");
                    i--;
                    MAS1[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка");
                    goto m100;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Введен не верный формат данных");
                    goto m100;
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Выход за конец массива");
                    i = 20;
                    goto m200;
                }
                if (MAS1[i] == 0)
                {
                    Console.WriteLine("Число не должно равняться нулю");
                    goto m100;
                }
            }


        m200:

            min1 = MAS1[0];

            for (i = 0; i < 5; i++)
            {
                if (min1 > MAS1[i])
                {
                    min1 = MAS1[i];
                }
            }

            for (i = 0; i < 5; i++)
            {
                if (min1 == MAS1[i])
                {
                    MAS1[i] = 0;
                    i = 20;
                }
            }

            min2 = MAS1[0];

            for (i = 0; i < 5; i++)
            {
                if (min2 > MAS1[i] && MAS1[i] != 0)
                {
                    min2 = MAS1[i];
                }
            }

            min1 = min1 * min2;

            Console.WriteLine("Произведение минимальных чисел:" + min1);

            #endregion

            #region Задание2

            int FL, a = 0;
            int A1, A2, A3, A4;

            Console.WriteLine("Задание2");
            do
            {
                FL = 0;
                try
                {
                    Console.WriteLine("Введите положительное трехзначное целое число");
                    a = Convert.ToInt32(Console.ReadLine());
                }
                catch (OverflowException)
                {
                    FL = 1;
                    Console.WriteLine("Ошибка");
                }
                catch (FormatException)
                {
                    FL = 1;
                    Console.WriteLine("Ошибка формата числа");
                }
                A1 = a / 100;
                A2 = (a - (A1 * 100)) / 10;
                A3 = (a - (A1 * 100) - (A2 * 10));
                A4 = a / 1000;

            } while (FL == 1 || a <= 0 || A4 != 0 || A1 == 0);

            if (A1 > A2 && A2 > A3)
            {
                Console.WriteLine("Ответ: Число образует убывающую последовательность");
            }
            else
            {
                Console.WriteLine("Ответ: Число не образует убывающую последовательность");
            }

            #endregion

            #region Задание3

            int[] MAS2 = new int[300];
            int sum = 0;
            int b;
            Int32 c = 0;

            Console.WriteLine("Задание3");

            for (i = 0; i < 301; i++)
            {
            m300:
                try
                {
                    i++;
                    Console.WriteLine("Введите " + i + " число в массив(0 значит конец массива)");
                    i--;
                    MAS2[i] = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.WriteLine("Введен неверный формат числа");
                    goto m300;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка");
                    goto m300;
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("К сожалению, массив закончился(поставьте ноль раньше)");
                    i = 0;
                    goto m300;
                }
                if (MAS2[i] == 0)
                {
                    Console.WriteLine("Массив окончен");
                    break;
                }
            }

            for (b = 0; b < i; b++)
            {
                if (MAS2[b] == 0)
                {
                    break;
                }
                if (MAS2[b] > 0 && MAS2[b] % 2 != 0)
                {
                    Console.Write(MAS2[b] + " ");
                    sum = sum + MAS2[b];
                    c = 1;
                }
            }

            if (c != 1)
            {
                Console.WriteLine("\n-1");
            }
            else
            {
                Console.WriteLine("\nСумма положительных нечетных чисел равна:" + sum);
            }

            #endregion

            #region Задание4

            int N1, f, fa;
            int cou = 0;
            Int32 sum1 = 0;

            Console.WriteLine("Задание4");

        m500:

            try
            {
                Console.WriteLine("Введите размер массива");
                N1 = Convert.ToInt32(Console.ReadLine());
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка");
                goto m500;
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m500;
            }
            if (N1 <= 0)
            {
                Console.WriteLine("Размер массива не может быть меньше или равен 0");
                goto m500;
            }

            int[] MAS3 = new int[N1];

        m20:

            for (f = 0; f < N1; f++)
            {
            m1:
                try
                {
                    f++;
                    Console.WriteLine("Введите " + f + " число в массиве(в массиве должен быть хотя бы 1 ноль, но не более 2)");
                    f--;
                    MAS3[f] = Convert.ToInt32(Console.ReadLine());
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка");
                    goto m1;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка ввода");
                    goto m1;
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Ошибка");
                    break;
                }
            }

            fa = 0;
            cou = 0;

            for (f = 0; f < N1; f++)
            {
                if (MAS3[f] == 0)
                {
                    fa = 1;
                    cou++;
                }
            }

            if (fa != 1)
            {
                Console.WriteLine("Вы не ввели ни единого нуля");
                goto m20;
            }
            if (cou > 2)
            {
                Console.WriteLine("Вы ввели слишком много нулей");
                goto m20;
            }

            if (cou == 1)
            {
                for (f = 0; f < N1; f++)
                {
                    sum1 = sum1 + MAS3[f];
                }
            }
            else
            {
                for (f = 0; f < N1; f++)
                {
                    if (MAS3[f] == 0)
                    {
                        f++;
                        break;
                    }
                }
                for (fa = f; fa < N1; fa++)
                {
                    sum1 = sum1 + MAS3[fa];

                    if (MAS3[fa] == 0)
                    {
                        break;
                    }
                }
            }

            if (cou == 1)
            {
                Console.WriteLine("Сумма всех чисел в массиве = " + sum1);
            }
            else
            {
                Console.WriteLine("Сумма всех чисел между нулями = " + sum1);
            }

            #endregion

            #region Задание5

            int N2, r;
            int z = 0;
            int x = 0;
            Int32 P = 1;
            Int32 G = 0;

            Console.WriteLine("Задание5");

        m5:

            try
            {
                Console.WriteLine("Введите размер массива");
                N2 = Convert.ToInt32(Console.ReadLine());
            }
            catch (OverflowException)
            {
                Console.WriteLine("Ошибка");
                goto m5;
            }
            catch (FormatException)
            {
                Console.WriteLine("Ошибка формата");
                goto m5;
            }
            if (N2 <= 0)
            {
                Console.WriteLine("Размер массива не может быть меньше или равен 0");
                goto m5;
            }

            int[] MAS4 = new int[N2];

            for (z = 0; z < N2; z++)
            {
            m90:
                try
                {
                    z++;
                    Console.WriteLine("Введите " + z + " число в массив");
                    z--;
                    MAS4[z] = Convert.ToInt32(Console.ReadLine());
                }
                catch (IndexOutOfRangeException)
                {
                    Console.WriteLine("Ошибка");
                    goto m90;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Ошибка формата");
                    goto m90;
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Ошибка");
                    goto m90;
                }
            }

            for (x = 0; x < N2; x++)
            {
                G = G + MAS4[x];
                P = P * MAS4[x];
            }

            x = N2;
            r = N2;
            x--;

            for (z = 0; z < x; z++)
            {
                N2 = MAS4[z];
                MAS4[z] = MAS4[x];
                MAS4[x] = N2;
                x--;
            }

            for (z = 0; z < r; z++)
            {
                Console.Write(MAS4[z] + " ");
            }

            Console.WriteLine("\nСумма и произведение равны соответственно " + G + " и " + P);

            #endregion

            Console.ReadKey();
        }
    }
}
