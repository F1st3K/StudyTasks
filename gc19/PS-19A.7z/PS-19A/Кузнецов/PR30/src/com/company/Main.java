package com.company;
import java.util.InputMismatchException;
import java.util.Scanner;

//ВАРИАНТ № А14/Б22
//1. Проверить истинность высказывания:"Квадратное уравнение A·x2 + B·x + C = 0 с данными коэффициентами " +
//"A (A ≠ 0), B, C имеет ровно один вещественный корень".

//2. Ввести пять различных ненулевых целых чисел. Найти произведение трех наибольших чисел.

//3. Даны пять целых ненулевых положительных чисел. Найти сумму двух наименьших чисел.

//4. Дан номер месяца N - целое положительное число в диапазоне от 1 до 12 (1 - январь, 2 - февраль, ..., 12 - декабрь).
// Определить количество дней в этом месяце для не високосного года.

public class Main {

    public static void main(String[] args) {

        int A = 1, B = 1, C = 1;
        Scanner input = new Scanner(System.in);

        System.out.println("Задание1");

        try {
            System.out.println("Введите 1 корень уравнения");
            A = input.nextInt();

            while (A == 0)
            {
                System.out.println("Ошибка, 1 корень не может быть равен 0");
                System.out.println("Введите 1 корень уравнения");
                A = input.nextInt();
            }

            System.out.println("Введите 2 корень уравнения");
            B = input.nextInt();

            System.out.println("Введите 3 корень уравнения");
            C = input.nextInt();

            if ((Math.pow(B, 2) - 4 * A * C) == 0)
            {
                System.out.println("Да, уравнение имеет ровно один вещественный корень");
            }
            else
            {
                System.out.println("Нет, уравнение не имеет ровно один вещественный корень");
            }
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }

        Scanner input1 = new Scanner(System.in);
        int [] MAS1 = new int[5];

        System.out.println("Задание2");
        try
        {
            for (int i = 0; i < 5; i++)
            {
                i++;
                System.out.println("Введите " + i + " число");
                i--;
                MAS1[i] = input1.nextInt();
                while (MAS1[i] == 0)
                {
                    i++;
                    System.out.println("Введите " + i + " число (не 0)");
                    i--;
                    MAS1[i] = input1.nextInt();
                }
            }

            int z = MAS1[0];
            int s = 0;

            for (int i = 0; i < 5; i++)
            {
                if (z < MAS1[i])
                {
                    z = MAS1[i];
                    s = i;
                }
            }

            MAS1[s] = -9999;
            int z1 = MAS1[0];

            for (int i = 0; i < 5; i++)
            {
                if (z1 < MAS1[i])
                {
                    z1 = MAS1[i];
                    s = i;
                }
            }

            MAS1[s] = -9999;
            int z2 = MAS1[0];

            for (int i = 0; i < 5; i++)
            {
                if (z2 < MAS1[i])
                {
                    z2 = MAS1[i];
                }
            }

            z = z * z1 * z2;
            System.out.println("Произведение 3 максимальных чисел равно = " + z);

        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }

        Scanner input2 = new Scanner(System.in);

        System.out.println("Задание3");

        try {
            for (int i = 0; i < 5; i++)
            {
                i++;
                System.out.println("Введите " + i + " число");
                i--;
                MAS1[i] = input2.nextInt();
                while (MAS1[i] == 0)
                {
                    i++;
                    System.out.println("Введите " + i + " число (не 0)");
                    i--;
                    MAS1[i] = input2.nextInt();
                }
            }

            int f = MAS1[0];
            int r = 0;

            for (int i = 0; i < 5; i++)
            {
                if (f > MAS1[i])
                {
                    f = MAS1[i];
                    r = i;
                }
            }

            MAS1[r] = 9999;
            int f1 = MAS1[0];

            for (int i = 0; i < 5; i++)
            {
                if (f1 > MAS1[i])
                {
                    f1 = MAS1[i];
                }
            }

            f = f + f1;
            System.out.println("Сумма 2 минимальных чисел равно " + f);
        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }

        int N = 0;

        Scanner input3 = new Scanner(System.in);

        System.out.println("Задание4");

        try
        {
            System.out.println("Введите число месяца");
            N = input3.nextInt();

            switch (N) {
                case(1):
                    System.out.println("В месяце 31 день");
                    break;
                case(2):
                    System.out.println("В месяце 28 дней");
                    break;
                case(3):
                    System.out.println("В месяце 31 день");
                    break;
                case(4):
                    System.out.println("В месяце 30 дней");
                    break;
                case(5):
                    System.out.println("В месяце 31 день");
                    break;
                case(6):
                    System.out.println("В месяце 30 дней");
                    break;
                case(7):
                    System.out.println("В месяце 31 день");
                    break;
                case(8):
                    System.out.println("В месяце 31 день");
                    break;
                case(9):
                    System.out.println("В месяце 30 дней");
                    break;
                case(10):
                    System.out.println("В месяце 31 день");
                    break;
                case(11):
                    System.out.println("В месяце 30 дней");
                    break;
                case(12):
                    System.out.println("В месяце 31 день");
                    break;
                default:
                    System.out.println("Введено не верное число месяца");
                    System.out.println("Задание будет пропущено");
                    break;
            }

        }
        catch (StackOverflowError ex)
        {
            System.out.println("Ошибка переполнения");
            System.out.println("Задание будет пропущено");
        }
        catch (InputMismatchException ex)
        {
            System.out.println("Ошибка формата");
            System.out.println("Задание будет пропущено");
        }
    }
}

