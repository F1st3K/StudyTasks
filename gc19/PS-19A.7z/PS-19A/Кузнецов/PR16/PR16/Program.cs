﻿//ВАРИАНТ № А14/Б32
//1. Из пяти целых различных ненулевых положительных и отрицательных чисел найти самое наименьшее число.
//2. Дано четырехзначное целое ненулевое положительное число N (N>0). Проверить истинность высказывания: "Все цифры данного числа различны".
//3. Дан целочисленный массив, состоящий из N элементов (N > 0). Заменить в массиве все элементы, встречающиеся ровно два раза на значение -999.
//4. Вводится строка. Длина строки может быть разной. Подсчитать и вывести количество содержащихся в ней прописных букв латинского алфавита.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PR16
{
    class Program
    {
        static void Main(string[] args)
        {
            #region задание1

            int i=0, m=0;
            int[] MAS1 = new int[5];

            try
            {
                using (StreamReader sr = File.OpenText("input1.txt"))
                {
                    for (i = 0; i < 5; i++)
                    {
                        try
                        {
                            MAS1[i] = Convert.ToInt32(sr.ReadLine());
                        }
                        catch (FormatException)
                        {
                            using (StreamWriter sw = File.CreateText("output1.txt"))
                            {
                                sw.WriteLine("Ошибка формата");
                                return;
                            }
                        }
                        catch (OverflowException)
                        {
                            using (StreamWriter sw = File.CreateText("output1.txt"))
                            {
                                sw.WriteLine("Ошибка переполнения");
                                return;
                            }
                        }
                        if (MAS1[i] == 0)
                        {
                            using (StreamWriter sw = File.CreateText("output1.txt"))
                            {
                                sw.WriteLine("Ошибка, числа не должны быть равны нулю, или вы не ввели несколько данных в текстовый файл");
                                return;
                            }
                        }
                    }
                }
            }
            catch (FileNotFoundException)
            {
                using (StreamWriter sw = File.CreateText("output1.txt"))
                {
                    sw.WriteLine("Ошибка, файл не создан");
                    goto mt2;
                }
            }
            catch (UnauthorizedAccessException)
            {
                using (StreamWriter sw = File.CreateText("output1.txt"))
                {
                    sw.WriteLine("Ошибка, неавторизированный доступ");
                    goto mt2;
                }
            }
            catch (ArgumentException)
            {
                using (StreamWriter sw = File.CreateText("output1.txt"))
                {
                    sw.WriteLine("Ошибка аргумента");
                    goto mt2;
                }
            }
            catch (PathTooLongException)
            {
                using (StreamWriter sw = File.CreateText("output1.txt"))
                {
                    sw.WriteLine("Ошибка, путь слишком большой");
                    goto mt2;
                }
            }
            catch (DirectoryNotFoundException)
            {
                using (StreamWriter sw = File.CreateText("output1.txt"))
                {
                    sw.WriteLine("Ошибка, директория не найдена");
                    goto mt2;
                }
            }
            catch (NotSupportedException)
            {
                using (StreamWriter sw = File.CreateText("output1.txt"))
                {
                    sw.WriteLine("Ошибка, формат не поддерживается");
                    goto mt2;
                }
            }


            m = MAS1.Min();

            using (StreamWriter sw = File.CreateText("output1.txt"))
            {
                sw.WriteLine("Ответ: минимальное число = " + m);               
            }
    

            #endregion

            #region задание2

            mt2:

            int A = 0, A1 = 0, A2 = 0, A3 = 0, A4 = 0;

            try
            {
                using (StreamReader sr1 = File.OpenText("input2.txt"))
                {
                    try
                    {
                        A = Convert.ToInt32(sr1.ReadLine());
                    }
                    catch (FormatException)
                    {
                        using (StreamWriter sw1 = File.CreateText("output2.txt"))
                        {
                            sw1.WriteLine("Ошибка формата");
                        }
                        return;
                    }
                    catch (OverflowException)
                    {
                        using (StreamWriter sw1 = File.CreateText("output2.txt"))
                        {
                            sw1.WriteLine("Ошибка переполнения");
                        }
                        return;
                    }
                    if (A <= 0)
                    {
                        using (StreamWriter sw1 = File.CreateText("output2.txt"))
                        {
                            sw1.WriteLine("Число должно быть положительным, или вы не ввели само число");
                        }
                        return;
                    }
                    if (A > 10000 || A < 999)
                    {
                        using (StreamWriter sw1 = File.CreateText("output2.txt"))
                        {
                            sw1.WriteLine("Число должно быть четырехзначным");
                        }
                        return;
                    }

                    A1 = A / 1000;
                    A2 = (A - (A1 * 1000)) / 100;
                    A3 = (A - (A1 * 1000) - (A2 * 100)) / 10;
                    A4 = A - A1 - A2 - A3;

                    if (A1 != A2 && A1 != A3 && A1 != A4 && A2 != A3 && A2 != A4 && A3 != A4)
                    {
                        using (StreamWriter sw1 = File.CreateText("output2.txt"))
                        {
                            sw1.WriteLine("Ответ: Да, числа в числе различны");
                        }
                    }
                    else
                    {
                        using (StreamWriter sw1 = File.CreateText("output2.txt"))
                        {
                            sw1.WriteLine("Ответ: Нет, числа в числе не различны");
                        }
                    }

                }
            }
            catch (FileNotFoundException)
            {
                using (StreamWriter sw1 = File.CreateText("output2.txt"))
                {
                    sw1.WriteLine("Ошибка, файл не создан");
                    goto mt3;
                }
            }
            catch (UnauthorizedAccessException)
            {
                using (StreamWriter sw1 = File.CreateText("output2.txt"))
                {
                    sw1.WriteLine("Ошибка, неавторизированный доступ");
                    goto mt3;
                }
            }
            catch (ArgumentException)
            {
                using (StreamWriter sw1 = File.CreateText("output2.txt"))
                {
                    sw1.WriteLine("Ошибка аргумента");
                    goto mt3;
                }
            }
            catch (PathTooLongException)
            {
                using (StreamWriter sw1 = File.CreateText("output2.txt"))
                {
                    sw1.WriteLine("Ошибка, путь слишком большой");
                    goto mt3;
                }
            }
            catch (DirectoryNotFoundException)
            {
                using (StreamWriter sw1 = File.CreateText("output2.txt"))
                {
                    sw1.WriteLine("Ошибка, директория не найдена");
                    goto mt3;
                }
            }
            catch (NotSupportedException)
            {
                using (StreamWriter sw1 = File.CreateText("output2.txt"))
                {
                    sw1.WriteLine("Ошибка, формат не поддерживается");
                    goto mt3;
                }
            }
            

            #endregion

            #region задание3

            mt3:

            int N = 0;
            int z = 0, b = 0, q = -1, w = 0;
            int V;

            try
            {
                using (StreamReader sr2 = File.OpenText("input3.txt"))
                {
                    try
                    {
                        N = Convert.ToInt32(sr2.ReadLine());
                    }
                    catch (FormatException)
                    {
                        using (StreamWriter sw2 = File.CreateText("output3.txt"))
                        {
                            sw2.WriteLine("Ошибка формата");
                            return;
                        }
                    }
                    catch (OverflowException)
                    {
                        using (StreamWriter sw2 = File.CreateText("output3.txt"))
                        {
                            sw2.WriteLine("Ошибка переполнения");
                            return;
                        }
                    }         
                }
            }
            catch (FileNotFoundException)
            {
                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    sw2.WriteLine("Ошибка, файл не создан");
                    goto mt4;
                }
            }
            catch (UnauthorizedAccessException)
            {
                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    sw2.WriteLine("Ошибка, неавторизированный доступ");
                    goto mt4;
                }
            }
            catch (ArgumentException)
            {
                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    sw2.WriteLine("Ошибка аргумента");
                    goto mt4;
                }
            }
            catch (PathTooLongException)
            {
                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    sw2.WriteLine("Ошибка, путь слишком большой");
                    goto mt4;
                }
            }
            catch (DirectoryNotFoundException)
            {
                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    sw2.WriteLine("Ошибка, директория не найдена");
                    goto mt4;
                }
            }
            catch (NotSupportedException)
            {
                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    sw2.WriteLine("Ошибка, формат не поддерживается");
                    goto mt4;
                }
            }

            if (N == 0)
            {
                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    sw2.WriteLine("Кол-во чисел в массиве должно быть больше 0");
                    return;
                }
            }

            Random rnd = new Random();
            int[] MAS2 = new int[N];
            StreamReader sr2_1 = File.OpenText("input3.txt");

            for (z = 0; z < N; z++)
            {
                int num = rnd.Next(-50, 50);
                MAS2[z] = num;   
            }

            sr2_1.Close();

            q = -1;

            for (z = 0; z < N; z++)
            {
                V = MAS2[z];
                for (b = 0; b < N; b++)
                {
                    if (V == MAS2[b])
                    {
                        q++;
                        w = b;
                    }
                }
                if (q == 1)
                {
                    MAS2[z] = -999;
                    MAS2[w] = -999;
                }
                q = -1;
            }

                using (StreamWriter sw2 = File.CreateText("output3.txt"))
                {
                    for (z = 0; z < N; z++)
                    {
                        sw2.Write(MAS2[z] + "   ");
                    }
                }
           
            #endregion

            #region задание4

            mt4:

            string TXT;
            int e, cou=0;

            try
            {
                using (StreamReader sr3 = File.OpenText("input4.txt"))
                {
                    TXT = sr3.ReadLine();
                }
            }
            catch (FileNotFoundException)
            {
                using (StreamWriter sw3 = File.CreateText("output4.txt"))
                {
                    sw3.WriteLine("Ошибка, файл не создан");
                    return;
                }
            }
            catch (UnauthorizedAccessException)
            {
                using (StreamWriter sw3 = File.CreateText("output4.txt"))
                {
                    sw3.WriteLine("Ошибка, файл не создан");
                    return;
                }
            }
            catch (ArgumentException)
            {
                using (StreamWriter sw3 = File.CreateText("output4.txt"))
                {
                    sw3.WriteLine("Ошибка, файл не создан");
                    return;
                }
            }
            catch (PathTooLongException)
            {
                using (StreamWriter sw3 = File.CreateText("output4.txt"))
                {
                    sw3.WriteLine("Ошибка, файл не создан");
                    return;
                }
            }
            catch (DirectoryNotFoundException)
            {
                using (StreamWriter sw3 = File.CreateText("output4.txt"))
                {
                    sw3.WriteLine("Ошибка, файл не создан");
                    return;
                }
            }
            catch (NotSupportedException)
            {
                using (StreamWriter sw3 = File.CreateText("output4.txt"))
                {
                    sw3.WriteLine("Ошибка, файл не создан");
                    return;
                }
            }

            for (e = 0; e < TXT.Length; e++)
            {
                if (TXT[e] >= 'A' && TXT[e] <= 'Z')
                {
                    cou++;
                }
            }

            using (StreamWriter sw3 = File.CreateText("output4.txt"))
            {
                sw3.WriteLine("Ответ: Кол-во прописных букв = " + cou);
            }

            #endregion

        }
    }
}
