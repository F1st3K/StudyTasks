﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PR50
{
    public partial class Form1 : Form
    {
        string ID = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string con = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";
                OleDbConnection oleDbConn = new OleDbConnection(con);
                oleDbConn.Open();
                OleDbCommand sql = new OleDbCommand("DELETE * FROM tickets Where id=" + Convert.ToInt32(ID) + ";");
                sql.Connection = oleDbConn;
                sql.ExecuteNonQuery();

                oleDbConn.Close();

                update_db();

                button1.Enabled = false;
            }
            catch (OleDbException)
            {
                MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                button1.Enabled = false;
            }
            catch (FieldAccessException)
            {
                MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                button1.Enabled = false;
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            update_db();
        }

        private void dataGridViewTickets_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            button1.Enabled = true;

            ID = dataGridViewTickets.SelectedCells[0].Value.ToString();

            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";
            OleDbConnection oleDbConn1 = new OleDbConnection(con1);
            DataTable dt1 = new DataTable();

            oleDbConn1.Open();
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets Where id = " + Convert.ToInt32(ID) + ";"); 
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);
            sql1.Connection = oleDbConn1;
            sql1.ExecuteNonQuery();

            da1.Fill(dt1);

            oleDbConn1.Close();
        }

        public void update_db()
        {
            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            try
            {
                DataTable dt1 = new DataTable();
                oleDbConn1.Open();
                OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets;");
                sql1.Connection = oleDbConn1;
                sql1.ExecuteNonQuery();
                OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

                da1.Fill(dt1);

                dt1.Columns["movie_title"].ColumnName = "Название фильма";
                dt1.Columns["place_number"].ColumnName = "Номер места";
                dt1.Columns["row_number"].ColumnName = "Номер ряда";
                dt1.Columns["session_date"].ColumnName = "Дата сессии";
                dt1.Columns["cashier_number"].ColumnName = "Номер кассира";
                dt1.Columns["price"].ColumnName = "Цена билета";

                dataGridViewTickets.DataSource = dt1;

                dataGridViewTickets.Columns[0].Visible = false;
                dataGridViewTickets.Columns[1].Width = 100;
                dataGridViewTickets.Columns[2].Width = 60;
                dataGridViewTickets.Columns[3].Width = 60;
                dataGridViewTickets.Columns[4].Width = 60;
                dataGridViewTickets.Columns[5].Width = 120;
                dataGridViewTickets.Columns[6].Width = 80;

                oleDbConn1.Close();
            }
            catch (OleDbException)
            {
                MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
            catch (FieldAccessException)
            {
                MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
            }
        }
    }
}
