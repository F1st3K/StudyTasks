﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace PR47
{
    public partial class PR47 : Form
    {
        public PR47()
        {
            InitializeComponent();
        }

        private void PR47_Load(object sender, EventArgs e)
        {

            string con1 = "Provider= Microsoft.Jet.OLEDB.4.0; Data Source=db_tickets.mdb;";

            OleDbConnection oleDbConn1 = new OleDbConnection(con1);

            DataTable dt1 = new DataTable();
            try
            {
                oleDbConn1.Open();
            }
            catch (OleDbException)
            {
                MessageBox.Show("Ошибка, база данных не создана", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                goto t1;
            }
            OleDbCommand sql1 = new OleDbCommand("SELECT * FROM tickets;");
            sql1.Connection = oleDbConn1;
            try
            {
            sql1.ExecuteNonQuery();
            }
            catch(FieldAccessException)
            {
                MessageBox.Show("Ошибка, такой таблицы не существует", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
                goto t1;
            }
            OleDbDataAdapter da1 = new OleDbDataAdapter(sql1);

            da1.Fill(dt1);

            dt1.Columns["movie_title"].ColumnName = "Название фильма";
            dt1.Columns["place_number"].ColumnName = "Номер места";
            dt1.Columns["row_number"].ColumnName = "Номер ряда";
            dt1.Columns["session_date"].ColumnName = "Дата сессии";
            dt1.Columns["cashier_number"].ColumnName = "Номер кассира";
            dt1.Columns["price"].ColumnName = "Цена билета";

            dataGridViewTickets.DataSource = dt1;

            dataGridViewTickets.Columns[0].Visible = false;
            dataGridViewTickets.Columns[1].Width = 100;
            dataGridViewTickets.Columns[2].Width = 60;
            dataGridViewTickets.Columns[3].Width = 60;
            dataGridViewTickets.Columns[4].Width = 60;
            dataGridViewTickets.Columns[5].Width = 120;
            dataGridViewTickets.Columns[6].Width = 80;

            t1:

            oleDbConn1.Close();
        }
    }
}
