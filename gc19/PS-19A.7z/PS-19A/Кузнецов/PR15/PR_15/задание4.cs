﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR_15
{
    public partial class задание4 : Form
    {
        public задание4()
        {
            ControlBox = false;
            MaximizeBox = false;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            меню a1 = new меню();
            a1.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string TXT;
            int d=0, s=0, z=0;
            int f1 = 0, f2 = 0;
            try
            {
                TXT = Convert.ToString(textBox1.Text);
            }
            catch(OverflowException)
            {
                MessageBox.Show("ОШИБКА, введено слишком большой текст");
                textBox1.Text = "";
                return;
            }
            if (textBox1.Text == "")
            {
                MessageBox.Show("ОШИБКА, вы не ввели ни одного символа");
                textBox1.Text = "";
                return;
            }
            if (textBox1.Text == null)
            {
                MessageBox.Show("ОШИБКА, вы не ввели ни одного символа");
                textBox1.Text = "";
                return;
            }

            for (d = 0; d < TXT.Length; d++)
            {
                if (TXT[d] == '=')
                {
                    d++;
                    
                    for(z = d; z < TXT.Length; z++)
                    {
                        if (TXT[z] == '=')
                        {
                            z++;
                            f1 = 1;
                            break;
                        }
                    }
                    break;
                }
            }


            if (f1 == 1)
            {
                for (s = z; s < TXT.Length; s++)
                {
                    if (TXT[s] == '=')
                    {
                        f2 = 1;
                        break;
                    }
                }
                s = s - z;
            }

            if (f1 == 1 && f2 == 1)
            {
                richTextBox1.Text = "Ответ: " + TXT.Substring(z, s);
            }
            else
            {
                richTextBox1.Text = "Ответ: " + TXT;
            }           
        }
    }

}

