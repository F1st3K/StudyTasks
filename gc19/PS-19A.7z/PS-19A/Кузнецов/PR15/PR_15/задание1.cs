﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR_15
{
    public partial class Задание1 : Form
    {
        public Задание1()
        {
            ControlBox = false;
            MaximizeBox = false;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(textBox1.Text);
            }
            catch(FormatException)
            {
                MessageBox.Show("ОШИБКА ФОРМАТА");
                textBox1.Text = "";
                return;
            }
            catch(OverflowException)
            {
                MessageBox.Show("ОШИБКА, Вы ввели слишком большое число");
                textBox1.Text = "";
                return;
            }
            if (Convert.ToInt32(textBox1.Text) <= 0)
            {
                MessageBox.Show("ОШИБКА, число должно быть положительным");
                textBox1.Text = "";
                return;
            }

            if (Convert.ToInt32(textBox1.Text) % 2 != 0 && Convert.ToInt32(textBox1.Text) > 99 && Convert.ToInt32(textBox1.Text) < 1000)
            {
                label4.Text = "Ответ: Число трехзначное и нечетное";
                textBox1.Text = "";
            }
            else
            {
                label4.Text = "Ответ: Число не трехзначное и нечетное";
                textBox1.Text = "";
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            меню a1 = new меню();
            a1.Show();
            Hide();
        }
    }
}
