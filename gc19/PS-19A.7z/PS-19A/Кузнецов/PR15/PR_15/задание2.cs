﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR_15
{
    public partial class Задание2 : Form
    {
        public Задание2()
        {
            ControlBox = false;
            MaximizeBox = false;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double pr = 1;
            int i;
            try
            {
                int z = Convert.ToInt32(textBox1.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("ОШИБКА ФОРМАТА");
                textBox1.Text = "";
                return;
            }
            catch (OverflowException)
            {
                MessageBox.Show("ОШИБКА, введено слишком большое число");
                textBox1.Text = "";
                return;
            }
            if (Convert.ToInt32(textBox1.Text) <= 0)
            {
                MessageBox.Show("ОШИБКА, число должно быть положительным");
                textBox1.Text = "";
                return;
            }

            for (i = 1; i < Convert.ToInt32(textBox1.Text) + 1; i++)
            {
                pr = pr * i;
            }

            label4.Text = "Ответ: произведение " + textBox1.Text + " чисел равно \n" + pr;
            textBox1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            меню a1 = new меню();
            a1.Show();
            Hide();
        }
    }
}
