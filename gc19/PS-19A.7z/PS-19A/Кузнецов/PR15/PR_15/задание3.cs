﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR_15
{
    public partial class задание3 : Form
    {
        public задание3()
        {
            ControlBox = false;
            MaximizeBox = false;
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string TXT;
            int d=0, s=0;
            int f1 = 0, f2 = 0;
            try
            {
                TXT = Convert.ToString(textBox1.Text);
            }
            catch(OverflowException)
            {
                MessageBox.Show("ОШИБКА, введено слишком большой текст");
                textBox1.Text = "";
                return;
            }
            if (textBox1.Text == "")
            {
                MessageBox.Show("ОШИБКА, вы не ввели ни одного символа");
                textBox1.Text = "";
                return;
            }
            if (textBox1.Text == null)
            {
                MessageBox.Show("ОШИБКА, вы не ввели ни одного символа");
                textBox1.Text = "";
                return;
            }

            for (d = 0; d < TXT.Length; d++)
            {
                if (TXT[d] == '.')
                {
                    f1 = 1;
                    break;                 
                }
            }

            d++;

            if (f1 == 1)
            {
                for (s = d; s < TXT.Length; s++)
                {
                    if (TXT[s] == '.')
                    {
                        f2 = 1;
                        break;
                    }
                }
                s = s - d;
            }

            if (f1 == 1 && f2 == 1)
            {
                richTextBox1.Text = "Ответ: " + TXT.Substring(d, s);
            }
            else
            {
                richTextBox1.Text = "Ответ: " + TXT;
            }           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            меню a1 = new меню();
            a1.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
