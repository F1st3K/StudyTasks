package main

import (
	"fmt"
	_ "go/ast"
	"io"
	"io/ioutil"
	"math"
	"os"
	"strconv"
	"strings"
)

//ВАРИАНТ № А14/Б22
//1. Ввести целое положительное число. Проверить истинность высказывания:
//"Данное целое число является четным двузначным числом".

//2. Дан целочисленный массив, состоящий из N элементов (N > 0).
//Заменить в массиве все элементы, встречающиеся ровно два раза
//на значение -999.

//3. В целочисленном массиве хранятся сведения о количестве осадков,
//выпавших за каждый день месяца N (в месяце должно быть 30 дней).
//Определить общее количество осадков, выпавших за каждую декаду
//этого месяца (декада состоит из 10 дней).

//4. Написать функцию double RingS(R1, R2) вещественного типа,
//находящую площадь кольца, заключенного между двумя окружностями
//с общим центром и радиусами R1 и R2 (R1 и R2 — вещественные, R1 > R2).
//Воспользоваться формулой площади круга радиуса R: S = π·R2.
//В качестве значения π использовать 3.14.

//5. Вводится строка, изображающая целочисленное арифметическое выражение
//вида «цифра_цифра_цифра_цифра», где на месте знака операции «_» находится
//символ «+» или «-», а на месте "цифра" находится одна из цифр (от 1 до 9).
//Например, «4+7-2+5». Вывести значение данного выражения (как целое число).

func main() {

	var num1 int
	var c []byte

	fmt.Println("Задание1")

	f1, err := os.Open("input1.txt")

	if err != nil {
		fmt.Println("Для 1 задания не создан файл")
		goto z2
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z2
	}

	num1, err = strconv.Atoi(string(c))

	if err != nil {
		fmt.Println("Ошибка, в файл введено не верный формат данных")
		goto z2
	}

	f1.Close()

	if num1 <= 0 {
		fmt.Println("Ошибка, введено отрицательное число или равное нулю")
		goto z2
	}

	f1, err = os.OpenFile("output1.txt", os.O_CREATE|os.O_RDWR, 0777)
	if err != nil {
		fmt.Println("Ошибка в создании файла")
		goto z2
	}

	if num1 > 9 && num1 < 100 && num1%2 == 0 {
		ans1 := "Да, введенное число двухзначное и четное"
		io.WriteString(f1, ans1)

	} else {
		ans1 := "Нет, введенное число не двухзначное и четное"
		io.WriteString(f1, ans1)
	}
	f1.Close()

z2:

	var MAS1 []int
	var a string
	var A10 []string
	var o int
	ans2 := "Новый массив - "
	var A1, A2 int
	var flag bool = false
	var count int = 0

	fmt.Println("Задание2")

	f1, err = os.Open("input2.txt")

	if err != nil {
		fmt.Println("Для 2 задания не создан файл")
		goto z3
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z3
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z3
	}

	a = string(c)
	A10 = strings.Split(a, " ")

	for i := 0; i < len(A10); i++ {
		o, err = strconv.Atoi(A10[i])
		if err != nil {
			fmt.Println("Ошибка формата")
			goto z3
		}
		MAS1 = append(MAS1, o)
	}

	f1.Close()

	for i := 0; i < len(MAS1); i++ {
		if MAS1[i] != -999 {
			for z := 0; z < len(MAS1); z++ {
				if MAS1[z] == MAS1[i] && flag == true {
					count++
					A2 = z
				}
				if MAS1[z] == MAS1[i] && flag == false {
					count++
					flag = true
					A1 = z
				}
			}
		}
		if count == 2 {
			MAS1[A1] = -999
			MAS1[A2] = -999
		}
		flag = false
		count = 0
	}

	for i := 0; i < len(MAS1); i++ {
		ans2 += strconv.Itoa(MAS1[i]) + " "
	}

	f1, err = os.OpenFile("output2.txt", os.O_CREATE|os.O_RDWR, 0777)
	if err != nil {
		fmt.Println("Ошибка в создании файла")
		goto z3
	}

	io.WriteString(f1, ans2)
	f1.Close()

z3:

	var MAS10 []float64
	var X1 float64 = 0
	var X2 float64 = 0
	var X3 float64 = 0

	fmt.Println("Задание3")

	f1, err = os.Open("input3.txt")

	if err != nil {
		fmt.Println("Для 3 задания не создан файл")
		goto z4
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z4
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z4
	}

	a = string(c)
	A10 = strings.Split(a, " ")

	for i := 0; i < len(A10); i++ {
		X1, err = strconv.ParseFloat(A10[i], 64)
		if err != nil {
			fmt.Println("Ошибка формата")
			goto z4
		}
		MAS10 = append(MAS10, X1)
	}
	f1.Close()

	if len(MAS10) == 30 {
		f1, err = os.OpenFile("output3.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto z4
		}

		for i := 0; i < 9; i++ {
			X1 += MAS10[i]
		}
		ans2 = "За 1 декаду выпало " + strconv.Itoa(int(X1)) + " осадков; "
		io.WriteString(f1, ans2)
		for i := 9; i < 19; i++ {
			X2 += MAS10[i]
		}
		ans2 = "За 2 декаду выпало " + strconv.Itoa(int(X2)) + " осадков; "
		io.WriteString(f1, ans2)
		for i := 19; i < 29; i++ {
			X3 += MAS10[i]
		}
		ans2 = "За 3 декаду выпало " + strconv.Itoa(int(X3)) + " осадков."
		io.WriteString(f1, ans2)

		f1.Close()
	} else {
		fmt.Println("В файл введены данные об осадках не на 30 дней")
		goto z4
	}
z4:
	var MAS40 []float64
	var R1 float64
	var R2 float64

	fmt.Println("Задание4")

	f1, err = os.Open("input4.txt")

	if err != nil {
		fmt.Println("Для 4 задания не создан файл")
		goto z5
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z5
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z5
	}

	a = string(c)
	A10 = strings.Split(a, " ")

	for i := 0; i < len(A10); i++ {
		X1, err = strconv.ParseFloat(A10[i], 64)
		if err != nil {
			fmt.Println("Ошибка формата")
			goto z5
		}
		MAS40 = append(MAS40, X1)
	}
	f1.Close()
	if len(MAS40) == 2 {
		R1 = MAS40[0]
		R2 = MAS40[1]
		if R1 > R2 || R1 <= 0 || R2 <= 0 {
			fmt.Println("Ошибка, неправильные значения радиусов")
			goto z5
		}
		R1 = RingS(R1, R2)
		f1, err = os.OpenFile("output4.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto z5
		}
		ans2 = "Площадь кольца равна " + strconv.Itoa(int(R1))
		io.WriteString(f1, ans2)
		f1.Close()
	} else {
		fmt.Println("Введено неправильное кол-во значений в файл")
		goto z5
	}

z5:
	var TXT1 string

	fmt.Println("Задание5")

	f1, err = os.Open("input5.txt")

	if err != nil {
		fmt.Println("Для 5 задания не создан файл")
		goto z6
	}

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z6
	}

	c, err = ioutil.ReadAll(f1)

	if err != nil {
		fmt.Println("Произошла ошибка содержания файла")
		goto z6
	}

	f1.Close()
	TXT1 = string(c)

	if (TXT1[0] >= '0' && TXT1[0] <= '9') && (TXT1[2] >= '0' && TXT1[2] <= '9') && (TXT1[4] >= '0' && TXT1[4] <= '9') && (TXT1[6] >= '0' && TXT1[6] <= '9') && (TXT1[1] == '+' || TXT1[1] == '-') && (TXT1[3] == '+' || TXT1[3] == '-') && (TXT1[5] == '+' || TXT1[5] == '-') && len(TXT1) == 7 {
		var SD string
		SD = string(TXT1[0])
		B1, _ := strconv.Atoi(SD)
		SD = string(TXT1[2])
		B2, _ := strconv.Atoi(SD)
		SD = string(TXT1[4])
		B3, _ := strconv.Atoi(SD)
		SD = string(TXT1[6])
		B4, _ := strconv.Atoi(SD)
		if TXT1[1] == '+' {
			B1 += B2
		} else {
			B1 -= B2
		}
		if TXT1[3] == '+' {
			B1 += B3
		} else {
			B1 -= B3
		}
		if TXT1[5] == '+' {
			B1 += B4
		} else {
			B1 -= B4
		}
		f1, err = os.OpenFile("output5.txt", os.O_CREATE|os.O_RDWR, 0777)
		if err != nil {
			fmt.Println("Ошибка в создании файла")
			goto z6
		}
		ans2 = "Значение примера равняется " + strconv.Itoa(B1)
		io.WriteString(f1, ans2)
		f1.Close()
	} else {
		fmt.Println("Введен не верный формат строки")
		goto z6
	}

z6:
}

func RingS(A float64, B float64) float64 {

	S1 := 3.14 * math.Pow(A, 2)
	S2 := 3.14 * math.Pow(B, 2)

	S1 = S2 - S1

	return S1
}
